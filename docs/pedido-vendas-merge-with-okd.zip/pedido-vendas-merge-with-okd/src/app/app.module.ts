import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule  } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { AppVersion } from '@ionic-native/app-version';

import { Vendas } from './app.component';
// Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA 
import { StatusBar } from '@ionic-native/status-bar';
// import { SplashScreen } from '@ionic-native/splash-screen';
import { HttpModule } from '@angular/http';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { IonicImageViewerModule } from 'ionic-img-viewer';

//----------Translate file section ------
import { HttpClientModule , HttpClient} from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NavigationBar } from '@ionic-native/navigation-bar';
import { Geolocation } from '@ionic-native/geolocation';
import { Network } from '@ionic-native/network';
import { BatteryStatus } from '@ionic-native/battery-status';  

import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { IonInputScrollIntoViewModule } from 'ion-input-scroll-into-view';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';

// by Ryuge 28/01/2019
import { AppConfig } from '../config/app.config';
import { GlobalVars } from '../providers/globalvars';

//---------------------------------------

// import { LoginPage } from '../pages/login/login';
import { AuthProvider } from '../providers/auth/auth';
import { CommonServices } from './../services/common-services';
import { HttpUtilProvider } from '../providers/http-util/http-util';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

// Import library
import { HideKeyboardModule } from 'hide-keyboard';
// import { EnvironmentsModule } from './../environments/environment-variables.module.ts';
// import { ExpandableHeader } from '../components/expandable-header/expandable-header';

import { ENV } from '@app/env';
console.log(ENV.mode);

@NgModule({
  declarations: [
    Vendas
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    IonicImageViewerModule,
    IonicModule.forRoot(Vendas, {mode: 'md'}),
    // IonicModule.forRoot(Vendas),
    // EnvironmentsModule,
    IonInputScrollIntoViewModule,
    HideKeyboardModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory:  (createTranslateLoader),
        deps: [HttpClient]
      }
    })        
  ],
  bootstrap:[IonicApp],
  entryComponents: [
    Vendas
  ],  
  providers: [
    AppConfig,GlobalVars,
    BatteryStatus,
    // Deve ser comentado (StatusBar) quando for gerar versão PWA 
    StatusBar,
    // SplashScreen,
    AndroidFullScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthProvider,
    BarcodeScanner,CommonServices,
    HttpUtilProvider,NavigationBar,
    Geolocation,AppVersion,
    Network,FileTransfer,FileTransferObject,File

  ]
})
export class AppModule {}

// export function HttpLoaderFactory(http: Http) {
//   return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
// }


export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
