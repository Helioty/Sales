import { Component, ViewChild, NgZone } from '@angular/core';
import { NavigationBar } from '@ionic-native/navigation-bar';
// Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA 
// import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { TranslateService } from '@ngx-translate/core';
import { Nav, Platform, Alert } from 'ionic-angular';

// import { AndroidFullScreen } from '@ionic-native/android-full-screen';

import { AuthProvider } from '../providers/auth/auth';
import { CommonServices } from '../services/common-services';
// import { timer } from 'rxjs/observable/timer';


@Component({
  selector: 'sidemenu-page',
  templateUrl: 'app.html'
})
export class Vendas {
  @ViewChild(Nav) nav: Nav;

  public isActive: boolean = false;
  public noPhoto: boolean = false;

  foto;
  nome;
  rootPage: any = "LoginPage";
  pages: Array<{ title: string, component: any }>;
  pages2: Array<{ title: string, component: any }>;


  constructor(
    public platform: Platform,
    // Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA     
    public statusBar: StatusBar,
    // public splashScreen: SplashScreen,
    public authService: AuthProvider,
    public translate: TranslateService,
    public commonServices: CommonServices,
    private navigationBar: NavigationBar,
    private zone: NgZone,
    // private androidFullScreen: AndroidFullScreen,
  ) {

    // if(!this.platform.is('cordova') ) {
      this.handleSplashScreen();
    // }

    // usuário conectado
    this.commonServices.exibeBotaoComprar = false;
    this.pages = [
      { title: 'Meus Pedidos', component: "PedidoLista" },
      { title: 'Produtos', component: "ProdutoLista" },
      { title: 'Consulta CEP', component: "ConsultaCep" },
      { title: 'Logout', component: "LoginPage" }

    ];


    // this.pages = [
    //   { title: 'Logout', component: "LoginPage" },
    //   { title: 'Lista Produtos', component: "ProdutoLista" },
    //   { title: 'Lista Pedido', component: "HomePage" },
    //   { title: 'Clientes', component: "ClienteLista" }
    // ];

    // Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA 
    let autoHide: boolean = true;
    this.navigationBar.setUp(autoHide);
    this.navigationBar.hideNavigationBar();
    this.statusBar.hide();

    // this.goToFullScreen();


    // Usuário desconectado
    this.pages2 = [
      { title: 'Login', component: "LoginPage" }
    ];

    // if(this.platform.is('cordova') ) {
    //   this.initializeApp();
    // }

    this.translate.setDefaultLang('pt-br');
    this.translate.use('pt-br');

  }


  // goToFullScreen() {
  //   this.androidFullScreen.isImmersiveModeSupported()
  //     .then(() => this.androidFullScreen.immersiveMode())
  //     .catch((error: any) => console.log(error));
  // }

  // hide #splash-screen when app is ready
  async handleSplashScreen(): Promise<void> {
    try {
      // wait for App to finish loading
      await this.platform.ready()
    } catch (error) {
      // TODO: there is probably nothing we can do about that...
    }
    // Here you may
    const splash = document.getElementById('splash-screen')
    // start opacity animation
    splash.style.opacity = '0'
    // remove after it is hidden
    setTimeout(() => { splash.remove() }, 300)
  }

  useLanguage(language: string) {
    this.translate.use(language);
  }

  // initializeApp() {
  //     this.platform.ready().then(() => {
  //     this.statusBar.styleDefault();
  //     this.splashScreen.hide();
  //   });
  // }

  getStatus() {

    if (localStorage.getItem("token")) {
      this.foto = localStorage.getItem("foto");
      this.nome = localStorage.getItem("nome");

      if (localStorage.getItem("foto") === 'null') {
        this.noPhoto = true;
        // console.log( this.noPhoto);        
      }

      return this.isActive = true;
    }

  }

  openPage(page) {
    if (page.title == "Produtos") {
      console.log("teste");
      this.commonServices.limpaDadosPedido();
      this.nav.push(page.component, { modoConsulta: true });
    } else if (page.title == "Consulta CEP") {
      this.nav.push(page.component, { modoConsulta: true });
    } else {
      this.nav.setRoot(page.component);
    }

  }



}
