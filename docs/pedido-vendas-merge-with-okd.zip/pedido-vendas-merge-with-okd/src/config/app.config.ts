import { Injectable } from "@angular/core";
import { Http } from "@angular/http";
// by Ryuge 14/02/2019
import { ENV } from '@app/env';
import { File } from '@ionic-native/file';
// import { ToastController, Platform } from "ionic-angular";
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { Platform } from 'ionic-angular';
import Net from '../assets/js/net.js';


declare var navigator: any;
declare var Connection: any;

export let API_URL: any;
export let API_URL_NODE: any; // utilizados para serviços nodejs
export let TCPIP: any;

export function getHTTP(): any {
  return API_URL;
}

// by Ryuge
export function setURL(value) {
  API_URL = value;
}

// by Ryuge 30/11/2019
export function getIP() {
  if (this.platform.is('ios') || this.platform.is('android')) {
    Net.getIp();
    TCPIP = Net.get_ip_local();
    console.log(TCPIP);
  }
};

@Injectable()
export class AppConfig {
  // data: Observable<any>;
  posts: any;
  // dados: any;

  // // Json server connection
  private getApiUrl: string = '';

  constructor(
    public platform: Platform,
    public http: Http,
    private transfer: FileTransfer,
    private file: File
  ) {

    // by Ryuge 30/09/2019 

    if (ENV.mode == 'Production') {
      // ex: 'http://hmlfcimbservices.ferreiracosta.local:8585/WS-Publico/getUrlService';

      this.getApiUrl = 'https://publico.api.imb/getUrlServiceOKD?apl=pv';

      // Linux Server
      // this.getApiUrl = 'http://fcimbservices.ferreiracosta.local:8080/WS-Publico/getUrlService?apl=pv';

      this.getURL();
      getHTTP();
    } else {
      // teste

      // OKD
      this.getApiUrl = 'https://publico.staging.imb/getUrlServiceOKD?apl=pv';

      // linux server
      // this.getApiUrl = 'http://hmlfcimbservices.ferreiracosta.local:8585/WS-Publico/getUrlService?apl=pv';

      this.getURL();
      getHTTP();

      // teste Stttic IP
      // API_URL = 'http://10.136.1.138:8080/';
      // API_URL = 'api.aju/';
    }

    //  Net.showLog('MAIK RYUGE');

    //  Net.downloadJson();          

  }

  // ionViewDidLoad(){
  //   getHTTP();
  // }

  download() {
    const fileTransfer: FileTransferObject = this.transfer.create();
    alert('teste A');
    const url = 'https://images.unsplash.com/photo-1531981842350-9801f0b2353b?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&dl=rawpixel-744338-unsplash.jpg';
    alert('teste B');
    fileTransfer.download(url, this.file.dataDirectory + '20MB.jpg', true).then((response) => {
      alert('teste C');
      console.log('download complete: ' + response);
    }).catch(err => {
      alert(err);
      console.log(err)
    });
  }

  // by Ryuge 27/11/2019
  pong(ipRes) {
    console.log(ipRes);
    return ipRes;
  }

  // by Ryuge 27/11/2019
  checkApiServer() {

    console.log('checkApiServer');

    // let url = "http://10.136.1.138:8080";
    // let valor;
    // Net.ping('10.131.9.18','8080', this.pong(valor))
    // Net.getUserIP('10.131.9.18');
  }


  public getURL() {
    let apiUrl = this.getApiUrl;
    return new Promise(resolve => {
      this.http.get(apiUrl).subscribe(data => {
        console.log(data);
        let link: any = data.json();
        API_URL = link.server + '/';
        // API_URL = 'api.aju/';
        resolve(data);
      }, err => {
        console.log(err);
      });
    });
  }


}

//  @Injectable()
//  export class Api {
//    constructor(public http: Http) {
//      console.log('Hello Api Provider');
//    }
//  }

//  @Injectable()
//  export class MobileApi extends Api {
//    constructor(public http: Http) {
//      super(http);
//      console.log('For Mobile');
//    }
//  }

//   export function getURL2(http: Http) {
//     let apiUrl = 'http://hmlfcimbservices.ferreiracosta.local:8585/WS-Publico/getUrlService';
//     return new Promise(resolve => {
//         http.get(apiUrl).subscribe(data => {
//         console.log(data);
//         let link: any =  data.json();
//         API_URL = link.server+'/';
//         resolve(data);
//       }, err => {
//         console.log(err);
//       });
//     });
//   }

