import {Injectable} from '@angular/core';

@Injectable()
export class GlobalVars{
    private varname: string; 

    constructor() {
    }

    set_var(valor: string) {
       this.varname = valor;
    }

    get_var() {
       return this.varname;
    }
}
