import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class ButtonProgress {
	private width;
	private widthSubject = new Subject<any>();
	private duration: number = 300;

	constructor() {
		this.width = this.widthSubject.asObservable();
	}

	start() {
		this.widthSubject.next(0);
		setTimeout(() => {
			this.widthSubject.next(0.2); // sets progress bar to 20%
			setTimeout(() => {
				this.widthSubject.next(0.5); // sets progress bar to 50%
				setTimeout(() => {
					this.widthSubject.next(0.9); // sets progress bar to 90%
				}, this.duration * 1.5);
			}, this.duration * 1.25);
		}, this.duration);

		return this.width;
	}

	stop() {
		setTimeout(() => {
			this.widthSubject.next(false); // stops spinner
			this.widthSubject.complete();
		}, this.duration * 0.5);

		return this.width;
	}
}
