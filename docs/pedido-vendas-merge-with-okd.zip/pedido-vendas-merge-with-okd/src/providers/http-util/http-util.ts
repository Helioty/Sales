import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map";

import { Injectable } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import { Network } from "@ionic-native/network";
import { NavController, Platform } from "ionic-angular";

// import * as environment from "./../../environments/environment";
import { CommonServices } from "./../../services/common-services";

// by Ryuge 27/02/2019
import { AppConfig, API_URL } from '../../config/app.config';
import { ENV } from '@app/env';

declare var navigator: any;
declare var Connection: any;


@Injectable()
export class HttpUtilProvider {

  abortProcess: any;

  constructor(
    private appConfig: AppConfig,
    public http: Http,
    public commonServices: CommonServices,
    public network: Network,
    public platform: Platform
  ) { }

  public checkNetwork() {
    if (this.platform.is("cordova")) {
      var networkState = navigator.connection.type;

      var states = {};
      states[Connection.UNKNOWN] = "Unknown connection";
      states[Connection.ETHERNET] = "Ethernet connection";
      states[Connection.WIFI] = "WiFi connection";
      states[Connection.CELL_2G] = "Cell 2G connection";
      states[Connection.CELL_3G] = "Cell 3G connection";
      states[Connection.CELL_4G] = "Cell 4G connection";
      states[Connection.CELL] = "Cell generic connection";
      states[Connection.NONE] = "No network connection";

      if (
        // networkState == Connection.UNKNOWN ||
        networkState == Connection.NONE
      ) {
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  // metodo especifio para cadastro cliente
  getNoAlert(parameters: string) {

    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .get(parameters, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            reject(error);
            try {
              this.commonServices.loading.dismiss();
            } catch (err) { }
          }
        );
    });
    // }
  }

  async getJson(parameters: string) {
    let headers = new Headers();
    headers.append("x-auth-token", localStorage.getItem("token"));
    let options = new RequestOptions({ headers: headers });

    return await this.http.get(parameters, options)
      .toPromise()
      .then(res => res.json(), err => this.handleError(err));

    // return this.http.get(parameters, options)
    //     .map(res => res.json())
    //     .catch(this._Error);
  }

  _Error(error) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }

  _abortProcess() {
    this.abortProcess.unsubscribe();
  }


  get(parameters: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.abortProcess = this.http
        .get(parameters, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            // reject(error);
            try {
              this.commonServices.loading.dismiss();
            } catch (err) { }
            this.handleError(error);
            // this.commonServices.showAlert2( error.json().title, error.json().detail);
          }
        );

    });
    // }
  }

  getTMS(parameters: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .get(parameters, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            console.log("aqui1")
            resolve(result);
          },
          error => {
            console.log(JSON.parse(error._body))
            reject(JSON.parse(error._body));
            // try {
            //   this.commonServices.loading.dismiss();
            // } catch (err) { }
            // reject(JSON.parse(error._body));
          }
        );
    });
  }

  post(parameters: string, body: {}) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .post(parameters, body, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            // reject(error); // by Ryuge 28/11/2019
            try {
              this.commonServices.loading.dismiss();
            } catch (err) { }
            this.handleError(error);
          }
        );
    });
    // }
  }

  // provisório para o pedido rapido
  post2(parameters: string, body: {}) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .post(parameters, body, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            reject(error); // by Ryuge 28/11/2019
          }
        );
    });
  }

  put(parameters: string, body: {}) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http.put(parameters, body, options).map(result => result.json()),
        error => {
          // this.commonServices.showAlert2( error.json().title,  error.json().detail);
          this.handleError(error);
        };
    });
    // }
  }

  private handleError(err: any) {
    // console.error('Ocorreu um erro!', error);
    try {

      // let versionNumber: string = await this.appVersion.getVersionNumber();

      this.commonServices.exibeSkeletonLoading = false;
      this.commonServices.loading.dismiss();
    } catch (err) { }
    // by Ryuge 11/11/2019
    if (this.commonServices.loading != undefined) {
      this.commonServices.loading.dismiss();
    }

    // by Ryuge 27/11/2019
    if (err.status == 400) {
      // this.commonServices.showToast(err.json().detail);
      this.commonServices.showAlert3(err.json().title, err.json().detail);

    } else {

      if (err.status == 503) {
        this.commonServices.showAlert3('Atenção', 'Sem serviço, entrar em contato com suporte.');
      } else {
        this.commonServices.showAlert3('Atenção', err);
      }

    }

    // return Promise.reject(error.json().detail || error);
    // || error.json().message
  }

  delete(url): Promise<void> {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    let headers = new Headers();
    // headers.append('Cache-Control', 'no-store');
    headers.append("x-auth-token", localStorage.getItem("token"));
    let options = new RequestOptions({ headers: headers });

    return this.http
      .post(url, {}, options)
      .toPromise()
      .then(() => null)
      .catch(error => {
        this.commonServices.loading.dismiss();
        this.commonServices.showAlert2(
          error.json().title,
          error.json().detail
        );
      });
    // }
  }

  //Metodo Criado por Nicollas Bastos em 25/09/2018
  //Post com o uso do Reject no erro

  postNoErrorHandle(parameters: string, body: {}) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .post(parameters, body, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            console.log(error);
            reject(error);
            try {
              this.commonServices.loading.dismiss();
            } catch (err) {
            }
            // this.commonServices.showAlert2( error.json().title,  error.json().detail);
          }
        );
    });
    // }
  }

  //Metodo utilizado somente em Consulta Cliente pleo retorno do erro (função reject)
  //Criado por Nicollas Bastos em 25/09/2018
  getNoErrorHandle(parameters: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .get(parameters, options)
        .map(result => result.json())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            reject(error);
            try {
              this.commonServices.loading.dismiss();
            } catch (err) {
            }
            console.log(error)
            // this.commonServices.showAlert2( error.json().title, error.json().detail);
          }
        );
    });
    // }
  }

  //Função get para retornos em forma de String (retornos não Json)

  getNoJson(parameters: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });
      this.http
        .get(parameters, options).map(result => result.text())
        .subscribe(
          (result: any) => {
            resolve(result);
          },
          error => {
            // reject(error);
            try {
              this.commonServices.loading.dismiss();
            } catch (err) {
            }
            console.log(error)
            this.handleError(error);
            // this.commonServices.showAlert2( error.json().title, error.json().detail);
          }
        );
    });
    // }
  }

  // metodos manutenção pedido

  async getPedidoX(idPedido: string): Promise<any> {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      let headers = new Headers();
      // headers
      // headers.append('Cache-Control', 'no-store');
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });

      let response = await this.http
        .get(
          ENV.WS_VENDAS + API_URL +
          "PedidoVenda/" +
          localStorage.getItem("empresa") +
          "/" +
          idPedido,
          options
        )
        .toPromise();
      return response.json();
    } catch (error) {
      await this.handleError(error);
    }
    // }
  }

  async getPedido(idPedido: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      let result: any = await this.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/" +
        localStorage.getItem("empresa") +
        "/" +
        idPedido
      );
      return result;
    } catch (error) {
      await this.handleError(error);
    }
    // }
  }

  async getItensPedido(idPedido: string) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      let result: any = await this.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVendaItem/" +
        localStorage.getItem("empresa") +
        "/" +
        idPedido +
        "/itens"
      );
      if (result == null) {
        return result.error;
      } else {
        return result;
      }
    } catch (error) {
      await this.handleError(error);
    }
    // }
  }

  getEstoque(codProduto: string): any {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      let result: any = this.get(
        ENV.WS_PRODUTO + API_URL +
        "estoque/" +
        localStorage.getItem("empresa") +
        "/" +
        codProduto
      );
      return result;
    } catch (error) {
      this.handleError(error);
    }
    // }
  }

  getEstoquePedido(codProduto: string, codPedido): any {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      let result: any = this.get(
        ENV.WS_PRODUTO + API_URL +
        "estoque/" +
        localStorage.getItem("empresa") +
        "/" +
        codProduto +
        "?pedido=" +
        codPedido
      );
      return result;
    } catch (error) {
      this.handleError(error);
      // this.commonServices.showAlert2( error.json().title,  error.json().detail);
    }
    // }
  }

  // by Ryuge 26/12/2018
  atualizaPedido(idPedido, dataPedido: {}) {
    // if (!this.checkNetwork()) {
    //   this.commonServices.showToast("Sem conexão!");
    // } else {
    try {
      // console.log(dataPedido);
      let result: any = this.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        idPedido,
        dataPedido
      );
      // console.log(result);
      return result;
    } catch (error) {
      this.handleError(error);
    }
    // }
  }
}
