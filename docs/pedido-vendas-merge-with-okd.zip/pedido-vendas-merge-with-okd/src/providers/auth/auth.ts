import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { AlertController } from 'ionic-angular';

//  import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

// by Ryuge 15/02/2019
import { AppConfig, getHTTP,setURL, API_URL } from '../../config/app.config';

// by Ryuge 14/02/2019
import { ENV } from '@app/env';

@Injectable()
export class AuthProvider {

  // public token: any;
  public menuAcesso: string = 'Login';
  private count: number = 0;

  constructor(
    private alertCtrl: AlertController,
    private appConfig: AppConfig,
    public http: Http,
    private commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider) {

  }

 

  // by Ryuge 19/11/2019
  forceGetURL() {
    // this.appConfig.getURL();
     // by Ryuge 29/11/2019
     if (localStorage.getItem("host")) {
      this.commonServices._API_URL = localStorage.getItem('host');
    }
    if(API_URL == '' ||  API_URL == undefined){
      if ( this.commonServices._API_URL != undefined || this.commonServices._API_URL != '') {
        setURL(this.commonServices._API_URL);
        getHTTP(); 
      }else{
        getHTTP(); 
      }
    }else{
      if (!localStorage.getItem("host")) {
        this.commonServices._API_URL = API_URL;
      }
    }
  }

  login(login: string, senha: string) {

    // if (!this.httpUtilProvider.checkNetwork()) {
    //   this.commonServices.loading.dismiss();
    //   this.commonServices.showToast('Sem conexão!');
    // } else {

    // this.appConfig.checkApiServer();

    return new Promise((resolve, reject) => {

      let msg: string = '';

      let headers = new Headers();

      headers.append('login', login);
      headers.append('senha', senha);


      let options = new RequestOptions({ headers: headers });
      this.http.get(ENV.WS_AUTH + API_URL + 'loginMobile', options).subscribe(res => {
        resolve(res.json());
        console.log(res.json());
      }, (err) => {
        this.commonServices.loading.dismiss();
        if (err.status == 0) {
           this.commonServices.showAlert2( 'Atenção!', 'Login não efetuado, tente novamente.');
           this.forceGetURL(); // by Ryuge 29/11/2019
        } else {

          if (err.status == 400) {
            this.commonServices.showToast(err.json().detail);
          } else {

            if (err.status == 503) {
              this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
            }else{
              this.commonServices.showToast(err);
            }

          }
          // if (err.json().detail != null) {
          //   this.commonServices.showToast(err.json().detail);
          // } else {
          // this.commonServices.showToast(err);
          // }
        }

        /*
        if (err.json().detail != null) {
          this.commonServices.showToast(err.json().detail);
        } else {
          // by Ryuge 18/11/2019
          // ping server
          if (this.testHttp()) {
            
            this.count += 1;
            if (this.count <= 3) {
              setTimeout(() => {
                this.commonServices.showToast('Aguarde...' + this.count);
                this.login(login, senha);  // metodo recursivo  
              }, 3000);
            } else {
              this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
            }
  
          } else {
            this.commonServices.showToast('Sem conexão! Entrar em contato com suporte.');
          }
  
        }
        */

      });

    });

  }

}
