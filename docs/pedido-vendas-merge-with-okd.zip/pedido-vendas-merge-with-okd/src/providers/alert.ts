import { Injectable } from '@angular/core';
import { AlertController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AlertProvider {

	constructor(public alertCtrl: AlertController) {
		console.log('Hello AlertServiceProvider Provider');
	}

	showAlert(title: string, msg: string) {
		return new Observable((observer) => {
			let alert = this.alertCtrl.create({
				title: title,
				message: msg,
				buttons: [
					{
						text: 'Cancelar',
						role: 'cancel',
						handler: () => {
							observer.next(false);
							observer.complete();
						}
					},
					{
						text: 'Parar',
						handler: () => {
							observer.next(true);
							observer.complete();
						}
					}
				]
			});
			alert.present();
		})
	}

}
