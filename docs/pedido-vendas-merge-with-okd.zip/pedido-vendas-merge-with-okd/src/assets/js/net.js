/**
 * Get the user IP throught the webkitRTCPeerConnection
 * @param onNewIP {Function} listener function to expose the IP locally
 * @return undefined
 */

// var download = require('download-file')

// var ip = require('ip');

// const download = require('./download.js')
// import {download} from "./download.js";

// function downloadJson(){
//     // download("data:text/plain,hello%20world", "dlDataUrlText.txt", "text/plain");
//     // alert('teste');

//     var x=new XMLHttpRequest();
//     x.open("GET", "http://danml.com/wave2.gif", true);
//     x.setRequestHeader('Access-Control-Allow-Headers', '*');
//     x.setRequestHeader('Content-type', 'application/json');
//     x.setRequestHeader('Access-Control-Allow-Origin', '*');
// 	x.responseType = 'blob';
// 	x.onload=function(e){download(x.response, "dlBinAjax.gif", "image/gif" ); }
//     x.send();    

//     alert('teste');    
// }

// function downloadJson(){

//     var url = "http://i.imgur.com/G9bDaPH.jpg"

//     var options = {
//         // directory: "./images/",
//         // filename: "cat.gif"
//     }

//     download(url, options, function(err){
//         if (err) throw err
//         console.log("meow")
//     }) 
// }

var TCPIP;
function showLog(msg) {
  alert(msg);
}

function set_ip_local(ip) {
  TCPIP = ip;
}
function get_ip_local() {
  return TCPIP
}

function ping(host, port, pong) {

  var started = new Date().getTime();

  var http = new XMLHttpRequest();

  http.open("GET", "http://" + host + ":" + port, /*async*/true);
  http.onreadystatechange = function () {
    if (http.readyState == 4) {
      var ended = new Date().getTime();

      var milliseconds = ended - started;

      if (pong != null) {
        pong(milliseconds);
      }
    }
  };
  try {
    http.send(null);
  } catch (exception) {
    // this is expected
  }

}

// by Ryuge 30/11/2019
function getIp(callback) { //  onNewIp - your listener function for new IPs
  //compatibility for firefox and chrome
  var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
  var pc = new myPeerConnection({
    iceServers: []
  }),
    noop = function () { },
    localIPs = {},
    ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
    key;

  // var resolve;
  // var reject;
  // var promise = new Promise(function (res, rej) {
  //   resolve = res;
  //   reject = rej;
  // });

  function iterateIP(ip) {
    if (!localIPs[ip]) callback(ip);
    // if (!localIPs[ip]) resolve(ip);
    localIPs[ip] = true;
  }

  //create a bogus data channel
  pc.createDataChannel("");

  // create offer and set local description
  pc.createOffer(function (sdp) {
    sdp.sdp.split('\n').forEach(function (line) {
      if (line.indexOf('candidate') < 0) return;
      line.match(ipRegex).forEach(iterateIP);
    });

    pc.setLocalDescription(sdp, noop, noop);
  }, noop);

  //listen for candidate events
  pc.onicecandidate = function (ice) {
    if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
    ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
  };

  // return promise;

}

// window.onload = function () {
//   var script = document.createElement("script");
//   script.type = "text/javascript";
//   script.src = "http://jsonip.appspot.com/?callback=DisplayIP";
//   document.getElementsByTagName("head")[0].appendChild(script);
// };

// function DisplayIP() {
//   TCPIP = Request.UserHostAddress;
//   // hostname = Request.UserHostName;
//   return TCPIP;
// }


// by Ryuge 30/11/2019
getIp(function (ip) {
  console.log(ip);
  set_ip_local(ip);
  console.log(TCPIP);
});


export default { showLog, ping, getIp, get_ip_local };
// module.exports = {getUserIP: getUserIP,showLog: showLog,downloadJson:downloadJson};

// Usage

// getUserIP(function (ip) {
//     document.getElementById("ip").innerHTML = 'Got your IP ! : ' + ip;
// });

