import { Directive, ElementRef, Renderer2 } from '@angular/core';

/**
 * Generated class for the StickyHeaderDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
@Directive({
	selector: '[sticky-header]', // Attribute selector
	host: {
		'(ionScroll)': 'onContentScroll($event)'
	}
})
export class StickyHeaderDirective {

	padding: number = 12;
	ionHeaderHeight: number;

	stHead: any;
	firstChild: any;

	translateAmt: number;

	constructor(private element: ElementRef, private renderer: Renderer2) {
		console.log('Hello StickyHeaderDirective Directive');
	}

	ngOnInit() {
		//DOM root
		let root = this.element.nativeElement.parentNode;

		//Calculate ion-header height
		this.ionHeaderHeight = root.getElementsByTagName("ion-header")[0].clientHeight;

		//Content
		let content = root.getElementsByClassName("scroll-content")[0];
		// Set content margin to 0
		this.renderer.addClass(content, 'margin0');

		//Find the header element that is going to be sticky
		this.stHead = content.getElementsByClassName("stHead")[0];
		//Set margin/padding & position of header element
		this.renderer.setStyle(this.stHead, 'margin-top', '0');
		this.renderer.setStyle(this.stHead, 'top', '0');
		this.renderer.setStyle(this.stHead, 'left', '0');

		//Find the first child from DOM and add padding equal to nav-height
		this.firstChild = content.firstElementChild;
		this.renderer.setStyle(this.firstChild, 'padding-top', '' + (this.ionHeaderHeight + this.padding) + 'px')
	}

	onContentScroll(ev) {
		ev.domWrite(() => {
			this.updateHeader(ev);
		});
	}

	updateHeader(ev) {
		console.log("ev", ev);
		if (ev.scrollTop >= 0) {
			this.translateAmt = ev.scrollTop / 2;
		}

		//Position heading title
		if (ev.scrollTop >= (this.firstChild.clientHeight - 90)) {
			this.renderer.setStyle(this.stHead, 'position', 'fixed');
			this.renderer.setStyle(this.stHead, 'background-color', '#C40318');
			this.renderer.setStyle(this.stHead, 'z-index', '12');
			this.renderer.setStyle(this.stHead, 'height', '' + this.ionHeaderHeight + 'px');
			this.renderer.setStyle(this.stHead, 'line-height', '' + this.ionHeaderHeight + 'px');
			this.renderer.setStyle(this.stHead, 'width', '100%');
			//this.isFixed = true;
		} else {
			this.renderer.setStyle(this.stHead, 'position', 'static');
			//this.isFixed = false;
		}
	}

}
