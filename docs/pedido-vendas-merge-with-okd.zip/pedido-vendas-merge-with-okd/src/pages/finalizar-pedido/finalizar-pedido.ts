import { Component } from '@angular/core';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { IonicPage, LoadingController, NavController, NavParams, Platform } from 'ionic-angular';
import { AlertProvider } from '../../providers/alert';
import { ButtonProgress } from '../../providers/button-progress';

@IonicPage()
@Component({
	selector: 'finalizar-pedido',
	templateUrl: 'finalizar-pedido.html',
	providers: [ButtonProgress, AlertProvider]
})

export class FinalizarPedido {
	progress: number | boolean = false;
	button_text = "Confirmar";
	landing_title = "";

	constructor(
		public navCtrl: NavController,
		public navParams: NavParams,
		public loadingCtrl: LoadingController,
		private btnProgress: ButtonProgress,
		private alert: AlertProvider,
		public platform: Platform,
		private androidFullScreen: AndroidFullScreen
	) {
		// by ryuge 27/09/2018
		platform.registerBackButtonAction(() => {
			console.log("backPressed 1");
		}, 1);
	}

	goToFullScreen() {
		this.androidFullScreen.isImmersiveModeSupported()
		  .then(() => this.androidFullScreen.immersiveMode())
		  .catch((error: any) => console.log(error));
	  }

	ionViewWillEnter() {
		
		this.goToFullScreen();

		// by ryuge 27/09/2018
		this.platform.registerBackButtonAction(() => {
			console.log("backPressed 1");
		}, 1);
	}
	
	presentLoading() {
		this.button_text = "Jā ē quase seu!";
		this.startLoading();
	}

	startLoading() {
		this.btnProgress.start().subscribe(data => {
			this.progress = data;
			if (data >= 0.9) {
				this.alert.showAlert("Gravação da Tela", "Parar gravação da tela").subscribe(response => {
					this.btnProgress.stop().subscribe((data) => {
						this.progress = data;
					})
				}, error => {
					console.log("error", error);
				});
			}
		})
	}
}
