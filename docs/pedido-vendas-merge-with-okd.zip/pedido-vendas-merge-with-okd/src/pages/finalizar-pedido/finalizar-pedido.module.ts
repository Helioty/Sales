import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalizarPedido } from './finalizar-pedido';
import { DirectivesModule } from '../../directives/directives.module';
import { LaddaModule } from 'angular2-ladda';

@NgModule({
	declarations: [
		FinalizarPedido,
	],
	imports: [
		IonicPageModule.forChild(FinalizarPedido),
		DirectivesModule,
		LaddaModule
	],
})
export class LandingPageModule { }
