import { Component, ViewChild } from "@angular/core";
import { Headers, Http, RequestOptions } from "@angular/http";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { AlertController, Content, IonicPage, Keyboard, ModalController, NavController, NavParams, Platform, Select } from "ionic-angular";
import { Celular, Clientes, Empresa, Endereco, Sequence, Telefone } from "../../class/class.cliente";
// import { ShrinkingSegmentHeader } from './../../components/shrinking-segment-header/shrinking-segment-header';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { Email, Tipo } from "./../../class/class.cliente";
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

@IonicPage()
@Component({
  selector: "page-cliente",
  templateUrl: "cliente.html"
})
export class Cliente {

  @ViewChild("input") search: any;
  // @ViewChild("email") email: any;
  // @ViewChild("rg") rg: any;

  @ViewChild("campo1") campo1;  // campo nome
  @ViewChild("campo2") campo2;  // campo rg
  @ViewChild("campo3") campo3;  // campo email
  @ViewChild("campo4") campo4;  // campo celular
  @ViewChild("campo5") campo5;  // campo CEP 
  @ViewChild("campo6") campo6;  // campo numero
  @ViewChild("campo7") campo7;  // campo complemento
  @ViewChild("campo8") campo8;  // campo Endereço
  @ViewChild("campo9") campo9;  // campo Telefone
  // by Ryuge 20/09/2019
  @ViewChild("campo10") campo10;  // campo Bairro
  @ViewChild("campo11") campo11;  // campo Cidade
  @ViewChild("campo12") campo12;  // campo Estado

  @ViewChild('mySelect') selectRef: Select; // profissao

  @ViewChild(Content) content: Content;  // by ryuge 19/10/2018	


  public valorDigitado: any;

  // 
  isName: boolean = true;
  isId: boolean = true;
  isEmail: boolean = true;
  isPhone: boolean = true;
  isTelefone: boolean = true; // by Ryuge
  isNumber: boolean = true;
  isCep: boolean = true;
  isProf: boolean = true;
  isActive: string;

  isActiveField1: boolean = false;
  isActiveField2: boolean = false;
  isActiveField3: boolean = false;
  isActiveField4: boolean = false;
  // by Ryuge 17/09/2019
  isActiveField5: boolean = false;

  field1: string = 'nome';
  field2: string = 'email';
  field3: string = 'celular';
  field4: string = 'telefone';

  item;
  loading: any;
  public pos: number = 0;

  private mode: any = 0; // by Ryuge 20/11/2019

  public SelectedAcivated: boolean = false;
  // controle background color content
  public isWhite: boolean = true;
  public isBlue: boolean = false;
  public isGreen: boolean = false;
  public isOrange: boolean = false;
  public isGLight: boolean = false;

  public disabled;
  public show: boolean = false;
  public validarCliente: boolean = false;
  public question: string;
  public DocCliente: string;

  public dataCliente: DataCli;
  public cliente: Clientes;
  public seq1: Sequence;
  public seq2: Sequence;
  public seq3: Sequence; // by Ryuge 16/09/2019
  public enderecos: Endereco;
  public telefones: Telefone;
  public celulares: Celular;
  public emails: Email;
  public empresa: Empresa;
  public tipo: Tipo;

  public profissoes: any[];
  public dados;
  public seq: Sequence;
  public retornar;
  public changed: boolean = false;
  public exibeDados: boolean = false;

  public seletedId: any;
  public isCNPJ: boolean;
  public msg: string;
  public finalizar: boolean = false;
  public existDados: boolean = false;
  public atualizaCadastro: boolean = false;
  public exibeCadastro: boolean = false;
  public novoCadastro: boolean = false;
  public labelButton: string;
  public aEmail: any;
  public aCelular: any;
  public aTelefone: any;
  private CEP: any;
  callback: any;

  public pedido: any;
  public dadosEndereco: any;


  // by Helio 27/12/2019
  public novoPedidoEntrega: boolean = false;

  constructor(
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public navCtrl: NavController,
    public Keyb: Keyboard,
    public navParams: NavParams,
    public platform: Platform,
    private alertCtrl: AlertController,
    public http: Http,
    public modalCtrl: ModalController,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.dataCliente = new DataCli();
    this.cliente = new Clientes();
    this.seq1 = new Sequence();
    this.seq2 = new Sequence();
    this.seq3 = new Sequence();
    this.empresa = new Empresa();
    this.emails = new Email();
    this.celulares = new Celular();
    this.telefones = new Telefone();
    this.tipo = new Tipo();

    this.retornar = this.navParams.get("back");
    this.pedido = this.navParams.get("pedido");
    this.finalizar = this.navParams.get("finalizar");
    this.callback = this.navParams.get("callback");

    this.novoPedidoEntrega = this.navParams.get("pedidoEntrega")

    // by Ryuge 20/11/2019
    this.mode = this.navParams.get("mode");

    if (this.retornar == "ProdutoDetalhe") {
      this.item = this.navParams.data.item;
    }
    this.color(1);

    // if (
    //   this.commonServices.docCliente != "" &&
    //   this.commonServices.docCliente != null
    // ) {

    //   this.validarCliente = true;
    //   this.loading = true;
    //   this.limpaCampos();
    //   this.valorDigitado = this.commonServices.docCliente;
    //   this.getCliente();

    //   // by Ryuge 17/09/2019
    //   this.isPhone = this.dataCliente.celular == '';
    //   this.isTelefone = this.dataCliente.telefone == '';

    //   this.loading = false;
    //   this.SelectedAcivated = true;

    // } else {
    //   this.validarCliente = false;
    //   setTimeout(() => {
    //     this.search.setFocus();
    //   }, 500);
    // }

  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ionViewDidEnter() {
    this.goToFullScreen();

    if (
      this.commonServices.docCliente != "" &&
      this.commonServices.docCliente != null
    ) {

      this.validarCliente = true;
      this.loading = true;
      this.limpaCampos();
      this.valorDigitado = this.commonServices.docCliente;
      this.getCliente();

      // by Ryuge 17/09/2019
      this.isPhone = this.dataCliente.celular == '';
      this.isTelefone = this.dataCliente.telefone == '';

      this.loading = false;
      this.SelectedAcivated = true;

    } else {
      this.validarCliente = false;
      setTimeout(() => {
        this.search.setFocus();
      }, 500);
    }

    // this.color(1);
    // this.getProfissoes();

    // if (
    //   this.commonServices.docCliente != "" &&
    //   this.commonServices.docCliente != null
    // ) {

    //   this.validarCliente = true;
    //   this.loading = true;
    //   this.limpaCampos();
    //   this.valorDigitado = this.commonServices.docCliente;
    //   this.getCliente();

    //   // by Ryuge 17/09/2019
    //   this.isPhone = this.dataCliente.celular == '';
    //   this.isTelefone = this.dataCliente.telefone == '';

    //   this.loading = false;
    //   this.SelectedAcivated = true;

    // } else {
    //   this.validarCliente = false;
    //   setTimeout(() => {
    //     this.search.setFocus();
    //   }, 500);
    // }
  }


  isEmptyObject(obj) {
    return Object.keys(obj).length > 0;
  }


  getFocusNome() {
    setTimeout(() => {
      this.campo1.setFocus();
    }, 150);
  }

  getFocusEmail() {
    setTimeout(() => {
      this.campo3.setFocus();
    }, 150);
  }

  getFocusPhone() {
    setTimeout(() => {
      this.campo4.setFocus();
    }, 150);
  }

  // by Ryuge 16/09/2019
  getFocusTel() {
    setTimeout(() => {
      this.campo9.setFocus();
    }, 150);
  }

  getFocusCEP2() {
    setTimeout(() => {
      this.campo5.setFocus();
    }, 150);
  }

  getFocusCEP(e) {
    this.isCep = e == '';
    setTimeout(() => {
      this.campo5.setFocus();
    }, 150);
  }

  validateFieldNome(e: any) {

    this.isName = true;
    this.isName = e == '';

    console.log(this.isName);
    if (this.isName) {
      this.field1 = 'nome obrigatório';
      this.isActiveField1 = true;
      // this.getFocusNome();
    };

  }

  validateFieldEmail(e: any) {

    this.isEmail = e == '';

    // if (this.isEmail) {
    //   this.field2 = 'email obrigatório';
    //   this.isActiveField2 = true;
    // } else {

    if (e != '') {
      this.isEmail = !this.commonServices.validateEmail(e);
      this.campo3.value = this.commonServices.LowCaseString(e);

      if (this.isEmail) {
        this.field2 = 'email inválido';
        this.isActiveField2 = true;
      }

    }
    // }

  }

  validateFieldPhone(e: any) {

    this.isPhone = e == '';

    if (this.isPhone) {
      this.field3 = 'celular obrigatório';
      this.isActiveField3 = true;
      this.isTelefone = true; // by Ryuge 16/09/2019
    } else {
      this.field3 = 'celular';
      this.isActiveField3 = false;
      let numero: any = e;
      // by Ryuge 16/09/2019
      if (numero != null) {
        this.isPhone = !this.commonServices.validarNumeroCelular(numero);
        this.isTelefone = false; // by Ryuge 16/09/2019
      }


      console.log(this.commonServices.validarNumeroCelular(numero));

      if (this.isPhone) {
        this.field3 = 'celular inválido';
        this.isActiveField3 = true;
      }
    }

  }

  // by Ryuge 16/09/2019
  validateFieldTelefone(e: any) {
    this.isTelefone = e == '';
    // let numero: any = e;
    // this.isTelefone = numero != '';

    console.log('validateFieldTelefone');
    console.log(this.isTelefone);
    if (this.isTelefone) {
      this.isPhone = true;
      this.isActiveField3 = true;
    } else {
      this.isPhone = false;
      this.isActiveField3 = false;
    }

  }

  limpaCampos() {
    this.dataCliente.nome = "";
    this.dataCliente.identidade = "";
    this.dataCliente.profissao = "";
    this.seletedId = "";
    this.dataCliente.email = "";
    this.dataCliente.celular = "";
    this.dataCliente.telefone = ""; // by Ryuge 16/09/2019
    this.dataCliente.cep = "";
    this.dataCliente.numero = "";
    this.dataCliente.complemento = "";
  }

  addNewCliente() {
    // this.color(1);
    this.labelButton = 'Cadastrar novo cliente';


    // console.log(this.valorDigitado)
    // let identificador = this.valorDigitado.replace(/\D/g, "");

    // if (!this.isCNPJ) {
    //   this.navCtrl.push("ClienteNovoPage", { tipoCadastro: "novo", tipoCliente: "cpf", cpf: identificador })
    // }
    // else {
    //   this.navCtrl.push("ClienteNovoPage", { tipoCadastro: "novo", tipoCliente: "cnpj", cnpj: identificador })
    // }

    console.log(this.valorDigitado)
    let identificador = this.valorDigitado.replace(/\D/g, "");

    if (this.novoPedidoEntrega) {
      if (!this.isCNPJ) {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "novo",
          tipoCliente: "cpf",
          cpf: identificador,
          pedidoEntrega: true
        })
      }
      else {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "novo",
          tipoCliente: "cnpj",
          cnpj: identificador,
          pedidoEntrega: true
        })
      }

    }
    else {
      if (!this.isCNPJ) {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "novo",
          tipoCliente: "cpf",
          cpf: identificador
        })
      }
      else {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "novo",
          tipoCliente: "cnpj",
          cnpj: identificador
        })
      }
    }

  }

  // by Ryuge 03/12/2018
  scrollTo(element: string) {
    let yOffset = document.getElementById(element).offsetTop;
    this.content.scrollTo(0, yOffset, 200);
    this.content.resize();
  }


  popUp(msg) {
    let prompt = this.alertCtrl.create({
      title: "Atenção!",
      message: msg,
      buttons: [
        {
          text: "Cancelar",
          handler: data => {
            console.log("Cancelado");
          }
        },
        {
          text: "Cadastrar",
          handler: data => {
            this.novoCadastro = true;
            this.exibeDados = true;
            this.labelButton = 'Cadastrar novo cliente';
          }
        }
      ],
      cssClass: "alertCustomCss"
    });

    prompt.present()

  }


  // ionViewDidLoad() {
  //   // this.SelectedAcivated = true;
  // }


  // by Helio 08/10/2019
  // mascara dinamica
  dynamicMask(inputName: string) {
    console.log("dynamic")
    if (this.valorDigitado.length > 2) {
      if (inputName == "cli") {
        if (this.valorDigitado != "" || this.valorDigitado != undefined) {
          let valorDigitado = this.valorDigitado.replace(/\D/g, '');
          console.log("Valor aqui!")
          console.log(valorDigitado)
          this.valorDigitado = this.commonServices.formata(valorDigitado, "CPFCGC")
        }
      }
    }

  }



  async getCliente() {
    let event = this.valorDigitado.replace(/\D/g, '');
    this.loading = true;

    try {

      let doc: any;

      // this.search.value = this.commonServices.formata(event.target.value, "CPFCGC");
      // this.DocCliente = this.search.value;

      if (this.commonServices.docCliente != "" &&
        this.commonServices.docCliente != null) {
        doc = this.commonServices.docCliente;
        this.dataCliente.cgccpf = doc;
        this.color(5);
      } else {

        this.isName = false;
        this.isId = false;
        this.isEmail = false;
        // this.isPhone = false;
        // this.isTelefone = false;

        // by Ryuge 17/09/2019
        this.isPhone = this.dataCliente.celular == '';
        this.isTelefone = this.dataCliente.telefone == '';

        this.isNumber = false;
        this.isCep = true;
        this.isProf = true;
        this.isActive = '';

        this.msg = "Encontramos seu cliente!";
        doc = event;
        this.dataCliente.cgccpf = doc;
        this.color(1);
      }

      // by RYUGE 01/11/2019
      await this.httpUtilProvider.getNoAlert(
        ENV.WS_CRM + API_URL + "cliente/" + doc).then((result) => {
          this.dados = result;

          console.log(this.dados);
          // by RYUGE 01/11/2019
          if (this.dados) {

            this.exibeDados = true;
            this.commonServices.dadosCliente = this.dados;

            // by Ryuge 05/09/2019
            this.isActive = this.dados.ativo;

            this.dataCliente.identidade = this.dados.identidade;
            this.dataCliente.nome = this.dados.nome;
            this.dataCliente.endereco = this.dados.endereco; // by Ryuge 16/09/2019
            this.dataCliente.numero = this.dados.numero;
            this.dataCliente.complemento = this.dados.complemento;
            this.CEP = this.dados.cep;
            this.dataCliente.cep = this.commonServices.formata(this.dados.cep, "CEP");

            this.atualizaCadastro = this.dados.atualizaCadastro;
            this.isCNPJ = this.dados.natureza != "FISICA";

            if (this.dados.tipo) {
              this.dataCliente.profissao = this.dados.tipo.description;
              this.seletedId = this.dados.tipo.id;

              console.log('PROFISSAO');
              console.log(this.dataCliente.profissao);

            }

            this.DocCliente = this.commonServices.formata(event, "CPFCGC");

            // by Ryuge 17/09/2019
            if (this.dados.emails.length > 0) {
              let valor0: any = String(this.dados.emails[0].email_site);
              if (valor0 != null || valor0 != '') {
                this.dataCliente.email = this.dados.emails[0].email_site;
              }

            }

            // by Ryuge 17/09/2019
            if (this.dados.celulares.length > 0) {
              let valor1: any = String(this.dados.celulares[0].numero);

              if (valor1.length > 8) {
                console.log('CELULAR');
                console.log(valor1.length);

                this.dataCliente.celular = this.commonServices.formata(
                  this.dados.celulares[0].ddd + this.dados.celulares[0].numero,
                  "FONE"
                );
              } else {
                this.dataCliente.celular = '';
              }
            }

            // by Ryuge 16/09/2019
            console.log('this.dados.telefones');
            console.log(this.dados.telefones);

            if (this.dados.telefones.length > 0) {
              let valor2: any = String(this.dados.telefones[0].numero);
              if (valor2.length > 7) {
                console.log('TELEFONE');
                console.log(valor2.length);

                this.dataCliente.telefone = this.commonServices.formata(
                  this.dados.telefones[0].ddd + this.dados.telefones[0].numero,
                  "FONE"
                );
              } else {
                this.dataCliente.telefone = '';
              }
            }

            console.log('isPhone & isTelefone');
            console.log(this.isPhone);
            console.log(this.isTelefone);


            let fullName = this.dados.nome.split(" ");
            let firstName = fullName[0];
            this.question = firstName + " não é o seu cliente?";


            this.labelButton = 'Salvar';
            this.show = true;

            // this.color(4);
            // this.getProfissoes();
            if (this.seletedId != "") {
              this.exibeProfissao();
            }

            this.loading = false;

            this.getCep(this.CEP);
            this.color(4);
          }
        });

    } catch (error) {
      console.log(error);
      console.log(error.json());
      // this.retornarPagina();
      if (error.status === 404) {

        // by Helio/Ryuge 05/11/2019 

        this.isName = true;
        this.isId = true;
        this.isEmail = true;
        this.isPhone = this.dataCliente.celular == '';
        this.isTelefone = this.dataCliente.telefone == '';
        this.isNumber = true;
        this.isCep = false;
        this.isProf = false;

        this.color(3);
        this.show = false;
        this.novoCadastro = true;
        this.msg = "Não encontramos o cadastro do cliente!";
        this.question = "CADASTRAR NOVO CLIENTE";
        this.valorDigitado = this.commonServices.formata(event, "CPFCGC");
        this.DocCliente = event;
        // this.popUp(this.msg);
        this.loading = false;

      } else if (error.status === 400 && error.json().detail) {
        this.loading = false;
        this.commonServices.showAlert2("Atenção!", error.json().detail);
      } else {
        this.commonServices.showAlert2("Atenção!", "Falha de processamento, tente novamente !!");
      }


    }

  }


  retornarPagina() {
    console.log('retornarPagina');
    console.log(this.isActive);

    if (this.isActive == 'N') {
      this.commonServices.showAlert2("Atenção!", "O cadastro do usuário deve ser atualizado!");
    } else {
      // by Ryuge 12/09/2019
      if (this.changed) {
        // ryuge 16/11/2018 
        if (this.retornar == "PedidoFinalizacao") {
          // this.navCtrl.pop();
          // by Ryuge 07/01/2019
          if (
            (this.commonServices.docCliente != "" &&
              this.commonServices.nomeCliente != "")
          ) {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.pedido });
          } else {
            // this.commonServices.showAlert2("Atenção!", "O Tipo de retirada ENTREGA, cliente deve ser informado!");
            this.navCtrl.push("PedidoRetirada", { modulo: 1 });
          }
        }
        if (this.retornar == "ProdutoLista") {
          this.navCtrl.push("ProdutoLista");
          // this.navCtrl.pop();
        }

        // by Ryuge 26/12/2018
        if (this.retornar == "PedidoSacola" || this.retornar == "PedidoRetirada" || this.retornar == "CartaoPedido") {
          // by Ryuge 26/12/2018
          this.navCtrl.pop();
        }
        if (this.retornar == "ProdutoDetalhe") {
          this.navCtrl.push("ProdutoDetalhe", { item: this.item, mode: 0 });
        }
      } else {
        // ryuge 07/01/2019
        if (this.retornar == "PedidoFinalizacao") {
          if (
            (this.commonServices.docCliente != "" &&
              this.commonServices.nomeCliente != "")
          ) {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.pedido });
          } else {

            // by Ryuge 20/11/2019
            if (this.mode == 0) {
              this.navCtrl.pop();
            } else {
              this.navCtrl.push("PedidoRetirada", { modulo: 1 });
            }

          }
        } else {
          // by Ryuge 07/01/2019
          if (this.retornar == "PedidoRetirada" && this.finalizar == true) {
            if (
              (this.commonServices.docCliente != "" &&
                this.commonServices.nomeCliente != "")
            ) {
              this.navCtrl.push("PedidoFinalizacao", { pedido: this.pedido });
            } else {
              this.navCtrl.pop();
            }
          } else {
            this.navCtrl.pop();
          }
        }
      }
    }
  }

  OnFocus() {
    this.scrollToBottom();
  }

  focusOn() {
    this.goToFullScreen();
    let taskScanner = setInterval(() => {
      clearInterval(taskScanner);
      // this.search.value = ""; // by RyUge 
      this.search.setFocus();
    }, 1000);
  }


  async refreshForm() {
    this.valorDigitado = "";
    this.isActive = '';
    try {
      // by Ryuge 26/12/2018  
      this.commonServices.clientSelected = false;
      this.commonServices.nomeCliente = "";
      this.commonServices.docCliente = "";
      this.commonServices.pedidoAtualizado.cliente = "";
      this.commonServices.pedidoAtualizado.seq_endereco_entrega = "";
      this.commonServices.valorFrete = 0;

      let table1: PedidoTable = new PedidoTable();
      table1.name = "cliente";
      table1.value = "";
      let aResult = [];
      aResult.push(table1);

      console.log('refreshForm');
      console.log(aResult);

      let result: any = await this.httpUtilProvider.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      );

      if (result != null) {
        this.commonServices.pedidoHeader = result;

        this.commonServices.nomeCliente = "";
        this.commonServices.docCliente = "";
        this.commonServices.pedidoAtualizado.cliente = "";
        this.commonServices.pedidoAtualizado.seq_endereco_entrega = "";
        this.commonServices.valorFrete = 0;

        this.validarCliente = false;
        this.exibeDados = false;
        this.show = false;

        this.dataCliente = new DataCli();

        this.commonServices.clientSelected = false;
        this.changed = true;
        this.color(1);

        setTimeout(() => {
          this.search.value = "";
          this.search.setFocus();
        }, 1000);
      }
    } catch (error) {
      this.commonServices.cardSelected = false;
      this.commonServices.codigoCartaoPedido = "";
    }
  }


  // by Ryuge 20/12/2018
  // edit by Helio 09/10/2019
  validar_CPF_CNPJ() {
    // by Helio 09/10/2019
    console.log("Valor digitado")
    console.log(this.valorDigitado)

    // by Ryuge 20/12/2018
    if (this.valorDigitado != '') {
      let doc = this.valorDigitado.replace(/\D/g, "");

      if (doc.length > 11) {
        if (!this.commonServices.validarCNPJ(doc)) {
          this.commonServices.showAlert2("Erro!", "Número de CNPJ inválido!");
          this.focusOn();
        } else {
          // by Ryuge 23/10/2018
          this.getCliente();
        }
      } else {
        if (!this.commonServices.validCPF(doc)) {
          this.commonServices.showAlert2("Erro!", "Número de CPF inválido!");
          this.focusOn();
        } else {
          // by Ryuge 23/10/2018
          this.getCliente();
        }
      }
    }
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }
    return idx;
  }

  // by Ryuge 10/12/2018
  validaCamposFormulario() {
    console.log(this.isActiveField2);
    console.log(this.isActiveField3);

    // by Ryuge 17/09/2019
    //  this.validateFieldEmail(this.dataCliente.email);
    this.validateFieldPhone(this.dataCliente.celular);
    this.validateFieldTelefone(this.dataCliente.telefone);

    if (
      (this.dataCliente.nome == '' || this.dataCliente.nome == undefined) ||
      // (this.dataCliente.email == '' || this.dataCliente.email == undefined) ||
      ((this.dataCliente.celular == '' || this.dataCliente.celular == undefined) &&
        (this.dataCliente.telefone == '' || this.dataCliente.telefone == undefined)) ||
      (this.dataCliente.cep == '' || this.dataCliente.cep == undefined)
    ) {
      return false;
    }
    else {
      return true;
    }

  }


  // by ryuge 06/11/2018	
  scrollToBottom() {
    setTimeout(() => {
      this.content.scrollToBottom();
    });
  }
  // by ryuge 06/11/2018	
  scrollToTop() {
    setTimeout(() => {
      this.content.scrollToTop();
    });
  }
  // by ryuge 13/11/2018	
  scrollToNext(y: number) {
    this.content.scrollTo(0, y, 200);
    this.content.resize();
  }



  getOffset(el) {
    // const rect = el.getBoundingClientRect();
    let y = document.getElementById(el).offsetTop;
    return {
      // top: rect.top + window.scrollY, left: rect.left + window.scrollX
      top: y
    };
  }


  calculatePosition(objElement, strOffset) {
    var iOffset = 0;

    if (objElement.offsetParent) {
      do {
        iOffset += objElement[strOffset];
        objElement = objElement.offsetParent;
      } while (objElement);
    }

    return iOffset;
  }



  editCadastro() {
    console.log(this.valorDigitado)
    let identificador = this.valorDigitado.replace(/\D/g, "");

    if (this.novoPedidoEntrega) {
      if (!this.isCNPJ) {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "edicao",
          tipoCliente: "cpf",
          cpf: identificador,
          dadosCli: this.dados,
          pedidoEntrega: true
        })
      }
      else {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "edicao",
          tipoCliente: "cnpj",
          cnpj: identificador,
          dadosCli: this.dados,
          pedidoEntrega: true
        })
      }

    }
    else {
      if (!this.isCNPJ) {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "edicao",
          tipoCliente: "cpf",
          cpf: identificador,
          dadosCli: this.dados
        })
      }
      else {
        this.navCtrl.push("ClienteNovoPage", {
          tipoCadastro: "edicao",
          tipoCliente: "cnpj",
          cnpj: identificador,
          dadosCli: this.dados
        })
      }
    }

  }

  saveAll() {
    this.commonServices.pedidoAtualizado.cliente = this.dataCliente.cgccpf;
    this.commonServices.pedidoAtualizado.seq_endereco_entrega = this.dataCliente.id;
    this.commonServices.nomeCliente = this.dataCliente.nome;
    this.commonServices.docCliente = this.dataCliente.cgccpf;

    let table: PedidoTable = new PedidoTable();
    table.name = "cliente";
    table.value = this.dataCliente.cgccpf;
    let aResult = [];
    aResult.push(table);

    let headers = new Headers();
    headers.append("x-auth-token", localStorage.getItem("token"));
    let options = new RequestOptions({ headers: headers });

    this.http
      .post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult,
        options
      )
      .subscribe(
        data => {
          this.changed = true;
          this.validarCliente = true;
          this.commonServices.clientSelected = true;

          if (this.novoPedidoEntrega) {
            this.disabled = false;
            return this.navCtrl.push("NovaEntrega", { item: this.commonServices.ItensPedidoAdd, modulo: 5 });
          }

          // teste
          // by Ryuge 07/01/2019
          if (this.retornar == "PedidoRetirada" && this.finalizar == true) {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.pedido });
          }

          if (this.retornar == "PedidoSacola") {

            if (this.finalizar) {

              // by Ryuge 20/11/2019
              this.navCtrl.push("FormasPagamento", {
                item: this.commonServices.ItensPedidoAdd, mode: 1
              });

            } else {
              this.navCtrl.push("PedidoSacola", { finalizar: this.finalizar });
            }



          } else if (this.retornar == "PedidoRapido") {
            // this.navCtrl.pop();

            // by Ryuge 20/11/2019
            this.navCtrl.push("FormasPagamento", {
              item: this.commonServices.ItensPedidoAdd, mode: 1
            });

          }
          else {
            if (!this.existDados) {
              this.exibeCadastro = false;
            } else {
              let itPedido;
              let idxPedido;
              if (this.commonServices.sistuacaoPedido == "A") {
                itPedido = this.commonServices.itemPedidoAberto.content;
                idxPedido = this.getIndexPedido(
                  this.commonServices.numPedido,
                  itPedido
                );
              } else {
                itPedido = this.commonServices.itemPedidoFinalizado.content;
                idxPedido = this.getIndexPedido(
                  this.commonServices.numPedido,
                  itPedido
                );
              }
            }
            // this.retornarPagina();
            // by Lucas 09/01/2019
            // if(this.retornar == "PedidoFinalizacao"){
            //   this.navCtrl.push("PedidoFinalizacao", { pedido:  this.pedido });
            // }else{
            //   this.navCtrl.push("CartaoPedido", { back: "Cliente",finalizar: this.finalizar });
            // }            

            // by Ryuge 21/11/2019
            if (this.finalizar) {
              this.navCtrl.push("CartaoPedido", { back: "Cliente", mode: 0 });
            } else {
              this.navCtrl.pop();
            }

          }
          this.disabled = false;

        },
        error => {
          this.commonServices.showAlert2(
            error.json().title,
            error.json().detail
          );

          this.validarCliente = false;
          this.commonServices.cardSelected = false;
          this.changed = false;

          this.commonServices.nomeCliente = "";
          this.commonServices.docCliente = "";
          this.commonServices.pedidoAtualizado.cliente = "";
          this.commonServices.pedidoAtualizado.seq_endereco_entrega = "";

          this.disabled = false;
          this.navCtrl.pop();
        }
      );
  }

  exibeProfissao() {
    let x = this.seletedId;
    // console.log("profissao");
    // console.log(this.profissoes);

    for (var i in this.profissoes) {
      if (this.profissoes[i].id === x) {
        console.log(this.profissoes[i].id + "," + this.profissoes[i].description);
      }
    }
  }

  async getProfissoes() {
    try {
      let result: any = await this.httpUtilProvider.get(
        ENV.WS_COMMONS + API_URL + "AreaAtuacao/list/profissoes"
      );

      this.profissoes = result.content;
      // this.profissoesFiltro = this.profissoes;
      console.log('Lista Profissoes');
      console.log(this.profissoes);

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  openSelect() {
    this.Keyb.close();
    this.isProf = true;
    this.selectRef.open();
  }


  focusOnEmail() {
    this.scrollToNext(200);
    let task = setInterval(() => {
      try {
        clearInterval(task);
        this.getFocusEmail();
      } catch (error) { }
    }, 1500);
    // this.getFocusEmail();
  }

  selected(idx: any) {

    for (var i in this.profissoes) {
      if (this.profissoes[i].id == idx) {
        this.seletedId = this.profissoes[i].id;
        console.log(
          this.profissoes[i].id + "," + this.profissoes[i].description
        );
        break;
      }
    }

    console.log('selected');
    this.isProf = true;
    // this.getFocusEmail();

    // by Ryuge 19/11/2018
    // seta focus no campo email
    // setTimeout(() => {
    //   this.campo3.setFocus();
    // }, 150);

  }

  validarEmail(e) {
    if (e.target.value != '') {
      if (!this.commonServices.validateEmail(e.target.value)) {

        this.commonServices.showToastAlert('Email inválido.');
        let task = setInterval(() => {
          clearInterval(task);
          this.campo3.value = "";
          this.campo3.setFocus();
        }, 1000);
      }
    }

  }


  async validarCep(e: any) {

    let valor = e.replace(/\D/g, ""); // remove mascara
    return await new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("X-Auth-Token", localStorage.getItem("token"));

      this.isCep = false;
      this.dataCliente.endereco = "";
      this.dataCliente.bairro = "";
      this.dataCliente.cidade = "";
      this.dataCliente.uf = "";

      this.http
        .get(
          ENV.WS_PUBLIC + API_URL + "consultaCEP/" + valor, { headers: headers }
        )
        .subscribe(
          res => {
            this.dadosEndereco = res.json();

            if (this.dadosEndereco.cep) {
              this.dataCliente.endereco = this.dadosEndereco.logradouro;
              this.dataCliente.bairro = this.dadosEndereco.bairro;
              this.dataCliente.cidade = this.dadosEndereco.cidade;
              this.dataCliente.uf = this.dadosEndereco.estado;
            }

            this.isCep = this.dadosEndereco.logradouro != '';
            console.log(this.isCep);
          },
          err => {
            console.log(err);
            this.commonServices.showToast(err.json().detail);
            // this.isCep = true;
          }
        );

      this.isCep = valor != '';

      if (!this.isCep) {
        this.isActiveField4 = true;
        this.field4 = 'cep obrigatório';
        this.scrollToNext(400);
        setTimeout(() => {
          this.campo5.setFocus();
        }, 150);
      }

    });
  }


  async getCep(e: any) {
    // this.loading = true;

    console.log('getCep');
    console.log(e);

    try {

      // this.dataCliente.endereco = "";
      // this.dataCliente.bairro = "";
      // this.dataCliente.cidade = "";
      // this.dataCliente.uf = "";

      let result: any = await this.httpUtilProvider.getNoAlert(
        ENV.WS_PUBLIC + API_URL + "consultaCEP/" + e
      );

      console.log(result);

      if (result.cep) {
        this.dataCliente.endereco = result.logradouro;
        this.dataCliente.bairro = result.bairro;
        this.dataCliente.cidade = result.cidade;
        this.dataCliente.uf = result.estado;
      }

      // this.loading = false;

      // mudou o cep
      if (!this.existDados) {
        if (result.cep != e) {
          this.dataCliente.numero = "";
          this.dataCliente.complemento = "";
        }
      }
    } catch (error) {
      // this.loading = false;
      console.log(error);
    }
  }

  async pesquisaCEP() {
    let mymodal = await this.modalCtrl.create(
      "ConsultaCep",
      { modoConsulta: false }
      , {
        showBackdrop: false,
        enterAnimation: "modal-md-slide-in",
        leaveAnimation: "modal-md-slide-out"
      }
    );
    mymodal.onDidDismiss(data => {

      console.log('PESQUISA CEP');
      console.log(data);

      if (data) {
        this.dataCliente.cep = this.commonServices.formata(data.cep, "CEP");
        this.dataCliente.endereco = data.endereco;
        this.dataCliente.numero = data.numero;
        this.dataCliente.complemento = data.complemento;
      }
    });
    await mymodal.present();
  }

  abrirConsultaCEP() {
    this.navCtrl.push("ConsultaCep");
  }

  abrirConsultaCliente() {
    console.log('TESTE');
    this.navCtrl.push("ConsultaClientePage");
  }

  color(key: number) {
    switch (key) {
      case 1:
        this.isWhite = true;
        this.isBlue = false;
        this.isOrange = false;
        this.isGreen = false;
        this.isGLight = false;
        break;
      case 2:
        this.isWhite = false;
        this.isBlue = true;
        this.isOrange = false;
        this.isGreen = false;
        this.isGLight = false;
        break;
      case 3:
        this.isWhite = false;
        this.isBlue = false;
        this.isOrange = true;
        this.isGreen = false;
        this.isGLight = false;
        break;
      case 4:
        this.isWhite = false;
        this.isBlue = false;
        this.isOrange = false;
        this.isGreen = true;
        this.isGLight = false;
        break;
      case 5:
        this.isWhite = false;
        this.isBlue = false;
        this.isOrange = false;
        this.isGreen = false;
        this.isGLight = true;
        break;

      default:
        this.isWhite = true;
        this.isBlue = false;
        this.isOrange = false;
        this.isGreen = false;
        this.isGLight = false;
        break;
    }
    // this.classname = true;
  }

}

export class DataCli {
  id: string;
  cgccpf: string;
  identidade: string;
  nome: string;
  cep: string;
  endereco: string;
  numero: string;
  complemento: string;
  bairro: string;
  cidade: string;
  uf: string;
  natureza: string;
  empresa: Empresa;
  email: string;
  ddd: string;
  celular: string;
  telefone: string;
  profissao: string;
}
