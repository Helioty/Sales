import { NgModule  } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { ShrinkingSegmentHeader } from './../../components/shrinking-segment-header/shrinking-segment-header';

import { Cliente } from './cliente';

@NgModule({
  declarations: [
    Cliente,ShrinkingSegmentHeader
  ],
  imports: [
    IonicPageModule.forChild(Cliente), PipesModule,DirectivesModule
  ],
  exports: [
    Cliente,ShrinkingSegmentHeader
  ]
})
export class  ClienteModule {}