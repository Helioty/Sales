import { Component } from "@angular/core";
import { ENV } from '@app/env';
import {
  IonicPage,
  NavController,
  NavParams,
  ViewController
} from "ionic-angular";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

/**
 * Generated class for the PedidoListaModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-pedido-lista-modal",
  templateUrl: "pedido-lista-modal.html"
})
export class PedidoListaModalPage {
  // @ViewChild('popupListaProduto') popupListaProduto: ElementRef;
  exibeProdutosPedido: boolean;
  pedidoNumero: any;
  pedido: any;
  exibeProdutos: boolean;
  produtos: any = [];
  distance: any;
  public docTipo;
  public cartaoPedido;
  public docCliente;
  public endereco;
  public entrega;
  public fakeitems: any = [1, 2];
  public skeletonLoading: boolean;
  public show: any = [];

  constructor(
    public navCtrl: NavController,
    public viewCtrl: ViewController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public navParams: NavParams,
    // public ngZone: NgZone
  ) {
    // Criado por Nicollas Bastos em 05/09/2018
    this.pedido = navParams.get("pedido");
    console.log(this.pedido);
    this.cartaoPedido = this.pedido.barCodecartaoPedido;
    if (this.pedido.cartaoPedido == 0) {
      this.cartaoPedido = "Sem Cartão";
    }
    this.docCliente = this.pedido.cgccpf_cliente;
    if (!this.docCliente) {
      this.docCliente = "Sem Cliente";
    }
    this.docTipo = this.docCliente.length > 12 ? "CNPJ" : "CPF";
    this.entrega =
      this.pedido.tipoEntrega == this.commonServices.opcaoRetirada[2];
    this.endereco = this.pedido.frete.endereco;
    if (this.endereco.length < 1) {
      this.endereco = "Não selecionado";
    }
  }

  closeModal() {
    this.viewCtrl.dismiss({ animate: false });
  }

  showAccordion(index, item) {
    // item.setElementStyle("transform", "scaleY(20vh)")
    this.show[index] = !this.show[index];
  }

  // Modificado por Nicollas Bastos em 10-09-2018
  // Metodo carrega todas as informações necessárias da lista de produtos e endereço de entrega
  async ionViewDidLoad() {
    this.exibeProdutosPedido = true;
    this.skeletonLoading = true;
    this.pedidoNumero = this.pedido.numpedido;
    try {
      if (this.pedido.totpedido > 0) {
        this.exibeProdutos = true;
      } else {
        this.exibeProdutos = false;
        // this.ngZone.run(() => {
        this.skeletonLoading = false;
        // });
        return;
      }
      // cabeçalho do pedido
      // item do pedido
      let produtosinteiro: any = await this.httpUtilProvider.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVendaItem/" +
        localStorage.getItem("empresa") +
        "/" +
        this.pedido.numpedido +
        "/itens"
      );

      if (this.pedido.frete.valor > 0) {
        let enderecos: any = await this.httpUtilProvider.get(
          ENV.WS_VENDAS + API_URL +
          "PedidoVenda/" +
          localStorage.getItem("empresa") +
          "/" +
          this.pedido.numpedido +
          "/listEnderecos"
        );

        if (enderecos.length > 0) {
          for (let end of enderecos) {
            if (end.seq_endereco == this.pedido.seqEnderecoEntrega) {
              this.endereco = end.dsc_endereco;
            }
          }
        }
      }

      if (this.show.length != this.produtos.totalElements) {
        this.show = new Array<boolean>(this.produtos.totalElements);
      }
      this.produtos = produtosinteiro.content;
    } catch (error) {
      this.exibeProdutosPedido = false;
      this.exibeProdutos = true;
      this.commonServices.showToast(error.json().detail);
    }
    // this.ngZone.run(() => {
    this.skeletonLoading = false;
    // });
  }
}
