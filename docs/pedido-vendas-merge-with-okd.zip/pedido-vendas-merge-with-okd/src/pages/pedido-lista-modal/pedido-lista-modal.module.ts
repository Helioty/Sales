import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PedidoListaModalPage } from './pedido-lista-modal';
import { PipesModule } from './../../pipes/pipes.module';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    PedidoListaModalPage,
  ],
  imports: [
    IonicPageModule.forChild(PedidoListaModalPage),
    PipesModule,TranslateModule
  ],
})
export class PedidoListaModalPageModule {}
