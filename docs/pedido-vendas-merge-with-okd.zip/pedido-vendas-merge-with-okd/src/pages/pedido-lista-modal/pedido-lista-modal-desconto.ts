import { Component, ViewChild } from '@angular/core';
import { ENV } from '@app/env';
import { AlertController, Content, IonicPage, NavController, NavParams, ToastController, ViewController } from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { AuthProvider } from '../../providers/auth/auth';
import { HttpUtilProvider } from '../../providers/http-util/http-util';
// import * as environment from './../../environments/environments';
import { CommonServices } from './../../services/common-services';

/**
 * Generated class for the PedidoListaModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-pedido-lista-modal-desconto",
  templateUrl: "pedido-lista-modal-desconto.html"
})
export class PedidoListaModalDescontoPage {
  // @ViewChild('popupListaProduto') popupListaProduto: ElementRef;
  @ViewChild(Content) content: Content;   // by ryuge 19/10/2018	
  @ViewChild("login") login;  // login field
  @ViewChild("pass") pass;  // password field

  pedido: any;
  // login = "";

  public valorDesconto: string;
  public percentualDesconto: string;
  public fakeitems: any = [1, 2];
  public skeletonLoading: boolean;
  public informacaoDesconto;
  public showInfo: boolean = false;
  public exibeLogin: boolean = false;
  public tipoEntrada: string = "info";

  timeout: any;

  constructor(
    public navCtrl: NavController,
    public viewCtrl: ViewController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public authService: AuthProvider,
    public alertCtrl: AlertController,
    public navParams: NavParams,
    public toastCtrl: ToastController,
    // public ngZone: NgZone
  ) {
    this.pedido = navParams.get("pedido");
    console.log(this.pedido);
  }

  // by Ryuge 05/12/2018
  ionViewDidLeave() {
    this.tipoEntrada = "info";
  }

  // by ryuge 27/10/2018	
  scrollTo(y: number) {
    // set the scrollLeft to 0px, and scrollTop to 500px
    // the scroll duration should take 200ms
    this.content.scrollTo(0, y, 200);
  }

  // by ryuge 27/10/2018	
  scrollToTop() {
    // Scrolls to the top, ie 0px to top.
    this.content.scrollToTop();
  }

  async ionViewDidLoad() {
    let result = await this.httpUtilProvider.get(
      ENV.WS_VENDAS+API_URL+
      "PedidoVenda/descontoInfo/" +
      localStorage.getItem("empresa") +
      "/" +
      this.pedido.numpedido
    );
    this.informacaoDesconto = result[0];
  }

  // by ryuge 05/12/2018	
  scrollToNext(y: any) {
    var element = document.getElementById("box");
    element.setAttribute('margin-top', y+'px')
  }

  // by Ryuge 10/12/2018
  focus(e){
    
    if (e == 'login') {
      setTimeout(() => {
        this.login.setFocus();
      }, 150);
    }
    this.scrollToNext(10);

    if (e == 'pass') {
      setTimeout(() => {
        this.pass.setFocus();
      }, 150);
    }
    this.scrollToNext(100);

  }

  // by Ryuge 05/12/2018
  next(e) {

    if (e == 'login') {
      setTimeout(() => {
        this.pass.setFocus();
      }, 150);
      this.scrollToNext(100);
    }

    if (e == 'pass') {
      setTimeout(() => {
        this.login.setFocus();
      }, 150);
      this.scrollToNext(10);
    }

  }

  // by Ryuge 05/12/2018
  close() {
    this.exibeLogin = false;
  }

  // by Ryuge 05/12/2018
  confirmar() {

    let login: string = this.login.value;
    let pass: string = this.pass.value;

    console.log(this.tipoEntrada);
    console.log(login.toUpperCase());
    console.log(pass);

    this.authService
      .login(login.toUpperCase(), pass.toUpperCase())
      .then(result => {
        let dados: any = result;
        // this.login = data.usuario;

        console.log(dados);

        if (dados.status == 'OK') {
          this.commonServices.showAlert2(dados.json().title, dados.json().detail);
        } else {
          if (this.tipoEntrada == "info") {
            this.exibeInformacaoDesconto(login.toUpperCase());
          } else if (this.tipoEntrada == "desconto") {
            this.insereDesconto(this.valorDesconto,login.toUpperCase() );
          }
          this. close(); // fecha tela do login // by Ryuge 12/12/2018
        }

      }, err => {
        this.commonServices.showAlert2(err.json().title, err.json().detail);
      });
  }

  showInfoDesc(){
    this.tipoEntrada = 'info';
    this.alertLogin() ; 
  }


  alertLogin() {

    this.exibeLogin = true;
    setTimeout(() => {
      this.login.setFocus();
    }, 500);

    // const prompt = this.alertCtrl.create({
    //   title: "Login",
    //   message: "Entre com o Usuario e Senha",
    //   inputs: [
    //     {
    //       id: "user",
    //       name: "usuario",
    //       placeholder: "Usuario",
    //       type: "password"

    //     },
    //     {
    //       // id: "pw",
    //       name: "senha",
    //       placeholder: "Senha",
    //       type: "password"
    //     }
    //   ],
    //   buttons: [
    //     {
    //       text: "Cancelar"
    //     },
    //     {
    //       text: "Confirmar",
    //       handler: data => {
    //         this.authService
    //           .login(data.usuario.toUpperCase(), data.senha)
    //           .then(result => {
    //             console.log(result);
    //             let dados: any = result;
    //             this.login = data.usuario;
    //             if (tipoEntrada == "info") {
    //               this.exibeInformacaoDesconto(dados.login);
    //             } else if (tipoEntrada == "desconto") {
    //               this.insereDesconto(
    //                 this.valorDesconto,
    //                 data.usuario.toUpperCase()
    //               );
    //             }
    //           }, err => {
    //             this.commonServices.showAlert2(err.json().title, err.json().detail);
    //           });
    //       }
    //     }
    //   ],
    //   cssClass: "prompts"
    // });
    // // prompt.present();

    // prompt.present()
    //   .then(() => {
    //     document.getElementById('user').focus();
    //   })
    //   .catch()

  }

  closeModal() {
    // this.scrollToTop();
    // by Ryuge 27/10/2018
    this.scrollTo(0);
    this.viewCtrl.dismiss({ animate: false });
  }

  //Alterado por Nicollas Bastos em 25/09/2018
  ajustaInputsPercentual(isPercentual: boolean) {
    clearTimeout(this.timeout);

    // by Ryuge 12/12/2018
    let totalPedido =
      this.pedido.totpedido +
      this.pedido.descontoBrinde+this.pedido.valorDesconto;

    this.timeout = setTimeout(() => {
      if (isPercentual) {
        if (this.percentualDesconto.trim().length == 0) {
          this.valorDesconto = "";
          return;
        }
        try {
          // if (this.percentualDesconto.charAt(-1) == "%") {
          //   this.percentualDesconto =
          //     this.commonServices.currency(
          //       this.percentualDesconto.slice(0, -1)
          //     ) + "%";
          // } else {
          //   this.percentualDesconto =
          //     this.commonServices.currency(this.percentualDesconto) + "%";
          // }
          
           console.log(parseFloat(this.percentualDesconto.slice(0, -1)) );

          // comentado por Ryuge 10/12/2018
          // this.valorDesconto = this.commonServices.currency(
          //   (parseFloat(this.percentualDesconto.slice(0, -1)) / 100) * this.pedido.totpedido    
          // );

          // by Ryuge 10/12/2018
          this.valorDesconto = this.commonServices.currency(
            (parseFloat(this.percentualDesconto) / 100) * totalPedido   
          );

        } catch (err) {
          // this.percentualDesconto = 0 + "%";
          this.percentualDesconto = '0';
          this.valorDesconto = "";
          this.toastCtrl
            .create({
              message: "Valor inválido!",
              duration: 2000,
              position: "middle"
            })
            .present();
          return;
        }
      } else {
        if (this.valorDesconto.trim().length == 0) {
          this.percentualDesconto = '0';
          return;
        }
        // by Ryuge 12/12/2018
        try {
          this.percentualDesconto =
            this.commonServices.currency(
              (parseFloat(this.valorDesconto) /totalPedido) * 100
            );
          this.valorDesconto = this.commonServices.currency(this.valorDesconto);
        } catch (err) {
          this.mostraToastvalorInvalido();
          return;
        }
      }
    }, 1000);
  }

  async exibeInformacaoDesconto(usuario) {
    let result = await this.httpUtilProvider.getNoJson(
      ENV.WS_VENDAS+API_URL+ "PedidoVenda/showMargens" + "?login=" + usuario
    );
    console.log('exibeInformacaoDesconto');
    console.log(result);
    if (result == "S") {
      this.showInfo = true;
    }else{
      this.commonServices.showAlert2('Atenção!', 'Usuário não autorizado.');  
    }
  }

  //Criado por Nicollas Bastos em 25/09/2018
  mostraToastvalorInvalido() {
    this.commonServices.showAlert2('Atenção!', 'Valor ou percentual deve ser informado!');  
    // this.toastCtrl
    //   .create({
    //     message: "Valor inválido!",
    //     duration: 2000,
    //     position: "middle"
    //   })
    //   .present();
  }

  // by Ryuge 06/12/2018
  // Alterado por Nicollas Bastos em 25/09/2018
  async aplicaDescontoVendedor() {

    if (this.valorDesconto == '0' || this.percentualDesconto == '0') {
      this.mostraToastvalorInvalido();
      return;
    } else if (isNaN(Number(this.valorDesconto)) || isNaN(Number(this.percentualDesconto.slice(0, -1)))) {
      this.mostraToastvalorInvalido();
      return;
    }
    
    try {
      let result: any = await this.httpUtilProvider.postNoErrorHandle(
        ENV.WS_VENDAS+API_URL+
        "PedidoVenda/aplicarDesconto/" +
        localStorage.getItem("empresa") +
        "/" +
        this.pedido.numpedido +
        "?login=" +
        localStorage.getItem("login") +
        "&desconto=" +
        this.valorDesconto,
        {}
      );
      if (result) {
        // this.toastCtrl
        //   .create({
        //     message: "Desconto inserido com sucesso!",
        //     duration: 2000,
        //     position: "bottom"
        //   })
        //   .present();
        this.commonServices.showAlert2('Atenção!', 'Desconto inserido com sucesso!');  
        this.closeModal();
      }
    } catch (error) {
      // this.commonServices.showAlert2('Atenção!', error.json().detail);  
      let toast = this.toastCtrl.create({
        message: error.json().detail,
        duration: 2000,
        position: "middle"
      });
      toast.onDidDismiss(() => {
        // this.alertLogin("desconto");
        this.tipoEntrada = 'desconto';
        this.alertLogin();
      });
      toast.present();
    }
  }

  async insereDesconto(valor, usuario) {
    if (!valor || valor == "") {
      return;
    }
    try {
      parseFloat(valor);
    } catch (err) {
      this.toastCtrl
        .create({
          message: "Valor inválido!",
          duration: 2000,
          position: "middle"
        })
        .present();
      return;
    }
    let result: any = await this.httpUtilProvider.post(
      ENV.WS_VENDAS+API_URL+
      "PedidoVenda/aplicarDesconto/" +  localStorage.getItem("empresa") +
      "/" + this.pedido.numpedido + "?login=" +  usuario + "&desconto=" +  valor, {}
    );
    if (result) {
      this.toastCtrl
        .create({
          message: "Desconto inserido com sucesso!",
          duration: 2000,
          position: "bottom"
        })
        .present();
      this.closeModal();
    }
    console.log('insereDesconto');
    console.log(result);
  }


  checkDec(el) {
    var ex = /^[1-9][\.\d]*(,\d+)?$/;

    if (ex.test(el.value) == false) {
      el.value = el.value.substring(0, el.value.length - 1);
    }
  }
}
