import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, Slides } from 'ionic-angular';
import { CommonServices } from './../../services/common-services';

// import { LoginPage } from '../../pages/login/login';
// let apiUrl: string = 'http://10.131.1.234:8585/WS-Produto/';

@IonicPage()
@Component({
  selector: 'produto-imagens',
  templateUrl: 'produto-imagens.html'
})
export class ProdutoImagens {

  item;
  public images: any;
  public bigImage: any;
  public event: any;
  
  @ViewChild(Slides) slides: Slides;

  constructor(
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    public platform: Platform
  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      this.close();
    },1);    
   

    this.item = navParams.data.item;
    this.images = this.navParams.get('images');

    console.log('ProdutoImagens');
    console.log(this.images);

    this.bigImage = this.images[0].imageGrande;

    if (!localStorage.getItem("token")) {
      navCtrl.setRoot("LoginPage");
    }
  }

  ionViewWillEnter(){
    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      this.close();
    },1);    
   
  }

  changeimage(e, img) {
    this.bigImage = img;
  }
  
  close(){
    this.navCtrl.pop();  
    // this.navCtrl.remove(2,1); 
  }

}