import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IonicImageViewerModule } from 'ionic-img-viewer';

import { ProdutoImagens } from './produto-imagens';

 
@NgModule({
  declarations: [
    ProdutoImagens,
  ],
  imports: [
    IonicPageModule.forChild(ProdutoImagens),
    IonicImageViewerModule
  ],
  exports: [
    ProdutoImagens
  ]
})
export class  ProdutoImagensModule {}