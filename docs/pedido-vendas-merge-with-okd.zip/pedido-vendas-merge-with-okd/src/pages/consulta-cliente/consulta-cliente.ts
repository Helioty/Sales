import { Component, NgZone, ViewChild } from "@angular/core";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import {
  AlertController, InfiniteScroll, IonicPage, Keyboard, NavController,
  NavParams, Platform, Searchbar
} from "ionic-angular";
// import { Headers, RequestOptions, Http } from "@angular/http";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "../../providers/http-util/http-util";
// import * as environment from "./../../environments/environments";
import { CommonServices } from "../../services/common-services";

// import { PedidoTable } from "../../class/class.pedido"


/**
 * Generated class for the ConsultaClientePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-consulta-cliente",
  templateUrl: "consulta-cliente.html"
})
export class ConsultaClientePage {
  public nomeClienteInput: any;
  public clientes: any = [];
  public fakeclientes = [1, 2, 3];
  public skeletonLoading: boolean;
  public exibeImage: boolean = true;
  public textoBottom: string;
  readonly clientesPorPagina: number = 20;
  totalPages: number;
  totalElements: number;
  nomeBusca: string;
  currentPage: number = 0;

  private filter;

  @ViewChild('searchbar') searchbar: Searchbar;
  @ViewChild(InfiniteScroll)
  infiniteScroll: InfiniteScroll;

  constructor(
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    public httpUtilProvider: HttpUtilProvider,
    public zone: NgZone,
    // public http: Http,
    public Keyb: Keyboard,
    public alertCtrl: AlertController,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);

    // // by Ryuge 26/10/2018
    // this.filter = this.navParams.get("filter");

    // if (this.filter != '') {
    //   this.exibeImage = this.navParams.get("exibeImage");
    //   console.log(this.exibeImage);
    //   this.updateSearchResults( this.filter);
    // }

  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ngOnInit() {
    let taskScanner = setInterval(() => {
      try {
        clearInterval(taskScanner);
        this.searchbar.value = "";
        this.searchbar.setFocus();
      } catch (error) { }
    }, 1000);
  }

  ionViewWillEnter() {

    this.goToFullScreen();
    
    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);

    // this.exibeImage = true;
    this.textoBottom = "Sem resultados para exibir…";
  }

  close() {
    this.navCtrl.pop();
  }

  onCancel(){
    this.exibeImage = true;
    this.filter = '';
  }

  
  closeKeyboard() {
    setTimeout(() => {
      this.Keyb.close();
    }, 500);
  }

  //Alterado por Nicollas Bastos em 25/09/2018
  updateSearchResults(e: any) {
    this.exibeImage = false;
    this.closeKeyboard();

    // console.log('updateSearchResults');
    // console.log(event);
    // console.log(this.filter);

    // if(this.filter != ''){
    //   this.nomeBusca = this.filter;
    //   // this.searchbar.value =  this.nomeBusca;
    // }else{
    //   if (e.target.value && e.target.value.length < 3) {
    //     return;
    //   }
    //   this.nomeBusca = e.target.value;
    // }

    this.nomeBusca = e.target.value;
    this.getClientePorNome(this.nomeBusca).then(() => {
      if (this.clientes.length == 0) {
        this.textoBottom = "Nenhum cliente encontrado!";
      }
    });
  }

  async getClientePorNome(nome: string) {
    
    this.closeKeyboard();
    
    this.zone.run(() => {
      this.clientes = [];
      this.exibeImage = false;
      this.skeletonLoading = true;
    });

    // alterado por Ryuge 26/10/2018

    // let result: any = await this.httpUtilProvider.getNoErrorHandle(
    //     ENV.WS_CRM + "cliente/list?search=" +  nome + "&size=" +
    //     this.clientesPorPagina +"&page=0" );

    let result: any = await this.httpUtilProvider.get(
      ENV.WS_CRM+API_URL+ "cliente/list?search=" + nome);

    console.log('getClientePorNome');        
    console.log(result);  

    this.searchbar.value = nome;
    this.exibeImage = result.numberOfElements == 0;
    
    this.zone.run(() => {
      this.totalPages = result.totalPages;
      this.totalElements = result.totalElements;
      this.skeletonLoading = false;
      this.clientes = result.content;
    });
  }

  async getAll(nome: string, page: number) {
    return await this.httpUtilProvider.get(
      ENV.WS_CRM+API_URL+
      "cliente/" +
      "list?search=" +
      nome +
      "&size=" +
      this.clientesPorPagina +
      "&page=" +
      page
    );
  }

  getAllItems(page: number) {
    this.getAll(this.nomeBusca, page)
      .then((result: any) => {
        for (let cliente of result.content) {
          this.clientes.push(cliente);
        }
        if (this.infiniteScroll) {
          this.infiniteScroll.complete();
          if (this.clientes.length == result.total) {
            this.infiniteScroll.enable(false);
          }
        }
      })
      .catch((error: any) => {
        this.commonServices.showToast(error.json().detail);
      });
  }

  getItems() {
    this.currentPage += 1;
    if (this.currentPage <= this.totalPages) {
      this.getAllItems(this.currentPage);
    }
    this.infiniteScroll.complete();    
    if (this.currentPage >= this.totalPages) {
      this.infiniteScroll.enable(false);
      this.infiniteScroll.complete();
    }
  }

  //Modificado por Nicollas Bastos em 10-09-2018
  //Função chamada quando um cliente listado é selecionado
  selecionaCliente(cliente: any) {
    let alert = this.alertCtrl.create({
      title: "Confirmar Cliente",
      message: "O seu cliente é: " + cliente.nome + "?",
      buttons: [
        {
          text: "Cancelar",
          role: "cancel"
        },
        {
          text: "Confirmar",
          handler: () => {
            this.commonServices.docCliente = cliente.cgccpf;
            this.commonServices.pedidoAtualizado.cliente = cliente.cgccpf;
            this.commonServices.pedidoAtualizado.seq_endereco_entrega = cliente.id;
            this.commonServices.nomeCliente = cliente.nome;
            this.commonServices.clientSelected = true;

            this.navCtrl.pop();
            // this.navCtrl.pop();
          }
        }
      ]
    });
    alert.present();
  }
}
