import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConsultaClientePage } from './consulta-cliente';

import { PipesModule } from './../../pipes/pipes.module';

@NgModule({
  declarations: [
    ConsultaClientePage,
  ],
  imports: [
    IonicPageModule.forChild(ConsultaClientePage),
    PipesModule
  ],
})
export class ConsultaClientePageModule {}
