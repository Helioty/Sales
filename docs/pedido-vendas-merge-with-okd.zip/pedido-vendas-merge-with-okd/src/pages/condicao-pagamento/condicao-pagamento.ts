import { Component, ViewChild } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { AlertController, IonicPage, MenuController, NavController, NavParams, Platform } from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import { Order_Summary } from '../../../pages/cart/ordersummary';
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

@IonicPage()
@Component({
  selector: 'condicao-pagamento',
  templateUrl: 'condicao-pagamento.html'
})

export class CondicaoPagamento {

  selectedItem: any;
  items: any;
  data: any;
  pedido: any;
  titulo;
  codigoCondicao;
  valorMin: number = 0;
  valorEntrada: number = 0;
  public existeFrete: boolean = false;
  // public existeEntrada:boolean = false;
  public labelEntrada;
  public back: boolean = true;

  disableAmt: any;
  buttonDisabled: any;

  @ViewChild("input") input: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    private menu: MenuController,
    public platform: Platform,
    private alertCtrl: AlertController,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);

    this.disableAmt = false;
    this.buttonDisabled = true;
    this.data = navParams.data.dados;
    this.pedido = navParams.get('pedido');

    this.labelEntrada = 'Sem entrada';
    this.codigoCondicao = navParams.get('condicao');
    this.back = navParams.get('back');

    if (this.commonServices.tipoRetirada != 'IMEDIATA') {
      this.existeFrete = true;
    }

    this.titulo = this.filterItems(this.codigoCondicao);
    this.getCondicaoPagamento(this.codigoCondicao, this.commonServices.numPedido);

  }

  filterItems(searchTerm) {

    return this.data.filter((data) => {
      return data.codigo.indexOf(searchTerm) > -1;
    });

  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  async getCondicaoPagamento(codCondicao, idPedido) {

    this.commonServices.showLoader();

    try {
      this.items = await this.httpUtilProvider.get(ENV.WS_VENDAS+API_URL+
        'condicaoPagto/list/' + localStorage.getItem('empresa') + '/' + codCondicao + '?pedido=' + idPedido)
      this.commonServices.loading.dismiss();
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }


  checkDec(el) {
    var ex = /^[1-9][\.\d]*(,\d+)?$/;

    if (ex.test(el.value) == false) {
      el.value = el.value.substring(0, el.value.length - 1);
    }
  }


  focusOn() {
    let task = setInterval(() => {
      try {
        clearInterval(task);
        this.input.value = "";
        this.input.setFocus();
      } catch (error) { }
    }, 1000);
  }

  showAlertSetFocus(titulo, msg) {
    if (msg != null) {
      let alert = this.alertCtrl.create({
        title: titulo,
        subTitle: msg,
        buttons: ['OK']
      });
      alert.present()
        .then(() => {
          this.focusOn();
        })
        .catch()
    }
  }

  async getCondicaoPagamentoComEntrada(event: any) {


    if (event.target.value > this.pedido.totpedido) {
      this.showAlertSetFocus("Valor inválido", "O valor da entrada não pode ser maior que o valor do pedido!");
      return
    };

    this.commonServices.showLoader();

    try {
      this.input.value = this.commonServices.currency(this.input.value);

      this.items = await this.httpUtilProvider.get(ENV.WS_VENDAS+API_URL+
        'condicaoPagto/list/' + localStorage.getItem('empresa') + '/' + this.codigoCondicao +
        '?pedido=' + this.commonServices.numPedido + '&valorentrada=' + parseFloat(event.target.value));

      // this.existeEntrada = true;
      this.valorEntrada = parseFloat(event.target.value);
      this.commonServices.pedidoAtualizado.valor_entrada = this.valorEntrada;
      this.commonServices.loading.dismiss();
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }


  selectPaymentOptionValue(index) {
    if (!this.items[index].status) {
      for (var v in this.items) {
        this.items[v].status = false;
      }
    }
    this.items[index].status = !this.items[index].status;
    this.items[index].valorEntrada = this.valorEntrada;
    this.selectedItem = this.items[index];

    // atualiza objeto 
    this.commonServices.pedidoAtualizado.condicao_pagto = this.selectedItem.id;
    this.commonServices.pedidoAtualizado.valor_entrada = this.valorEntrada;

    // by Ryuge 30/11/2018
    this.pedido.valorEntrada = this.items[index].valorEntrada;
    this.pedido.valorParcela = this.items[index].valorParcelas;
    this.pedido.qtdParcelas = this.items[index].qtdParcelas;
    this.pedido.condpag = this.selectedItem.id;
    this.pedido.descricao_condpag = this.titulo;

    console.log('this.pedido');
    console.log(this.pedido);

    this.buttonDisabled = null;
  }

  selectPaymentValue() {
    this.disableAmt = !this.disableAmt;

    if (this.disableAmt) {
      this.labelEntrada = 'Com entrada'
    } else {
      this.labelEntrada = 'Sem entrada'
    }

  }

  // by Ryuge 18/12/2018
  async atualizaPedido() {
    try {
      let aResult = [];

      let table: PedidoTable = new PedidoTable();
      table.name = "tipo_pagamento";
      table.value = this.commonServices.pedidoAtualizado.tipo_pagamento;
      aResult.push(table);

      if (
        this.commonServices.pedidoAtualizado.condicao_pagto != "" &&
        this.commonServices.pedidoAtualizado.condicao_pagto != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "condicao_pagto";
        table.value = this.commonServices.pedidoAtualizado.condicao_pagto;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.valor_entrada > 0 &&
        this.commonServices.pedidoAtualizado.valor_entrada != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "valorentrada";
        table.value = this.commonServices.pedidoAtualizado.valor_entrada.toString();
        aResult.push(table);
      }

      let result: any = await this.httpUtilProvider.post(
        ENV.WS_VENDAS+API_URL+
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      );

    } catch (error) {
      console.log(error);
    }

  }


  openOrderSummary() {
    // by Ryuge 18/12/2018
    try {
      this.atualizaPedido();
    }
    finally {
      this.navCtrl.push("PedidoFinalizacao", { condicao: this.selectedItem, pedido: this.pedido })
    }

  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  ionViewWillEnter() {

    this.goToFullScreen();

    // by Ryuge 10/01/2019
    this.back = this.navParams.get('back');

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);
  }

  // by Ryuge 10/01/2019
  retornarPagina() {
     this.navCtrl.pop();
  }


}
