import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { CondicaoPagamento } from './condicao-pagamento';
import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    CondicaoPagamento,
  ],
  imports: [
    IonicPageModule.forChild(CondicaoPagamento),
    PipesModule,DirectivesModule,TranslateModule
  ],
  exports: [
    CondicaoPagamento
  ]
})
export class  CondicaoPagamentoModule {}