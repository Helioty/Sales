import { NgModule } from "@angular/core";
import { IonicPageModule } from "ionic-angular";
import { PedidoFinalizacao } from "./pedido-finalizacao";
import { DirectivesModule } from "./../../directives/directives.module";
import { PipesModule } from "./../../pipes/pipes.module";
import { HideKeyboardModule } from 'hide-keyboard';
// import { ShrinkingSegmentHeader } from './../../components/shrinking-segment-header/shrinking-segment-header';
import { ExpandableHeader } from './../../components/expandable-header/expandable-header';

// import { LaddaModule } from 'angular2-ladda';

@NgModule({
    declarations: [PedidoFinalizacao,ExpandableHeader],
  imports: [
    IonicPageModule.forChild(PedidoFinalizacao),
    DirectivesModule, PipesModule,HideKeyboardModule
  ],
  exports: [
    PedidoFinalizacao,ExpandableHeader
  ]

})
export class PedidoFinalizacaoModule {}
