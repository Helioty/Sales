import { Component, HostListener, ViewChild } from "@angular/core";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import {
  AlertController,
  App, Content, IonicPage,
  Keyboard, NavController,
  NavParams, Platform, ViewController
} from "ionic-angular";
import "rxjs/add/observable/fromEvent";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from "./../../environments/environments";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

/*
 * Generated class for the PedidoFinalizacaoPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-pedido-finalizacao",
  templateUrl: "pedido-finalizacao.html",
})
export class PedidoFinalizacao {
  public button_text = "Finalizar Pedido";
  landing_title = "";
  numeroPedido;
  pedidoCab: any;
  pedidoItem;
  item: any;
  dados: any;

  public endereco;
  public enderecoEntrega: any;
  public condicao;
  public retirada;
  public pagamento;
  public qtdItens;
  public icmsRetido;
  public frete;
  public total;
  public totalPedido;
  public descontoBrinde;
  public desconto;  // by Ryuge 11/12/2018
  public pesoPedido;
  public qtdParcela;
  public parcela;
  public entrada;
  public tipoDoc;
  public tipoRetirada: string;
  public tipoEntrega;

  existeDesconto: boolean = false; // by Ryuge 11/12/2018
  existeDescontoBrinde: boolean = false;
  existeFrete: boolean = false;
  existeEntrada: boolean = false;
  exibeImagem: boolean = false;
  disabled: boolean = false;

  modulo: any = 0;

  public existClient: boolean = false;
  public cardClient: boolean = false;

  exibeProgressBar: boolean = false;
  width: number = 1;

  public progressValue: number = 0;
  public show: any = [];
  public listaViews;

  public fakeitems = [1, 2];

  @ViewChild("input") search: any;
  @ViewChild("scanner") scanned: any;
  @ViewChild(Content) content: Content;
  public skeletonLoading: boolean;
  public skeletonEndereco: boolean;

  // by Ryuge 13/12/2018
  public inFocus: boolean = true;
  private idScanner;
  subscription: Subscription
  public unregisterBackButtonAction: any;;

  constructor(
    public navCtrl: NavController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public appCtrl: App,
    private alertCtrl: AlertController,
    public keyboard: Keyboard,
    // public ngZone: NgZone,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen,
    // public http: Http
  ) {

    // by ryuge 27/09/2018
    // platform.registerBackButtonAction(() => {
    //   console.log("backPressed 1");
    // }, 1);

    this.unregisterBackButtonAction && this.unregisterBackButtonAction();

    this.existClient = this.commonServices.clientSelected;
    this.cardClient = this.commonServices.cardSelected;

    // caso forma de pagamento parcelado
    this.numeroPedido =
      this.commonServices.numPedido + "-" + this.commonServices.digitoPedido;
    this.condicao = this.navParams.get("condicao");
    this.pedidoCab = this.navParams.get("pedido");
    console.log(this.pedidoCab)

    // by Ryuge 27/09/2019
    this.modulo = this.navParams.get("modulo");

    if (this.pedidoCab.tipodoc == "CC" || this.pedidoCab.tipodoc == "C4" || this.pedidoCab.tipodoc == "DP") {
      let doc = this.pedidoCab.descricao_tipodoc;
      let text = doc.split(" ");
      this.pagamento = text[0];
      this.entrada = this.pedidoCab.valorEntrada;
      this.parcela = this.pedidoCab.valorParcela;
      this.qtdParcela = this.pedidoCab.qtdParcelas;
      this.tipoDoc = this.pedidoCab.tipodoc;
      // this.tipoEntrega = this.pedidoCab.tipoEntrega;
      // by Ryuge 03/01/2019
      this.tipoEntrega = this.commonServices.pedidoAtualizado.entrega;
      this.existeEntrada = true;

    } else {
      let doc = this.pedidoCab.descricao_tipodoc;
      let text = doc.split(" ");
      this.pagamento = text[0];

      this.tipoDoc = this.pedidoCab.tipodoc;
      this.tipoEntrega = this.pedidoCab.tipoEntrega;
      this.existeEntrada = false;
      this.qtdParcela = 0;
      this.totalPedido = this.pedidoCab.valorTotalPedido;

      console.log('TOTAL PEDIDO');
      console.log(this.pedidoCab.valorTotalPedido);
    }

    if (this.modulo != 0) {
      this.alterarTipoEntregaAux(this.commonServices.codigoTipoRetirada);
    }


  }


  ionViewDidLoad() {
    this.initializeBackButtonCustomHandler();
  }

  initializeBackButtonCustomHandler(): void {
    this.unregisterBackButtonAction = this.platform.registerBackButtonAction(function (event) {
      console.log('Prevent Back Button Page Change');
    }, 101); // Priority 101 will override back button handling (we set in app.component.ts) as it is bigger then priority 100 configured in app.component.ts file */
  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }



  async ionViewWillEnter() {

    // // by ryuge 27/09/2018
    // this.platform.registerBackButtonAction(() => {
    //   console.log("backPressed 1");
    // }, 1);

    this.goToFullScreen();

    this.cardClient = this.commonServices.cardSelected;
    // this.pedidoCab = this.navParams.get("pedido"); // by Ryuge 27/09/2019

    console.log('TESTE');
    console.log(this.pedidoCab);

    this.tipoRetirada = this.commonServices.tipoRetirada;

    // by Helio 11/02/2020
    if (this.pedidoCab.cgccpf_cliente && this.pedidoCab.cgccpf_cliente != null) {
      // console.log("cliente nao null");
      this.httpUtilProvider.getNoAlert(ENV.WS_CRM + API_URL + "cliente/" + this.pedidoCab.cgccpf_cliente).then((resu) => {
        this.commonServices.dadosCliente = resu;
      });
    }

    // console.log(this.pedidoCab);
    this.disabled = false;
    this.skeletonLoading = true;
    this.skeletonEndereco = true;
    this.existeFrete = false;

    if (this.pedidoCab.descontoBrinde > 0) {
      this.descontoBrinde = this.pedidoCab.descontoBrinde;
      this.existeDescontoBrinde = true;
    }

    // by Ryuge 11/12/2018 
    if (this.pedidoCab.valorDesconto > 0) {
      this.desconto = this.pedidoCab.valorDesconto;
      this.existeDesconto = true;
    }

    this.pesoPedido = this.pedidoCab.pesoTotal;


    this.retirada = this.commonServices.tipoRetirada;
    this.icmsRetido = this.pedidoCab.icmsRetido;
    this.qtdItens = this.pedidoCab.numitens;
    // this.frete = this.pedidoCab.frete.valor;
    // this.enderecoEntrega = this.pedidoCab.frete.endereco;
    this.tipoEntrega = this.pedidoCab.tipoEntrega;

    // by Ryuge 12/12/2018
    this.total = this.pedidoCab.totpedido - this.pedidoCab.frete.valor +
      this.pedidoCab.descontoBrinde + this.pedidoCab.valorDesconto;
    this.totalPedido = this.pedidoCab.valorTotalPedido;


    if (this.commonServices.tipoRetirada == "ENTREGA") {
      this.existeFrete = true;
      this.frete = this.commonServices.valorFrete;

      console.log("FRETE")
      console.log(this.commonServices.valorFrete)

      this.endereco = this.pedidoCab.frete.endereco;
      console.log('TESTE ENDERECO');
      console.log(this.endereco);

      // by Ryuge 26/09/2019
      let tms = localStorage.getItem("tms");
      if (tms == 'false') {

        let enderecos: any = await this.httpUtilProvider.get(
          ENV.WS_VENDAS + API_URL +
          "PedidoVenda/" +
          localStorage.getItem("empresa") +
          "/" +
          this.pedidoCab.numpedido +
          "/listEnderecos"
        ).then(result => {
          console.log('Pedido');
          console.log(result);

          console.log('TESTE PARAMETER');
          console.log(this.pedidoCab.seqEnderecoEntrega);
          console.log(this.pedidoCab);

          console.log('TESTE ENDEREÇO');
          console.log(enderecos);

          if (enderecos.length > 0) {
            for (let end of enderecos) {
              if (end.seq_endereco == this.pedidoCab.seqEnderecoEntrega) {
                this.endereco = end.dsc_endereco;
              }
            }
          }

        });

      }
      // this.ngZone.run(() => {
      this.skeletonEndereco = false;
      // });
    }

    // items do pedido
    await this.httpUtilProvider
      .getItensPedido(this.commonServices.numPedido)
      .then(result => {
        console.log('items pedido');
        console.log(result);
        this.pedidoItem = result.content;
        if (this.show.length != this.pedidoItem.totalElements) {
          this.show = new Array<boolean>(this.pedidoItem.totalElements);
        }

        // this.ngZone.run(() => {
        this.skeletonLoading = false;
        // });

      });

    // this.ngZone.run(() => {
    this.skeletonLoading = false;
    this.skeletonEndereco = false;
    // });
    this.content.resize();

  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }

  showAccordion(index, item) {
    this.show[index] = !this.show[index];
  }

  openPedidoSacola() {
    let itPedido;
    let idxPedido;
    if (this.commonServices.sistuacaoPedido == "A") {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    if (itPedido != {}) {
      // by Ryuge 29/11/2018
      this.commonServices.pedidoHeader = this.pedidoCab;
      this.navCtrl.push("PedidoSacola", {
        item: itPedido[idxPedido], mode: 4, finalizar: true
      });
    }

  }

  presentPrintModal() {
    let selectedItem: any;
    selectedItem = this.commonServices.ItensPedidoAdd;

    // console.log("presentPrintModal");
    console.log(this.commonServices.tipoRetirada);

    if (
      selectedItem.informarCliente == "S" ||
      this.commonServices.tipoRetirada == "ENTREGA"
    ) {
      if (
        (this.commonServices.docCliente == "" &&
          this.commonServices.nomeCliente == "") ||
        this.commonServices.nomeCliente == "Não Identificado"
      ) {
        this.navCtrl.push("Cliente", { back: "PedidoSacola" });
      } else {
        if (!this.commonServices.cardSelected) {
          this.navCtrl.push("CartaoPedido", { back: "PedidoSacola" });
        } else {
          if (this.commonServices.tipoRetirada == "ENTREGA") {
            this.navCtrl.push("EntregaFrete", {
              total: this.totalPedido,
              item: selectedItem
            });
          } else {
            this.finalizaPedido();
          }
        }
      }
    } else {
      if (!this.commonServices.cardSelected) {
        this.navCtrl.push("CartaoPedido", { back: "PedidoSacola" });
      } else {
        this.finalizaPedido();
      }
    }
  }

  ionViewDidLeave() {
    this.unregisterBackButtonAction && this.unregisterBackButtonAction();
    this.exibeProgressBar = false;
    // this.menu.swipeEnable(true); // by Ryuge 24/12/2018
  }

  ionViewDidEnter() {
    this.exibeProgressBar = false;
    // this.menu.swipeEnable(false); // by Ryuge 24/12/2018
    // console.log(this.navCtrl.getViews());
    this.listaViews = this.navCtrl.getViews();
  }

  presentAlert(msg) {
    let alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title:
        "Pedido: " +
        this.commonServices.numPedido +
        "-" +
        this.commonServices.digitoPedido,
      subTitle: msg,
      buttons: [
        {
          text: "Ok",
          handler: data => {
            let ststusPedido: boolean = true;
            this.navCtrl.setRoot("PedidoLista", { refresh: ststusPedido });
          }
        }
      ]
    });
    alert.present();
  }

  presentAlertCred(msg) {
    let msgs = msg.split("!")
    if (msgs.length == 3) {
      let alert = this.alertCtrl.create({
        enableBackdropDismiss: false,
        title:
          "Pedido: " +
          this.commonServices.numPedido +
          "-" +
          this.commonServices.digitoPedido,
        subTitle: msgs[0] + "! " + msgs[1],
        message: msgs[2],
        buttons: [
          {
            text: "Ok",
            handler: data => {
              let ststusPedido: boolean = true;
              this.navCtrl.setRoot("PedidoLista", { refresh: ststusPedido });
            }
          }
        ],
        cssClass: "custom-back"
      });
      alert.present();
    }
    else if (msgs.length == 2) {
      let alert = this.alertCtrl.create({
        enableBackdropDismiss: false,
        title:
          "Pedido: " +
          this.commonServices.numPedido +
          "-" +
          this.commonServices.digitoPedido,
        subTitle: msgs[0] + "!",
        message: msgs[1],
        buttons: [
          {
            text: "Ok",
            handler: data => {
              let ststusPedido: boolean = true;
              this.navCtrl.setRoot("PedidoLista", { refresh: ststusPedido });
            }
          }
        ],
        cssClass: "custom-back"
      });
      alert.present();
    }

  }


  alterarTipoEntrega() {
    // atualiza pedidoHeader 
    this.commonServices.pedidoHeader = this.pedidoCab;
    this.navCtrl.push("PedidoRetirada", { modulo: 1 });

    // let alert = this.alertCtrl.create();
    // alert.setTitle("Alterar tipo de retirada");

    // alert.addInput({
    //   type: "radio",
    //   label: "Imediata ",
    //   value: "0",
    //   checked: this.commonServices.tipoRetirada == "IMEDIATA" ? true : false
    // });

    // alert.addInput({
    //   type: "radio",
    //   label: "Posterior",
    //   value: "1",
    //   checked: this.commonServices.tipoRetirada == "POSTERIOR" ? true : false
    // });

    // alert.addInput({
    //   type: "radio",
    //   label: "Entrega",
    //   value: "2",
    //   checked: this.commonServices.tipoRetirada == "ENTREGA" ? true : false
    // });

    // alert.addButton("Cancelar");
    // alert.addButton({
    //   text: "Alterar",
    //   handler: (data: any) => {
    //     this.alterarTipoEntregaAux(data);
    //   }
    // });

    // alert.present();
  }

  async alterarTipoEntregaAux(retirada) {
    if (retirada != this.commonServices.codigoTipoRetirada) {
      let aResult = [];
      let table: PedidoTable = new PedidoTable();
      table.name = "entrega";
      table.value = this.commonServices.opcaoRetirada[retirada];
      aResult.push(table);

      await this.httpUtilProvider.atualizaPedido(
        this.commonServices.numPedido,
        aResult
      );

      this.commonServices.codigoTipoRetirada = retirada;
      this.commonServices.tipoRetirada = this.commonServices.opcaoRetirada[
        retirada
      ];
      // atualiza objeto pedidoAtualizado
      this.commonServices.pedidoAtualizado.entrega = this.commonServices.tipoRetirada;

      if (this.commonServices.tipoRetirada == "ENTREGA") {
        this.alterarEnderecoEntrega();
      } else {
        await this.httpUtilProvider.postNoErrorHandle(ENV.WS_VENDAS + API_URL +
          "PedidoVenda/" +
          localStorage.getItem("empresa") +
          "/" +
          this.commonServices.numPedido +
          "/entregaremove",
          {})
        this.openPedidoSacola();
      }
    }
  }

  alterarEnderecoEntrega() {
    // let index: number = null;

    // // by Ryuge 19/11/2018
    // this.commonServices.pedidoHeader = this.pedidoCab;
    // this.navCtrl.push("EntregaFrete", {
    //   item: this.pedidoCab, codicao: this.condicao, modulo: 1
    // });

    let tms = localStorage.getItem("tms");

    if (tms == 'true') {
      this.navCtrl.push("NovaEntrega", {
        item: this.pedidoCab, modulo: 2
      });

    } else {
      this.commonServices.pedidoHeader = this.pedidoCab;
      this.navCtrl.push("EntregaFrete", {
        item: this.pedidoCab, codicao: this.condicao, modulo: 1
      });

    }

  }

  alterarFormaPagamento() {

    //  comentado por Ryuge 04/10/2018
    // let index: number = null;
    // for (let view of this.listaViews) {
    //   if (view.id == "FormasPagamento") {
    //     index = view.index;
    //   }
    // }
    // if (index) {
    //   this.navCtrl.push("FormasPagamento", {
    //     item: this.pedidoCab, mode: 1  });      
    // }

    // implementado por Ryuge 29/11/2018  
    this.commonServices.pedidoHeader = this.pedidoCab;
    // implementado por Ryuge 04/10/2018  
    this.navCtrl.push("FormasPagamento", {
      item: this.pedidoCab, mode: 3
    });

  }

  progreeBar() {
    this.button_text = "Finalizando...";
    this.disabled = true;
    this.exibeProgressBar = true;
    var elem = document.getElementById("bar");
    var width = 0;

    var progressValue = setInterval(() => {
      if (width >= 100) {
        clearInterval(progressValue);
        this.finalizaPedido();
      } else {
        width = width + 10;
        elem.style.width = width + '%';
        // document.getElementById("value").innerHTML = width  + '%';
      }
    }, 50);
  }

  progreeBar2() {
    this.disabled = true;
    this.exibeProgressBar = true;
    var elem = document.getElementById("bar2");
    var width = 0;

    var progressValue = setInterval(() => {
      if (width >= 100) {
        clearInterval(progressValue);
        this.finalizaPedido();
      } else {
        width = width + 10;
        elem.style.width = width + '%';
        // document.getElementById("value2").innerHTML = width  + '%';
      }
    }, 50);

  }


  // by Ryuge 26/12/2018
  gravaPedido(parameters: string, body: {}) {

    return new Promise((resolve, reject) => {
      // let headers = new Headers();

      // headers.append("x-auth-token", localStorage.getItem("token"));
      // let options = new RequestOptions({ headers: headers });
      this.httpUtilProvider
        .post(parameters, body)
        .then(
          (result: any) => {
            resolve(result);
          },
          error => {
            this.commonServices.showAlert2(error.json().title, error.json().detail);
            reject(error.json());
          }
        );
    });

  }

  async finalizaPedido() {
    this.disabled = true;
    this.button_text = "Finalizando...";

    try {

      let aResult = [];

      if (
        this.commonServices.pedidoAtualizado.entrega != "" &&
        this.commonServices.pedidoAtualizado.entrega != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "entrega";
        table.value = this.commonServices.tipoRetirada;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.tipo_pagamento != "" &&
        this.commonServices.pedidoAtualizado.tipo_pagamento != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "tipo_pagamento";
        table.value = this.commonServices.pedidoAtualizado.tipo_pagamento;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.condicao_pagto != "" &&
        this.commonServices.pedidoAtualizado.condicao_pagto != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "condicao_pagto";
        table.value = this.commonServices.pedidoAtualizado.condicao_pagto;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.valor_entrada > 0 &&
        this.commonServices.pedidoAtualizado.valor_entrada != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "valorentrada";
        table.value = this.commonServices.pedidoAtualizado.valor_entrada.toString();
        aResult.push(table);
      }

      // let table: PedidoTable = new PedidoTable();
      // table.name = "cartao_pedido";
      // table.value = this.commonServices.codigoCartaoPedido;
      // aResult.push(table);

      await this.httpUtilProvider.atualizaPedido(
        this.commonServices.numPedido,
        aResult
      );

      // console.log('finalizaPedido');
      // console.log(result);

      // by Ryuge 26/12/2018
      // let status: any = await this.httpUtilProvider.post(
      //   ENV.WS_VENDAS +
      //   "PedidoVenda/finalize/" +
      //   localStorage.getItem("empresa") +
      //   "/" +
      //   this.commonServices.numPedido,
      //   {}
      // );

      // by Ryuge 26/12/2018
      let status: any = await this.gravaPedido(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/finalize/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        {}
      );

      this.commonServices.manutencaoPedido = false;
      let a = status.msg.search("crediário.")
      // console.log("-------------------------------------------------")
      // console.log(status.msg)
      // console.log(a)
      if (a != -1) {
        this.presentAlertCred(status.msg);
      }
      else {
        this.presentAlert(status.msg);
      }

    } catch (error) {

      // comentado para teste por Ryuge 19/11/2019
      // this.openPedidoSacola();

      // by Ryuge 19/11/2019 
      // obs: Precisa ser analisado e testado.
      if (error.status == 400) {
        this.commonServices.showToast(error.json().detail);
      } else {

        if (error.status == 503) {
          this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
        } else {
          if (error.detail === "É necessário cadastrar um cliente!") {
            this.showclient();
          } else {
            this.openPedidoSacola();  // ??????????? Verificar
            // this.commonServices.showToast(error);
          }
        }

      }


    }
  }

  // por ryuge 20/11/2019
  showclient() {
    this.navCtrl.push("Cliente", { back: "PedidoFinalizacao", pedido: this.pedidoCab, mode: 0 });
  }

  // por ryuge 16/11/2018 
  showCardClient() {
    this.navCtrl.push("CartaoPedido", { back: "PedidoFinalizacao" });
  }

  // by Ryuge 13/12/2018
  setCardPedido(codCard: any) {
    this.commonServices.codigoCartaoPedido = codCard;

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = this.commonServices.codigoCartaoPedido;
    aResult.push(table);

    this.httpUtilProvider
      .post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      )
      .then(data => {
        this.commonServices.dadosCliente = data;
        this.commonServices.cardSelected =
          this.commonServices.codigoCartaoPedido != "";

        this.commonServices.cardSelected = true;
        this.cardClient = this.commonServices.cardSelected;
      })
      .catch(error => {
        this.cardClient = false;
        this.commonServices.cardSelected = false;
        this.commonServices.codigoCartaoPedido = "";
      });
  }

  // by Ryuge 13/12/2018
  async getCard(event: any) {
    if (event.target && event.target.value.length >= 2) {
      let codigo: string = event.target.value;

      if (codigo.substring(0, 1) == "P") {
        this.setCardPedido(codigo);
      }
    }
  }

  // by Ryuge 13/12/2018
  focusOn() {
    let taskScanner = setInterval(() => {
      clearInterval(taskScanner);
      this.scanned.value = "";
      this.scanned.setFocus();
    }, 1000);
  }

  // by Ryuge 13/12/2018
  ngOnInit() {
    this.subscription = Observable.fromEvent(document, "keypress").subscribe(
      (e: KeyboardEvent) => {
        if (e.keyCode != 13) {
          this.idScanner += e.key;
        } else {
          this.inFocus = true;
          if (this.platform.is("ios") || this.platform.is("android")) {
            this.focusOn();
          }
        }
      }
    );
  }

  // by Ryuge 13/12/2018
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  // by Ryuge 13/12/2018
  @HostListener("window:keyup", ["$event"])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode != 13) {
      this.idScanner += event.key;
    } else {
      this.inFocus = true;
      if (this.platform.is("ios") || this.platform.is("android")) {
        this.focusOn();
      }
    }
  }
}
