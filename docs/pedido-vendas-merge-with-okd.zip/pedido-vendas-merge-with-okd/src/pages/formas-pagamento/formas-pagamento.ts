import { Component } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { IonicPage, MenuController, NavController, NavParams, Platform } from 'ionic-angular';
// let UrlImage: string = 'assets/images/06-formas_de_pagamento/';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import { Payment_Confirmation_Screen } from '../paymentMethod/paymentMethodConfirmation';
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from './../../';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

@IonicPage()
@Component({
  selector: 'formas-pagamento',
  templateUrl: 'formas-pagamento.html'
})

export class FormasPagamento {

  selected: any;
  data: any;
  items: any;
  count: number;
  dadosCondicao: any;

  public existeFrete: boolean = false;
  public modePageReturn;
  private mode: any = 0;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    private menu: MenuController,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.mode = 1;
      this.retornarPagina();
    }, 1);

    this.data = this.navParams.get('item');
    this.mode = this.navParams.get('mode');
    console.log('DADOS PEDIDO');
    console.log(this.data);   

    if (this.commonServices.tipoRetirada != 'IMEDIATA') {
      this.existeFrete = true;
    }

  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }


  ionViewWillEnter() {

    this.goToFullScreen();

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.selected = this.commonServices.tipoDocumento;

    // console.log('ionViewWillEnter');
    // console.log(this.selected);

    this.getFormaPagamento(this.commonServices.numPedido);
  }

  async getFormaPagamento(idPedido) {

    // this.commonServices.showLoader();

    try {
      this.items = await this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
        'condicaoPagto/list/' + localStorage.getItem('empresa') + '?pedido=' + idPedido)

      this.count = this.items.length;
      // this.commonServices.loading.dismiss();
    } catch (error) {
      // this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }


  async atualizaPedido() {
    try {
      let aResult = [];

      let table: PedidoTable = new PedidoTable();
      table.name = "tipo_pagamento";
      table.value = this.commonServices.pedidoAtualizado.tipo_pagamento;
      aResult.push(table);

      let result: any = await this.httpUtilProvider.post(
        ENV.WS_VENDAS +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      );

    } catch (error) {
      console.log(error);
    }

  }


  atualizaCondicaoPagamento() {
    let aResult = [];
    if (
      this.commonServices.pedidoAtualizado.tipo_pagamento != "" &&
      this.commonServices.pedidoAtualizado.tipo_pagamento != undefined
    ) {

      console.log('atualizaCondicaoPagamento - 1');
      console.log(this.commonServices.pedidoAtualizado.tipo_pagamento);

      let table: PedidoTable = new PedidoTable();
      table.name = "tipo_pagamento";
      table.value = this.commonServices.pedidoAtualizado.tipo_pagamento;
      aResult.push(table);

       this.httpUtilProvider.atualizaPedido(
        this.commonServices.numPedido,
        aResult
      ); 
      
      console.log('atualizaCondicaoPagamento - 2');
      console.log(aResult);
    }

  }

  // Padido Cabeçalho
  async getPedidoHeader() {
    // cabeçalho do pedido
    await this.httpUtilProvider
      .getPedido(this.commonServices.numPedido)
      .then(result => {
        this.commonServices.pedidoHeader = result;
      });
  }

   // tela condição de pagamento
  openCondicaoPagamento(it) {

    this.selected = it.codigo;
    this.commonServices.pedidoAtualizado.tipo_pagamento = this.selected;

    // by Ryuge 29/11/2018
    this.atualizaCondicaoPagamento();

    // by Ryuge 30/11/2018
    this.data.tipodoc = it.codigo;
    this.data.descricao_tipodoc = it.descricao;

    // Promise.all([this.atualizaCondicaoPagamento(), this.getPedidoHeader()]);

    console.log("TOTAL PEDIDO");
    console.log(this.dadosCondicao);

    // by Ryuge 29/11/2018
    if (this.mode == 3) {
      if (it.parcelas != 0) {
        this.commonServices.pedidoAtualizado.condicao_pagto = '';
        this.navCtrl.push("CondicaoPagamento", {
          dados: this.items, condicao: it.codigo, pedido: this.data, back:false
        });
      } else {
        this.navCtrl.push("PedidoFinalizacao", { pedido: this.data, modulo: 1 })
      }
    } else {
      if (it.parcelas != 0) {
        this.commonServices.pedidoAtualizado.condicao_pagto = '';
        this.navCtrl.push("CondicaoPagamento", {
          dados: this.items, condicao: it.codigo, pedido: this.data
        });

      } else {
        // this.navCtrl.push("PedidoFinalizacao", { pedido: this.data, condicao: it })
        this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.ItensPedidoAdd, condicao: it })
      }

    }

  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  retornarPagina() {

    console.log('retornarPagina');
    console.log(this.mode);

    switch (this.mode) {
      case 1:
        this.navCtrl.pop();
        break;
      case 2: // by Ryuge 20/11/2019
        this.navCtrl.push("PedidoRapido", { mode: 0 });        
        break;
      case 3:
        this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.pedidoHeader, modulo: 1 })
        break;
      default:
        this.navCtrl.push("PedidoSacola", {
          item: this.items, mode: 0
        });

    }
  }

  ionViewDidLoad(){

  }
}
