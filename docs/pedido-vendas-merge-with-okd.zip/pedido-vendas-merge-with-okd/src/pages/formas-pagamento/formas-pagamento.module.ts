import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { FormasPagamento } from './formas-pagamento';
import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    FormasPagamento,
  ],
  imports: [
    IonicPageModule.forChild(FormasPagamento),
    PipesModule,DirectivesModule,TranslateModule
  ],
  exports: [
    FormasPagamento
  ]
})
export class  FormasPagamentoModule {}