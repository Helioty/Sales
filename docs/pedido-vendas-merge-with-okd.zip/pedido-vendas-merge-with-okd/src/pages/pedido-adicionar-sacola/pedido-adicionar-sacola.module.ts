import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PipesModule } from './../../pipes/pipes.module';
import { PedidoAdicionarSacola } from './pedido-adicionar-sacola';
import { BrMaskerModule } from 'brmasker-ionic-3';


@NgModule({
  declarations: [
    PedidoAdicionarSacola
  ],
  imports: [
    IonicPageModule.forChild(PedidoAdicionarSacola),
    PipesModule,  BrMaskerModule
  ],
  exports: [
    PedidoAdicionarSacola
  ]
})
export class  PedidoAdicionarSacolaModule {}