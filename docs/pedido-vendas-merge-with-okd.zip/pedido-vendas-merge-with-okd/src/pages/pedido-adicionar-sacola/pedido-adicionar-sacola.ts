import {
  Component,
  ElementRef,
  QueryList,
  ViewChild, ViewChildren
} from "@angular/core";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import {
  AlertController,
  App, Content, IonicPage,
  Keyboard,
  MenuController,
  ModalController,
  NavController,
  NavParams, Platform
} from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoTable, Retiradas } from "./../../class/class.pedido";
import { PedidoCab, PedidoItens } from "./../../class/class.Pedido";
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

// class

@IonicPage()
@Component({
  selector: "pedido-adicionar-sacola",
  templateUrl: "pedido-adicionar-sacola.html"
})
export class PedidoAdicionarSacola {

  @ViewChild(Content) content: Content;   // by ryuge 19/10/2018	
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;


  item;
  dados: any;
  public idInput: any[];
  public dadosPedido;
  public headerPedido;
  public pedidoRapido: boolean;
  // private empresa;
  public pedidoItens: PedidoItens;
  public pedidoCab: PedidoCab;
  public retiradas: Retiradas;
  public pedido;
  public qty: number = 1;
  public idPedido: any;
  public exibeFinalizacao: boolean = false;
  public existEstoque: boolean = false;
  public isenabled: boolean = true;
  // public excedeEstoque: boolean = false;
  public statuPedido;
  // private status;
  private type;
  private existQtdBasket: boolean = false;
  private qtdeItemPedido: number = 0;
  // private processado: boolean = false;
  public qtdDec: number;
  private mode;

  // @ViewChild('qtde') qtd:ElementRef;
  // @ViewChild('input') input: any;


  @ViewChildren("input") input: QueryList<any>;
  skeletonLoading: boolean = false;

  public tms = localStorage.getItem("tms");
  public showOpcs: boolean = false;
  public paraEntrega: boolean = false;
  public tipoEntrega: any;
  public dadosCli: any;
  public qtdProd: number = 0;

  // TMS
  // by Helio
  @ViewChild("quantidade") quantidade;

  public dadosTMS: any;
  public opcsEntrega: any;

  public vendedorSelecionado: any;
  public opcSelecionada: any;

  public existeRetiradaLoja: boolean = false;
  public existeRetiradaDeposito: boolean = false;

  public mostraSkeletonOpcs: boolean = false;

  constructor(
    public Keyb: Keyboard,
    private alertCtrl: AlertController,
    public modalCtrl: ModalController,
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpUtilProvider: HttpUtilProvider,
    // private _http: Http,
    private menu: MenuController,
    public appCtrl: App,
    // public renderer: Renderer,
    public elementRef: ElementRef,
    // public ngZone: NgZone,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {



    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.qty = 1;

    if (!localStorage.getItem("token")) {
      navCtrl.setRoot("LoginPage");
    }

    this.item = navParams.data.item;
    console.log(this.item);
    this.headerPedido = navParams.get("headerPedido");
    this.pedidoRapido = navParams.get("pedidoRapido");
    this.type = navParams.get("type");
    this.mode = this.navParams.get("mode");

  }


  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ngOnInit() {
    // console.log('PEDIDO NOVO');
    // console.log(this.commonServices.numPedido);

    // this.pedido = this.navParams.get('dadosPedido');
    this.idPedido = this.commonServices.numPedido;
    let empresa = localStorage.getItem("empresa");

    this.pedidoItens = new PedidoItens(empresa, this.idPedido);
    this.pedidoItens.idEmpresa = parseInt(empresa);
    this.pedidoItens.numPedido = parseInt(this.idPedido);
    this.pedidoItens.idProduto = this.item.codigodigitoembalagem;
    this.pedidoItens.embalagem = Number(this.item.codigodigitoembalagem.charAt(this.item.codigodigitoembalagem.length - 1));
    this.pedidoItens.qtdTotal = 0;
    this.pedidoItens.prcUnitario = 0;
    this.pedidoItens.prcTotal = 0;

  }

  // ngAfterViewChecked() {
  //   this.scrollToBottom();
  // }

  // scrollToBottom(): void {
  //   // method used to enable scrolling
  //   this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  // }

  closeKeyboard() {
    this.resizeElementHeight('NULL');

    setTimeout(() => {
      this.Keyb.close();
    }, 500);

  }

  // by ryuge 19/10/2018	
  scrollToTop() {
    // Scrolls to the top, ie 0px to top.
    this.content.scrollToTop();
  }

  // by ryuge 19/10/2018	
  scrollToBottom(): void {
    // method used to enable scrolling
    this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  }


  // by ryuge 19/10/2018	
  scrollTo(y: number) {
    // set the scrollLeft to 0px, and scrollTop to 500px
    // the scroll duration should take 200ms
    this.content.scrollTo(0, y, 200);
    this.content.resize();
  }


  setHeightUnic(div) {
    div[0].style.height = "auto";
  }

  setHeight(div, valor) {
    for (var i = 0; i < div.length; i++) {
      div[i].style.height = valor + "vh";
    }
  }

  resizeElementHeight(tipo: any) {
    var element = document.getElementsByClassName("box");

    // Loop over matching divs
    // for (var i = 0; i < element.length; i++) {
    //   var ele = element[i];
    // }
    if (tipo == 'OPEN') {
      this.setHeight(element, 100);
    } else {
      this.setHeightUnic(element);
    }

  }

  ionViewDidLeave() {
    this.isenabled = true;
  }

  ionViewDidEnter() {
    try {
      // this.ngZone.run(() => {
      this.skeletonLoading = true;
      // });

      this.menu.swipeEnable(false);
      this.statuPedido = this.commonServices.statusPedido;

      this.qtdDec = this.item.qtdDecimal;

      // comentado por Ryuge 02/10/2019

      // this.httpUtilProvider
      //   .getEstoquePedido(
      //     this.item.codigodigitoembalagem,
      //     this.commonServices.numPedido
      //   )
      //   .then(result => {
      //     this.dados = result;
      //     this.existEstoque = parseInt(this.dados.estoque) > 0;
      // });

      // by Ryuge 02/10/2019
      // this.dados = this.navParams.get("deposito");

      //By Lucas 04/10/2019
      // if (!this.dados) {
      // by Ryuge 11/11/2019 
      try {
        this.getEstoqueDeposito();
      } catch (error) {
        this.commonServices.showAlert2("Atenção!", "Falha de processamento, tente novamente !!");
      }

      // }

      console.log('ionViewDidEnter');
      console.log(this.dados);

      // this.SetFocusOn();
    } catch (error) {
      console.log(error);
    }

    // this.ngZone.run(() => {
    this.skeletonLoading = false;
    // });

    if (this.showOpcs) {
      setTimeout(() => {
        this.quantidade.setFocus();
      }, 500);
    }

  }

  // by Lucas 04/10/2019
  async getEstoqueDeposito() {

    // by Ryuge 11/11/2019 
    await this.httpUtilProvider
      .getEstoquePedido(
        this.item.codigodigitoembalagem,
        this.commonServices.numPedido
      ).then(result => {
        this.dados = result;
        this.existEstoque = parseInt(this.dados.estoque) > 0;
        // console.log("AQUI O RETORNO")
        // console.log(this.dados);

        // console.log("ANTES DE INICIAR O FOR")
        for (let i = 0; i < this.dados.length; i++) {
          // console.log("INICIOU O FOR")
          if (this.dados[i].cdIndLoja == null) {
            // console.log("tem entrega no item " + i + "?")
            this.existeRetiradaDeposito = true
          }
          else if (this.dados[i].cdIndLoja != null) {
            // console.log("tem retirada no item " + i + "?")
            this.existeRetiradaLoja = true
          }
        }
      }
        , (error) => {
          this.commonServices.showAlert3(error.json().title, error.json().detail);
        }
      );

  }

  ionViewWillEnter() {
    // // by Helio
    this.tipoEntrega = this.commonServices.tipoRetirada
    // if (this.tipoEntrega == "ENTREGA") {
    //   this.change()
    // }

    this.goToFullScreen();

    this.content.resize(); // by ryuge 19/10/2018	

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    // this.ngZone.run(() => {
    this.skeletonLoading = true;
    // })

    // this.isenabled = true;
  }

  onValidaEstoque(qtde, estq, idx) {
    for (var i in this.dados) {
      if (i == idx) {
        // this.dados[i].qtdPedido = 1;
        if (estq < qtde) {
          this.dados[i].excedeEstoque = true;
          this.isenabled = false;
        } else {
          this.dados[i].excedeEstoque = false;
          this.isenabled = true;
        }
      }
    }


    // this.exibeFinalizacao = qtde > 0;
    // if (estq < qtde) {
    //   this.exibeFinalizacao = false;
    //   this.excedeEstoque = true;
    //   // this.commonServices.showToast('Excede estoque!');
    // }

    // by ryuge 22/11/2018
    // this.isenabled = qtde == 0;
  }


  msgErro() {
    let alert = this.alertCtrl.create({
      title: 'Atenção!',
      message: 'Informar quantidade retirada.',
      buttons: [
        {
          text: 'Ok',
          role: 'ok',
          handler: () => {
            console.log('clicked');
            // this.SetFocusOn();
          }
        }
      ]
    });
    alert.present();
  }


  validateField() {

    // função TMS
    let isValor: boolean = false;
    if (this.paraEntrega == true && this.qtdProd > 0 && this.qtdProd != null) {
      console.log("TEM ITENS PARA A ENTREGA")
      isValor = true;
    } else {
      for (var i in this.dados) {
        if (this.dados[i].qtdPedido > 0) {
          isValor = true;
        }
      };
    }

    console.log(isValor);
    return isValor;



    // função antes do TMS
    // let isValor: boolean = false;
    // for (var i in this.dados) {
    //   if (this.dados[i].qtdPedido > 0) {
    //     isValor = true;
    //   }
    // };
    // console.log(isValor);
    // return isValor;
  }

  retornarPagina() {
    // this.navCtrl.pop();

    if (this.showOpcs == true) {
      this.change()
      this.paraEntrega = false;
    }
    else {
      console.log('retornarPagina');
      console.log(this.mode);

      switch (this.mode) {
        case 1:
          this.navCtrl.push("ProdutoLista");
          break;

        case 2:
          this.navCtrl.pop();
          break;

        default:
          let status: boolean = true;
          // this.navCtrl.push("PedidoLista", { refresh: status });
          this.navCtrl.setRoot("PedidoLista", { refresh: status });
          this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
          break;
      }
    }

  }

  ProcessamentoEfetuado(value: boolean): boolean {
    this.commonServices.showToast("Produto adicionado !");
    return value;
  }


  OnFocus(e: any, idx) {

    this.goToFullScreen();

    for (var i in this.dados) {
      if (i == idx) {
        if (this.dados[i].qtdPedido < 1) {
          this.dados[i].qtdPedido = "";
        }
      }
    }

    // this.scrollToBottom();

    this.resizeElementHeight('OPEN');

    if (idx == 0) {
      this.scrollTo(0);
    } else {
      this.scrollTo(200);
    }

  }

  SetFocusOn() {
    setTimeout(() => {
      this.input.toArray()[0].setFocus();
    }, 1000);

  }

  SetFocusOn2(id: any) {
    for (var i in this.dados) {
      if (i == id) {
        this.dados[i].qtdPedido = 0;

        setTimeout(() => {
          this.input.toArray()[id].setFocus();
        }, 1000);

        break;
      }
    }

  }

  // by Helio
  addQtd(id: any) {
    console.log("Input aqui")
    console.log(this.input.toArray()[id])
    for (var i in this.dados) {
      if (i == id) {
        if (this.dados[i].estoque <= this.input.toArray()[id].value || this.dados[i].estoque < this.input.toArray()[id].value + 1) {
          if (this.dados[i].estoque < this.input.toArray()[id].value) {
            this.input.toArray()[id].value--
          }
          this.alertEstoque2(this.dados[i].estoque, this.dados[i].deposito)
        } else {
          if (this.item.qtdMinima != 0) {
            this.input.toArray()[id].value++
            this.input.toArray()[id].value = Math.ceil(this.input.toArray()[id].value / this.item.qtdMinima) * this.item.qtdMinima;
          }
          else {
            this.input.toArray()[id].value++
          }
        }
        break;
      }
    }
  }
  rmQtd(id: any) {
    console.log("Input aqui")
    console.log(this.input.toArray()[id])
    for (var i in this.dados) {
      if (i == id) {
        if (this.input.toArray()[id].value <= 0) {
          this.input.toArray()[id].value = 0
        } else {
          if (this.item.qtdMinima != 0) {
            this.input.toArray()[id].value = this.input.toArray()[id].value - this.item.qtdMinima
          }
          else {
            this.input.toArray()[id].value--
          }
        }
        break;
      }
    }
  }

  // by Helio
  mascaraDecimal(id: any) {
    setTimeout(() => {
      if (this.item.qtdMinima != 0) {
        let result = Math.ceil(this.input.toArray()[id].value / this.item.qtdMinima) * this.item.qtdMinima;
        // console.log("CEIL _________________")
        // console.log(result)
        if (result > this.dados[id].estoque) {
          this.input.toArray()[id].value = this.dados[id].estoque
        } else {
          this.input.toArray()[id].value = result
        }
      }

      try {
        let valor = parseFloat(this.input.toArray()[id].value);
        // console.log("Valor Aqui!")
        // console.log(valor)
        let n = valor.toFixed(2)
        // console.log("------------------------")
        // console.log(n)
        this.input.toArray()[id].value = parseFloat(n)
      }
      catch (error) {
        console.log(error)
      }

    }, 1000);

  }

  // by Helio
  limitaQtd(id: any) {
    setTimeout(() => {
      if (this.input.toArray()[id].value > this.dados[id].estoque) {
        this.input.toArray()[id].value = this.dados[id].estoque
      }
    }, 1000);
  }

  alertEstoque(idx: string, qtdEstq: string, depto: string) {
    let msg: string;
    if (qtdEstq == "1") {
      msg =
        "Temos apenas " + qtdEstq + " unidade disponível no depósito " + depto;
    } else {
      msg =
        "Temos apenas " +
        qtdEstq +
        " unidades disponíveis no depósito " +
        depto;
    }
    let prompt = this.alertCtrl.create({
      title: "Estoque insuficiente!",
      message: msg,
      buttons: [
        {
          text: "oK",
          handler: data => {
            this.SetFocusOn2(idx);
            // this.isenabled = true;
            // this.SetFocusOn();
            console.log("Cancelado");
          }
        }
      ],
      enableBackdropDismiss: false, // <- Here! :)
      cssClass: "alertCustomCss"
    });
    prompt.present();
  }

  // by Helio
  alertEstoque2(qtdEstq: string, depto: string) {
    let msg: string;
    if (qtdEstq == "1") {
      msg =
        "Temos apenas " + qtdEstq + " unidade disponível no depósito " + depto;
    } else {
      msg =
        "Temos apenas " +
        qtdEstq +
        " unidades disponíveis no depósito " +
        depto;
    }
    let prompt = this.alertCtrl.create({
      title: "Estoque insuficiente!",
      message: msg,
      buttons: [
        {
          text: "oK",
          handler: data => {
            console.log("Cancelado");
          }
        }
      ],
      enableBackdropDismiss: false, // <- Here! :)
      cssClass: "alertCustomCss"
    });
    prompt.present();
  }

  setValue(e: any, idx) {

    this.resizeElementHeight('NULL');

    for (var i in this.dados) {
      if (i == idx) {
        if (this.dados[i].qtdPedido < 1) {
          this.dados[i].excedeEstoque = false;
          this.dados[i].qtdPedido = 0;
        }

      }
    }
  }

  checkDec(el) {
    var ex = /^[1-9][\.\d]*(,\d+)?$/;

    if (ex.test(el.value) == false) {
      el.value = el.value.substring(0, el.value.length - 1);
    }
  }

  isNumberKey(evt) {
    var charCode = evt.which ? evt.which : evt.keyCode;
    return !(charCode > 31 && (charCode < 48 || charCode > 57));
  }

  checkInteger(el) {
    // var ex = /[0-9]/;
    var ex = /^\d+$/;

    if (ex.test(el.value) == false) {
      el.value = el.value.substring(0, el.value.length - 1);
    }
  }

  addItem(qtde) {
    this.commonServices.qtdBasketItens = qtde;
    // console.log(this.commonServices.qtdBasketItens);

    this.atualizarPedidoHearder(); // atualiza Cabecalho Pedido
    this.exibirTelaPedido();
  }

  // atualizarPedidoHearder(idPedido) {
  //   return new Promise((resolve, reject) => {
  //     let headers = new Headers();
  //     headers.append('X-Auth-Token', localStorage.getItem('token'));

  //     this.headerPedido.tipoEntrega = this.commonServices.tipoRetirada;  // atualiza o tipo de retirada
  //     this._http.post(environment.WS_VENDAS + 'PedidoVenda/' + localStorage.getItem('empresa') + '/' + idPedido, this.headerPedido, { headers: headers })
  //       .subscribe(res => {
  //         this.pedido = res.json();
  //         this.commonServices.numPedido = this.pedido.id;
  //       }, (err) => {
  //         // reject(err);
  //         this.commonServices.showToast(err);
  //       });
  //   });
  // }

  atualizarPedidoHearder() {
    let aResult = [];

    if (
      this.commonServices.pedidoAtualizado.entrega != "" &&
      this.commonServices.pedidoAtualizado.entrega != undefined
    ) {
      let table: PedidoTable = new PedidoTable();
      table.name = "entrega";
      table.value = this.commonServices.tipoRetirada;
      aResult.push(table);

      this.httpUtilProvider.atualizaPedido(
        this.commonServices.numPedido,
        aResult
      );
    }
  }

  async addItemPedido(pedidoBody) {
    let resut: any;

    try {
      console.log("addItemPedido");
      console.log(pedidoBody);

      let valorStatus: string = "";

      // if(this.type != 'N'){
      valorStatus = "?update=S";
      // }

      resut = await this.httpUtilProvider.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVendaItem/" +
        localStorage.getItem("empresa") +
        "/" +
        this.idPedido +
        valorStatus,
        pedidoBody
      );

      this.commonServices.ItensPedidoAdd = resut;

      this.addItem(resut.numitens);
      // this.commonServices.showToast(resut);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  async addItemPedidoX(pedidoBody) {
    return await new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("X-Auth-Token", localStorage.getItem("token"));

      let valorStatus: string = "";

      // if(this.type != 'N'){
      valorStatus = "?update=S";
      // }

      this.httpUtilProvider
        .post(
          ENV.WS_VENDAS + API_URL +
          "PedidoVendaItem/" +
          localStorage.getItem("empresa") +
          "/" +
          this.idPedido +
          valorStatus,
          pedidoBody
        )
        .then(
          res => {
            this.dadosPedido = res;

            // if(this.dadosPedido){
            //   this.processado =  this.ProcessamentoEfetuado(true);
            // };
          },
          err => {
            this.commonServices.showToast(err.json().detail);
          }
        );
    });
  }

  getManutencaoPedido(idPedido) {
    // cabeçalho do pedido
    try {
      // cabeçalho do pedido
      this.httpUtilProvider.getPedido(idPedido).then(result => {
        this.commonServices.qtdBasketItens = result.numitens;
      });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }


  async adicionarSacola(itemSacola) {

    // Função usada para o TMS
    try {
      this.isenabled = false;
      if (this.paraEntrega == true) {
        await this.gravaOpcoesTMS()
      }


      if (this.validaQtdEstoqueLoja()) {
        await this.addItemSacola(itemSacola);
      }
      else {
        await this.exibirTelaPedido();
      }
      // Promise.all([this.addItemSacola(itemSacola)]);
    } catch (error) {
      this.isenabled = true;
      this.commonServices.showToast(error.json().detail);
    }


    // Funcão usada antes do TMS
    // try {
    //   this.isenabled = false;
    //   this.addItemSacola(itemSacola);
    //   // Promise.all([this.addItemSacola(itemSacola)]);
    // } catch (error) {
    //   this.isenabled = true;
    //   this.commonServices.showToast(error.json().detail);
    // }

  }

  addItemSacola(itemSacola) {

    let aRetiradas: any[] = [];
    // this.ngZone.run(() => {
    this.skeletonLoading = true;
    // });

    try {
      for (var i in itemSacola) {
        if (itemSacola[i].estoque < itemSacola[i].qtdPedido) {
          this.exibeFinalizacao = false;
          // console.log("itemSacola");
          // console.log(document.getElementById(id));
          // this.SetFocusOn2(i);
          this.alertEstoque(i, itemSacola[i].estoque, itemSacola[i].deposito);
          break;
        } else {
          if (parseInt(itemSacola[i].qtdPedido) > 0) {
            this.exibeFinalizacao = true;
            this.retiradas = new Retiradas();
            this.retiradas.empresaRetirada = parseInt(itemSacola[i].empresa);
            this.retiradas.idDeposito = parseInt(itemSacola[i].deposito);
            this.retiradas.tipoRetirada = parseInt(itemSacola[i].tipoEntrega);

            this.retiradas.qtd = parseFloat(itemSacola[i].qtdPedido);
            this.retiradas.precoUnitario = this.item.prvd1;

            //add array
            aRetiradas.push(this.retiradas);
          }

          // this.isenabled = parseInt(itemSacola[i].qtdPedido) > 0;

        }
      }

      try {
        if (this.exibeFinalizacao) {
          this.pedidoItens.retiradas = aRetiradas;

          // comentado para, reabrir o pedido na lista de pedido
          // if(this.statuPedido == 'M'){
          //   this.reabrirPedido( this.commonServices.numPedido) ;
          // }

          if (this.pedidoItens.numPedido == 0 || this.pedidoItens.numPedido == null) {
            this.commonServices.showToast('ATENÇÃO! ' + this.pedidoItens.numPedido);
          }

          console.log('SACOLA');
          console.log(this.pedidoItens);

          this.addItemPedido(this.pedidoItens);

          this.existQtdBasket = true;
          this.qtdeItemPedido = this.retiradas.qtd;
          this.commonServices.sistuacaoPedido = "A"; // altera situação do pedido

          // let qtd: number = this.commonServices.qtdBasketItens;
          // this.navCtrl.push("ProdutoLista", { basket: this.existQtdBasket, mode: 1 });
        }
      } catch (error) {
        console.log(error);
        // this.commonServices.showToast(error);
      }
      // this.ngZone.run(() => {
      this.skeletonLoading = false;
      // });
    } catch (error) {
      // this.ngZone.run(() => {
      this.skeletonLoading = false;
      // });
      console.log(error);
      // this.commonServices.showToast(error);
    }
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }

  openPedidoSacola() {
    let itPedido;
    let idxPedido;
    if (this.commonServices.sistuacaoPedido == "A") {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    if (itPedido != {}) {
      this.navCtrl.push("PedidoSacola", {
        item: itPedido[idxPedido],
        modo: 0
      });
    }
  }

  exibirTelaPedido() {
    // this.navCtrl.push("PedidoSacola");
    if (this.type == "N") {
      // this.mode = 0;
      this.commonServices.exibeBotaoComprar = true;
      this.navCtrl.push("ProdutoLista", {
        basket: this.existQtdBasket,
        mode: 0
      });
    } else if (this.pedidoRapido) {
      this.navCtrl.pop();
    } else {
      this.openPedidoSacola();
    }

  }

  incrementQty(itempedido) {
    this.qty += 1;
  }

  decrementQty(itempedido) {
    this.qty = itempedido.qtdMovimentada;
    if (this.qty - 1 < 1) {
      this.qty = 1;
    } else {
      this.qty -= 1;
    }
  }

  finalizarPedido(event, item) {
    this.navCtrl.push("PedidoSacolaPage", {
      item: item
    });
  }


  // TMS - by Helio
  change() {
    this.showOpcs = !this.showOpcs
    if (this.showOpcs) {
      setTimeout(() => {
        this.quantidade.setFocus();
      }, 700);
    } else {
      this.getEstoqueDeposito()
    }
  }

  // by Helio 02/10/2019 
  // adiciona classe CSS em um objeto 
  addClass(id: string) {
    var elemento = document.getElementById(id);
    elemento.classList.add('showYesNo')
  }

  // by Helio 02/10/2019  
  // remove classe CSS de objeto 
  delClass(id: string) {
    var elemento = document.getElementById(id);
    elemento.classList.remove('showYesNo')
  }

  keyEnter() {
    this.quantidade.setBlur();
  }

  OnFocusTMS() {
    this.goToFullScreen();
    if (this.qtdProd < 1) {
      this.qtdProd = null;
    }
  }
  OnBlurTMS() {
    this.goToFullScreen();
    if (this.qtdProd < 1 || this.qtdProd == null) {
      this.qtdProd = 0;
    }
  }

  selecionaQtd() {
    setTimeout(() => {
      if (this.showOpcs) {
        if (this.qtdProd > 0 && this.qtdProd != undefined && this.qtdProd != null) {
          this.getCliente();
        }
      }
    }, 100);
  }

  async getCliente() {
    try {
      let doc: any = null;
      doc = this.commonServices.docCliente;
      if (this.commonServices.docCliente != "" && this.commonServices.docCliente != null) {
        this.dadosCli = await this.httpUtilProvider.getNoAlert(ENV.WS_CRM + API_URL + "cliente/" + doc);
        this.getOpcoesTMS()
      }
      else {
        this.showclient()
      }
    }
    catch (error) {
      console.log(error);
      console.log("Chamando cliente novamente")
      this.getCliente()
    }
  }

  showclient() {
    this.navCtrl.push("Cliente", { back: "ProdutoDetalhe", item: this.item });
  };

  async ende(seq: any, endes: any) {
    for (let i = 0; i < endes.length; i++) {
      if (endes[i].id.sequencialId == seq) {
        return endes[i]
      }
    }
  }

  async getOpcoesTMS() {
    this.mostraSkeletonOpcs = true;
    let precolocal: any;
    let hasItem = await this.validaQtdEstoqueLoja()
    if (hasItem) {
      precolocal = "S";
    } else {
      precolocal = "N";
    }

    let enderecos = this.commonServices.dadosCliente.enderecos;
    let sequen = this.commonServices.pedidoAtualizado.seq_endereco_entrega;
    let enderecoSelecionado = await this.ende(sequen, enderecos)

    // console.log("ENDERECO AQUI")
    // console.log(enderecos)
    // console.log(sequen)
    // console.log(enderecoSelecionado)

    // console.log(this.commonServices.pedidoAtualizado)
    let link: string;
    if (enderecoSelecionado.latitude && enderecoSelecionado.longitude) {
      link = ENV.WS_TMS + API_URL +
        "tms/opcoesfrete/" + localStorage.getItem("empresa") +
        "/" + this.item.codigodigitoembalagem +
        "?qtd=" + this.qtdProd +
        "&cep=" + enderecoSelecionado.ds_cep +
        "&latitude=" + enderecoSelecionado.latitude +
        "&longitude=" + enderecoSelecionado.longitude +
        "&precolocal=" + precolocal +
        "&pedido=" + this.commonServices.numPedido;
    }
    else {
      link = ENV.WS_TMS + API_URL +
        "tms/opcoesfrete/" + localStorage.getItem("empresa") +
        "/" + this.item.codigodigitoembalagem +
        "?qtd=" + this.qtdProd +
        "&cep=" + enderecoSelecionado.ds_cep +
        "&precolocal=" + precolocal +
        "&pedido=" + this.commonServices.numPedido;
    }

    console.log("LINK")
    console.log(link)
    try {
      this.dadosTMS = await this.httpUtilProvider.getTMS(link);
      console.log("opcoes entrega")
      console.log(this.dadosTMS)

      // by Helio 09/01/2020
      // Seleciona automaticamente caso exista apenas uma opção de entrega
      if (this.dadosTMS.length == 1) {
        this.vendedorSelecionado = this.dadosTMS[0];
        if (this.vendedorSelecionado.opcoes.length == 1) {
          this.opcSelecionada = this.vendedorSelecionado.opcoes[0]
        }
      }

      this.mostraSkeletonOpcs = false;
      this.paraEntrega = true;
    }
    catch (error) {
      console.log("ERRO AQUI")
      console.log(error)
      this.mostraSkeletonOpcs = false;
      if (error.detail) {
        this.commonServices.showAlert3('Atenção', error.detail);
      }
      else {
        this.commonServices.showAlert3(error.error, error.message)
      }

      this.change()
    }

    // try {
    //   console.log("opcoes entrega")
    //   console.log(this.dadosTMS)
    //   this.opcsEntrega = this.dadosTMS[0].opcoes;
    //   console.log("Opcs separadas")
    //   console.log(this.opcsEntrega)
    //   this.opcSelecionada = this.opcsEntrega[0];
    // }
    // catch (error) {

    // }


    console.log("ITEM AQUI!")
    console.log(this.item)
  }

  async gravaOpcoesTMS() {
    // atualizando pedido para o tipo entrega // 31/01/2020
    await this.atualizarPedidoHearder();
    let link = ENV.WS_VENDAS + API_URL +
      "PedidoVendaItem/" + localStorage.getItem("empresa") +
      "/" + this.commonServices.numPedido +
      "/" + this.item.codigodigitoembalagem +
      "/gravaopcaofrete?qtd=" + this.qtdProd +
      "&fator=" + this.item.conversao;
    console.log("LINK DE GRAVAÇÃO DO TMS")
    console.log(link)

    this.opcSelecionada.dataPrevista = null;
    try {
      await this.httpUtilProvider.post(link,
        this.opcSelecionada).then(data => {
          console.log("Salvou!");
          console.log(data);
          console.log("Numero do pedido")
          console.log(this.commonServices.numPedido)
        });

    }
    catch (error) {
      console.log("Erro ao grava opção frete!")
      console.log(error.json())
    }
  }

  validaQtdEstoqueLoja() {
    let result = false;
    for (var i in this.dados) {
      if (this.dados[i].qtdPedido > 0) {
        result = true;
      }
    };
    return result
  }

}
