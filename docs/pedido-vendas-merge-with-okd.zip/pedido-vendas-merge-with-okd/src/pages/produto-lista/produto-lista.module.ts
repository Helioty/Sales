// by Ryuge 18/09/2018 

import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HideKeyboardModule } from 'hide-keyboard';
import { IonicPageModule } from 'ionic-angular';

import { PipesModule } from './../../pipes/pipes.module';
import { ProdutoLista } from './produto-lista';

// Import library

@NgModule({
  declarations: [
    ProdutoLista,
  ],
  imports: [
    IonicPageModule.forChild(ProdutoLista),
    PipesModule,TranslateModule,
    HideKeyboardModule
  ],
  exports: [
    ProdutoLista
  ]
})
export class  ProdutoListaModule {}
