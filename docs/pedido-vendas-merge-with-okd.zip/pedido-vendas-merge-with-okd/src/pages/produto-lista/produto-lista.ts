// by Ryuge 18/09/2018 
import { Component, HostListener, ViewChild } from "@angular/core";
// import { Headers, Http, RequestOptions } from "@angular/http";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { BarcodeScanner } from "@ionic-native/barcode-scanner";
import { TranslateService } from "@ngx-translate/core";
import {
  AlertController, Content,
  InfiniteScroll, IonicPage,
  Keyboard, MenuController,
  NavController, NavParams,
  Platform, Slides
} from "ionic-angular";
import "rxjs/add/observable/fromEvent";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";
import { PedidoTable } from "../../class/class.pedido";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "../../providers/http-util/http-util";
import { CommonServices } from "../../services/common-services";

//class
@IonicPage()
@Component({
  selector: "produto-lista",
  templateUrl: "produto-lista.html"
})
export class ProdutoLista {
  abort: boolean = true;

  public percent: number = 0;
  public totalPages: number = 0;
  public currentPage: number = 1;
  public items: any = [];
  public fakeitems: any = [1, 2, 3, 4];
  public data: any = [];
  private itemSearch;
  public images;
  public firstSkeletonLoading: boolean = false;
  public skeletonLoading: boolean = false;
  public showsearch: boolean = true;
  public existItem: boolean = false;
  public exibeProduto: boolean = false;
  public exibeBotaoLimpar: boolean = false;
  public semResultado: boolean = true;
  private alreadyPushed: boolean = false;
  public existBasket: boolean = false;
  private scannedCode: string;
  public headerPedido;
  // public dados;
  public qtdItem: Number = NaN;
  public retirada;
  public totalElements;
  public exibeFiltro: boolean = true;
  public qtdCheckedFilter: number = 0;
  public exibeItemComEstq: boolean = true;
  public existClient: boolean = false;

  public loadingImage: boolean = false;
  public inFocus: boolean = true;
  public cardClient: boolean = false;
  public isBrowser: boolean = false;
  public codCardPedido: string;

  query: string = "";

  // variaveis filtro

  public itemFiltersResult: any;
  public itemFilters: any;
  public itemFiltersClone: any;
  public filtros: any[];
  public linhas: any[];
  public situacoes: any[];
  public filter: any;
  public line: any;
  public situation: any;

  public atributos: any[];
  public aResult: any;

  public situacaoTitle = "Todas as situações";

  public linhaTitle = "Todas as linhas";
  public filtroTitle;

  //Criado por Nicollas Bastos em 25/09/2018
  public isToggled: boolean;
  public disableToggle: boolean;

  public Show: boolean = true;
  public Hide: boolean = false;

  public Show1: boolean = true;
  public Hide1: boolean = false;
  public Show2: boolean = true;
  public Hide2: boolean = false;

  public showLevel1 = null;
  public showLevel2 = null;

  public surveyForm: any;
  private clearInput: boolean = true;

  private idScanner;
  private taskScanner;
  private mode: any = 0;
  public active: boolean = false;

  //MODO DE VIZUALIZAÇÃO
  public modoConsulta: boolean = false;

  // PEDIDO
  public cabPedido: any;
  public itemsPedido;
  public tipo;

  alertInstance: any;
  subscription: Subscription;

  keyDowns;
  keyUps;
  keyActions;

  @ViewChild("mySlider") slider: Slides;
  @ViewChild(InfiniteScroll) infiniteScroll: InfiniteScroll;
  @ViewChild("input") search: any;
  @ViewChild("scanner") scanned: any;
  @ViewChild(Content) content: Content;


  // by Helio 25/10/2019
  public pesquisa: boolean = true;

  //Alterado pro Nicollas Bastos em 25/09/2018
  constructor(
    public platform: Platform,
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    private barcodeScanner: BarcodeScanner,
    private httpUtilProvider: HttpUtilProvider,
    public translateService: TranslateService,
    private menu: MenuController,
    private alertCtrl: AlertController,
    public Keyb: Keyboard,
    // private zone: NgZone, // private broad: Broadcaster
    // public http: Http,
    private androidFullScreen: AndroidFullScreen
  ) {

    if (!localStorage.getItem("token")) {
      navCtrl.setRoot("LoginPage");
    }

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.modoConsulta = this.navParams.get("modoConsulta");
    console.log("MODO:" + this.modoConsulta);

    this.existClient = this.commonServices.clientSelected;
    this.cardClient = this.commonServices.cardSelected;

    this.existBasket = this.navParams.get("basket");
    this.retirada = this.navParams.get("tiporetirada");

    // if (this.retirada) {
    //   if (this.retirada == '2') {
    //     if (!this.existClient) {
    //       this.showclient()
    //     }
    //   }
    // }

    // this.qtdItem = this.navParams.get('qtde');
    this.commonServices.pedidoHeader = navParams.get("dados");
    this.mode = this.navParams.get("mode");

    this.tipo = this.commonServices.codigoTipoRetirada;
    this.isToggled = true;
    this.disableToggle = false;
    this.firstSkeletonLoading = true;
    // let headers = new Headers();
    // headers.append("x-auth-token", localStorage.getItem("token"));
    // let options = new RequestOptions({ headers: headers });

    window.addEventListener("contextmenu", e => {
      e.preventDefault();
    });
    // window.addEventListener('native.keyboardshow', this.keyboardHideHandler);
  }

  //  @HostListener("document:keyup", ["$event"])
  //  onkeyup(event: KeyboardEvent) {
  //   let current: string = this.el.nativeElement.value;
  //   this.commonServices.presentPrompt(current);
  //  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ionViewWillEnter() {
    this.goToFullScreen();

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    if (this.platform.is("cordova")) {
      this.isBrowser = false;
      if (this.platform.is("ios") || this.platform.is("android")) {
        this.focusOn();
      }
    } else {
      this.isBrowser = true;
    }

    console.log('isBrowser');
    console.log(this.isBrowser);

  }

  mostrarSearch() {
    this.pesquisa = !this.pesquisa;
  }


  searchOnFocus(e) {
    this.inFocus = false;
    this.goToFullScreen();
    // this.search.setValue('');
  }

  ngOnInit() {
    this.subscription = Observable.fromEvent(document, "keypress").subscribe(
      (e: KeyboardEvent) => {
        if (e.keyCode != 13) {
          this.idScanner += e.key;
        } else {
          this.active = false;
          this.inFocus = true;
          if (this.platform.is("ios") || this.platform.is("android")) {
            this.focusOn();
          }
        }
      }
    );
  }

  @HostListener("window:keyup", ["$event"])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode != 13) {
      this.idScanner += event.key;
    } else {
      this.inFocus = true;
      if (this.platform.is("ios") || this.platform.is("android")) {
        this.focusOn();
      }
    }
  }

  closeKeyboard() {
    this.inFocus = false;
    this.focusOff();
    this.Keyb.close();
    // by Ryuge 06/12/2018
    this.goToFullScreen();
    // setTimeout(() => {
    //   clearInterval(this.taskScanner);
    //   this.Keyb.close();
    // }, 500);
  }

  focusOff() {
    setTimeout(() => {
      clearInterval(this.taskScanner);
    }, 500);
  }

  focusOn() {
    this.taskScanner = setInterval(() => {
      try {
        this.scanned.value = "";
        this.scanned.setFocus();
      } catch (error) { }
    }, 300);
  }

  focusOnInput() {
    this.taskScanner = setInterval(() => {
      try {
        // this.search.value = "";
        this.search.setFocus();
      } catch (error) { }
    }, 150);
  }

  pedidoRapido() {
    this.commonServices.executaPedidoRapido = true;
    this.navCtrl.push("PedidoRapido", { mode: 1 });
  }


  ExitConfirm() {

    // comentado por Ryuge 02/10/2018 - Correçã para evitar apagar pedido com item na cesta

    // let flag = this.qtdItem == 0;
    let mensagem = this.commonServices.qtdBasketItens == 0
      ? "Pedidos sem itens serão removidos permanentemente!"
      : "";

    let numpedido = this.commonServices.numPedido;
    let alert = this.alertCtrl.create({
      title: "Deseja realmente sair do pedido?",
      message: mensagem,
      buttons: [
        {
          text: "Não",
          role: "cancel",
          handler: () => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Sim",
          handler: () => {
            if (this.commonServices.qtdBasketItens == 0) {
              this.RemoveOrder(numpedido);
            } else {
              this.navCtrl.setRoot("PedidoLista", { refresh: true });
              this.navCtrl.popToRoot(); //  reset history:
            }
          }
        }
      ]
    });
    alert.present();
  }

  async RemoveOrder(PedidoId) {
    try {
      await this.httpUtilProvider.delete(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/" +
        localStorage.getItem("empresa") +
        "/" +
        PedidoId
      );
      this.navCtrl.setRoot("PedidoLista", { refresh: true });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  retornarPagina() {

    switch (this.mode) {
      case 1:
        let itPedido;
        let idxPedido;
        if (this.commonServices.sistuacaoPedido == "A") {
          itPedido = this.commonServices.itemPedidoAberto.content;
          idxPedido = this.getIndexPedido(
            this.commonServices.numPedido,
            itPedido
          );
        } else {
          itPedido = this.commonServices.itemPedidoFinalizado.content;
          idxPedido = this.getIndexPedido(
            this.commonServices.numPedido,
            itPedido
          );
        }

        if (itPedido != {}) {
          this.navCtrl.push("PedidoSacola", {
            item: itPedido[idxPedido],
            mode: this.mode
          });
        }
        break;

      case 2:
        if (this.modoConsulta) {
          this.navCtrl.setRoot("PedidoLista");
          this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
        } else {
          this.navCtrl.pop();
        }
        break;

      default:
        // let status: boolean = true;
        // this.navCtrl.setRoot("PedidoLista", { refresh: status });
        if (this.modoConsulta && !undefined) {
          this.navCtrl.pop();
        } else {
          this.ExitConfirm();
        }
        break;
    }
  }

  // pressed() {
  //   console.log('PRESSED');
  // }

  // swipeAll(event: any): any {
  //   console.log('Swipe All', event);
  // }

  // swipeLeft(event: any): any {
  //   console.log('Swipe Left', event);
  // }

  // swipeRight(event: any): any {
  //   console.log('Swipe Right', event);
  // }

  // swipeUp(event: any): any {
  //   console.log('Swipe Up', event);
  // }

  // swipeDown(event: any): any {
  //   console.log('Swipe Down', event);
  // }

  presentAlert(msg) {
    let alert = this.alertCtrl.create({
      title: "ATENÇÃO",
      subTitle: msg,
      buttons: ["Ok"]
    });
    alert.present();
  }

  getAll(e: string, page: number) {
    return this.httpUtilProvider.get(
      ENV.WS_PRODUTO + API_URL +
      "list/" +
      localStorage.getItem("empresa") +
      "?filter=descricao:" +
      e +
      "&page=" +
      page
    );
  }

  getAllItems(page: number) {
    this.getAll(this.itemSearch, page)
      .then((result: any) => {
        console.log("Next: " + page);
        console.log(result.content);

        for (let i = 0; i < result.content.length; i++) {
          let it = result.content[i];
          this.items.push(it);
        }

        if (this.infiniteScroll) {
          console.log("aqui2");
          this.infiniteScroll.complete();
          if (this.items.length == result.total) {
            this.infiniteScroll.enable(false);
          }
        }
      })
      .catch((error: any) => {
        this.commonServices.showToast(error.json().detail);
      });
  }

  getItems(infiniteScroll) {
    this.currentPage += 1;
    if (this.currentPage <= this.totalPages) {
      this.getAllItems(this.currentPage);
    }
    infiniteScroll.complete();

    if (this.currentPage > this.totalPages) {
      infiniteScroll.enable(false);
      infiniteScroll.complete();
    }
  }

  onCancel() {
    this.linhaTitle = "Todas as linhas";
    this.exibeProduto = false;
    this.existItem = false;
    this.items = [];
    this.qtdCheckedFilter = 0;
    this.search.setValue("");
  }

  close() {
    this.linhaTitle = "Todas as linhas";
    this.existItem = false;
    this.qtdCheckedFilter = 0;

    // this.filtros = [];
    // this.linhas = [];
    // this.situacoes = [];
    // this.filter = null;
    // this.line = null;
    // this.situation = null;

    console.log("click");
    if (this.abort) {
      this.FilterProduct(this.itemSearch);
    }

    this.SendListProduct(this.itemSearch, this.itemFiltersClone);
  }

  onKeyup(event) {
    if (event.key == "Backspace" || event.keyCode == 8) {
      if (event.target.value == "") {
        // this.exibeProduto = false;
        this.existItem = false;
        this.items = [];
      }
    }
  }

  async processarConsulta(e: any) {
    try {
      var input: String = e.target.value;
    } catch (error) {
      return;
    }
    if (this.commonServices.validateScan(e.target.value)) {
      var code = this.commonServices.codeScan(e.target.value);
      let codigo = code[code.length - 1];
      this.query = input
        .substr(0, input.length - codigo.length)
        .replace("\n", "")
        .replace("\r", "");
      if (codigo[0] == "P") {
        this.setCardPedido(codigo);
        return;
      } else if (codigo.length >= 13 && codigo.length <= 16) {
        // this.zone.run(() => {
        this.items = [];
        // });
        this.getProdutoPorScanner(codigo);
        this.onCancel();
        return;
      }
    } else {
      this.itemSearch = e.target.value;

      // by Ryuge 12/09/2019 - comentado para resolver problema de processamento do banco
      // if (this.abort) {
      //   this.FilterProduct(this.itemSearch);
      // }

      if (this.itemSearch.trim() != "") {
        // this.zone.run(() => {
        //this.items = [];
        this.semResultado = false;
        this.skeletonLoading = false;
        this.content.resize();
        this.firstSkeletonLoading = false;
        // });
        this.getProdutoPorDescricao(e.target.value);
      } else {
        this.commonServices.showToast("Busca inválida");
      }
    }

    // Promise.all() allows us to send all requests at the same time.
    // let results = await Promise.all([ this.FilterProduct(this.itemSearch), this.getProdutoPorDescricao(e) ]);
  }

  async getProdutoPorDescricao(event: any) {
    try {
      console.log("getProdutoPorDescricao");
      // this.zone.run(() => {
      this.skeletonLoading = this.commonServices.exibeSkeletonLoading;
      // });

      //  this.mode = 2;
      this.clearInput = true;
      this.itemSearch = "";

      // if (event.target && event.target.value.length >= 2) {
      //   this.itemSearch = event.target.value;
      // }

      if (event.length >= 2) {
        this.itemSearch = event;
      }

      if (this.itemSearch != "") {

        // alert('teste1');

        if (isNaN(this.itemSearch)) {
          if (this.exibeItemComEstq) {

            this.httpUtilProvider._abortProcess();  // by Ryuge 29/11/2019

            this.items = await this.httpUtilProvider.get(
              ENV.WS_PRODUTO + API_URL +
              "list/" +
              localStorage.getItem("empresa") +
              "?filter=descricao:" +
              this.itemSearch
            );
            console.log("COM ESTOQUE");
            console.log(this.items);
          } else {
            this.items = await this.httpUtilProvider.get(
              ENV.WS_PRODUTO + API_URL +
              "list/" +
              localStorage.getItem("empresa") +
              "?filter=descricao:" +
              this.itemSearch +
              "&socomestq=N"
            );
            console.log("SEM ESTOQUE");
            console.log(this.items);
          }

          this.totalPages = this.items.totalPages;
          this.totalElements = this.items.totalElements;

          // this.zone.run(() => {
          this.disableToggle = false;
          this.exibeProduto = true;
          this.items = this.items.content;
          // });
        } else {

          // alert('teste2');

          let dados;
          dados = await this.httpUtilProvider.get(
            ENV.WS_PRODUTO + API_URL +
            "list/" +
            localStorage.getItem("empresa") +
            "?filter=" +
            this.itemSearch
          );

          let item: any[] = dados.content;

          if (item) {
            // this.zone.run(() => {
            // this.active = true;
            this.exibeProduto = true;
            // });
            this.ItemDetail(event, item[0]);
            this.onCancel();
          }
        }

        // this.focusOn(); // limpa campo search
        // this.zone.run(() => {
        this.skeletonLoading = false;
        this.content.resize();
        this.firstSkeletonLoading = false;
        // });
      }
    } catch (error) {

      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      // });
      // this.commonServices.showToast(error);
      // this.focusOnInput();

    }
  }

  // //Alterado por Nicollas Bastos em 25/09/2018
  // async getProdutoSemEstoque(itemSearch) {
  //   try {
  //     console.log("getProdutoSemEstoque");

  //     this.zone.run(() => {
  //       this.skeletonLoading = this.commonServices.exibeSkeletonLoading;
  //     });
  //     // this.commonServices.showLoader();

  //     this.mode = 2;
  //     this.clearInput = true;

  //     if (isNaN(this.itemSearch)) {
  //       this.items = await this.httpUtilProvider.get(
  //         ENV.WS_PRODUTO +
  //           "list/" +
  //           localStorage.getItem("empresa") +
  //           "?filter=descricao:" +
  //           itemSearch +
  //           "&socomestq=N"
  //       );

  //       this.totalPages = this.items.totalPages;
  //       this.totalElements = this.items.totalElements;

  //       this.zone.run(() => {
  //         this.disableToggle = false;
  //         this.exibeProduto = true;
  //         this.items = this.items.content;
  //       });
  //     } else {
  //       let dados;
  //       dados = await this.httpUtilProvider.get(
  //         ENV.WS_PRODUTO +
  //           "list/" +
  //           localStorage.getItem("empresa") +
  //           "?filter=" +
  //           itemSearch +
  //           "&socomestq=N"
  //       );

  //       let item: any[] = dados.content;

  //       if (item) {
  //         this.zone.run(() => {
  //           this.active = true;
  //           this.exibeProduto = true;
  //         });
  //         this.ItemDetail(event, item[0]);

  //         this.onCancel();
  //       }
  //     }
  //     this.zone.run(() => {
  //       this.skeletonLoading = false;
  //       this.content.resize();
  //       this.firstSkeletonLoading = false;
  //     });
  //   } catch (error) {
  //     this.zone.run(() => {
  //       this.skeletonLoading = false;
  //       this.content.resize();
  //       this.firstSkeletonLoading = false;
  //     });
  //     this.commonServices.showToast(error);
  //   }
  // }

  async atualizaPedido() {
    try {
      let aResult = [];

      let table: PedidoTable = new PedidoTable();
      table.name = "cartao_pedido";
      table.value = this.commonServices.codigoCartaoPedido;
      aResult.push(table);

      await this.httpUtilProvider.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      );
    } catch (error) {
      this.commonServices.cardSelected = false;
      this.commonServices.codigoCartaoPedido = "";
    }
  }

  //Alterado por Nicollas Bastos em 25/09/2018
  setCardPedido(codCard: any) {
    this.commonServices.codigoCartaoPedido = codCard;

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = this.commonServices.codigoCartaoPedido;
    aResult.push(table);

    this.httpUtilProvider
      .post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      )
      .then(data => {
        this.commonServices.dadosCliente = data;
        this.commonServices.cardSelected =
          this.commonServices.codigoCartaoPedido != "";

        if (this.commonServices.dadosCliente.cgccpf_cliente != null && this.commonServices.dadosCliente.cgccpf_cliente.trim().length > 0) {
          this.commonServices.clientSelected = true;
          this.existClient = this.commonServices.clientSelected;
          this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
          this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;
        } else {
          this.commonServices.clientSelected = false;
          this.commonServices.docCliente = "";
          this.commonServices.nomeCliente = "";
        }

        // this.atualizaPedido();
        this.commonServices.cardSelected = true;
        this.cardClient = this.commonServices.cardSelected;
      })
      .catch(error => {
        this.cardClient = false;
        this.commonServices.cardSelected = false;
        this.commonServices.codigoCartaoPedido = "";

        console.log(error);
      });
  }

  async getProdutoPorCodigodeBarra(event: any) {

    try {

      if (event.target && event.target.value.length >= 2) {
        let codigo: string = event.target.value;

        if (codigo.substring(0, 1) == "P") {
          this.setCardPedido(codigo);
        } else {
          this.mode = 2;
          this.active = true;

          this.httpUtilProvider._abortProcess();  // by Ryuge 29/11/2019

          let dados;
          dados = await this.httpUtilProvider.get(
            ENV.WS_PRODUTO + API_URL +
            "list/" +
            localStorage.getItem("empresa") +
            "?filter=" +
            event.target.value
          )
          let item: any[] = dados.content;

          if (item) {
            this.active = false;
            //this.exibeProduto = false;
            this.ItemDetail(event, item[0]);
          }
        }
      }

    } catch (error) {
      this.focusOn();
    }

  }

  async getProdutoPorScanner(cod: string) {
    this.mode = 2;
    try {
      // this.zone.run(() => {
      this.skeletonLoading = this.commonServices.exibeSkeletonLoading;
      // });
      if (cod != "") {

        this.httpUtilProvider._abortProcess();  // by Ryuge 29/11/2019

        this.items = await this.httpUtilProvider.get(
          ENV.WS_PRODUTO + API_URL +
          "list/" +
          localStorage.getItem("empresa") +
          "?filter=" +
          cod
        );

        this.items = this.items.content;
        this.existItem = this.items.status == "OK";

        let it: any[] = this.items;
        //this.exibeProduto = false;
        this.ItemDetail(event, it[0]);

        // this.zone.run(() => {
        this.skeletonLoading = false;
        this.content.resize();
        this.firstSkeletonLoading = false;
        this.items = [];
        // });
      }
    } catch (error) {
      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      // });
      this.commonServices.showToast(error.json().detail);
    }
  }

  //Alterado por Nicollas Bastos em 25/09/2018
  ionViewDidEnter() {
    this.alreadyPushed = false;

    // Initialize the flag
    this.menu.swipeEnable(false);

    // this.existBasket = this.commonServices.qtdBasketItens > 0;
    // this.qtdItem = this.commonServices.qtdBasketItens;
    //  console.log(this.commonServices.qtdBasketItens);

    this.abort = true;

    this.infiniteScroll.enable(true);
    // if (this.commonServices.numPedido != '0' && this.commonServices.statusPedido == 'M') {
    if (this.commonServices.numPedido != "0") {
      // console.log('produto');
      // console.log(this.commonServices.qtdBasketItens);

      if (this.mode == 1) {
        this.qtdItem = this.commonServices.qtdBasketItens;
      } else {
        this.getManutencaoPedido(this.commonServices.numPedido);
      }
    }
    this.existClient = this.commonServices.clientSelected;
    this.cardClient = this.commonServices.cardSelected;
    this.content.resize();

    // setTimeout(() => {
    //   if (this.scanned) {
    //     this.scanned.setFocus();
    //   }
    // }, 150);

  }

  scanCode() {
    if (this.platform.is("cordova")) {
      let options = {
        prompt: "Escaneie o código de barra"
      };
      this.barcodeScanner.scan(options).then(
        barcodeData => {
          this.scannedCode = barcodeData.text;
          try {
            if (this.commonServices.validateScan(this.scannedCode)) {
              var code = this.commonServices.codeScan(this.scannedCode);
              let codigo = code[code.length - 1];
              if (codigo[0] == "P") {
                this.setCardPedido(codigo);
                return;
              } else if (codigo.length >= 13 && codigo.length <= 16) {
                // this.zone.run(() => {
                this.items = [];
                // });
                this.getProdutoPorScanner(codigo);
                this.onCancel();
                return;
              }
            }
          } catch (e) {
            console.log("Error: ", e);
          }
        },
        err => {
          console.log("Error: ", err);
        }
      );
    } else {
      this.scannerWeb();
    }
  }


  cardWeb() {
    let prompt = this.alertCtrl.create({
      title: "Cartão Pedido",
      message: "Digite o código do cartão.",

      inputs: [
        {
          id: "idinput",
          name: "codigo",
          value: this.codCardPedido,
          placeholder: "Digite o código de barra"
        }
      ],
      buttons: [
        {
          text: "Voltar",
          handler: data => {
            this.liberaCartao();
            console.log("Cancelado");
          }
        },
        {
          text: "Ok",
          handler: data => {
            console.log(data.codigo);
            this.gravaCardPedido(data.codigo);
          }
        }
      ],
      cssClass: "alertCustomCss"
    });
    prompt
      .present()
      .then(() => {
        document.getElementById("idinput").focus();
      })
      .catch();
  }

  scannerWeb() {
    let prompt = this.alertCtrl.create({
      title: "Scanner",
      message: "Escaneie ou digite o código.",

      inputs: [
        {
          id: "idinput",
          name: "codigo",
          placeholder: "Escaneie o código de barra"
        }
      ],
      buttons: [
        {
          text: "Voltar",
          handler: data => {
            console.log("Cancelado");
          }
        },
        {
          text: "Ok",
          handler: data => {
            console.log(data.codigo);
            this.getProdutoPorScanner(data.codigo);
          }
        }
      ],
      cssClass: "alertCustomCss"
    });
    prompt
      .present()
      .then(() => {
        document.getElementById("idinput").focus();
      })
      .catch();
  }


  liberaCartao() {

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = 'P0';
    aResult.push(table);

    // let result: any = await this.httpUtilProvider.post(environment.WS_VENDAS + 'PedidoVenda/update/'
    // 	+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult);

    // let headers = new Headers();
    // headers.append('x-auth-token', localStorage.getItem('token'));
    // let options = new RequestOptions({ headers: headers });

    return new Promise(resolve => {
      this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/update/'
        + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult).then(data => {
          resolve(data);

          this.codCardPedido = '';
          this.commonServices.cardSelected = false;
          this.commonServices.codigoCartaoPedido = '0';
          this.cardClient = this.commonServices.cardSelected;

          console.log('LIBERA CARTAO PEDIDO');
          console.log(this.cardClient);


        }, err => {
          this.commonServices.showAlert2(err.json().title, err.json().detail);
        });
    });

  }

  gravaCardPedido(CartaoPedido: any) {

    this.codCardPedido = CartaoPedido;

    this.commonServices.cardSelected = false;

    console.log(this.codCardPedido.toUpperCase());

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = this.codCardPedido.toUpperCase();
    aResult.push(table);

    // let headers = new Headers();
    // headers.append('x-auth-token', localStorage.getItem('token'));
    // let options = new RequestOptions({ headers: headers });

    return new Promise(resolve => {
      this.httpUtilProvider.post(ENV.WS_VENDAS + 'PedidoVenda/update/'
        + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult).then(data => {
          resolve(data);
          // this.commonServices.dadosCliente = data.json();
          this.commonServices.codigoCartaoPedido = this.codCardPedido.toUpperCase();
          this.commonServices.cardSelected = this.codCardPedido != '';
          this.cardClient = this.commonServices.cardSelected;

        }, err => {
          console.log('ERRO CARTAO PEDIDO');
          console.log(err);
          this.commonServices.showAlert2(err.json().title, err.json().detail);
        });
    });

  }



  scanner() {
    this.barcodeScanner.scan().then(
      result => {
        if (!result.cancelled) {
          const barcode = new BarcodeData(result.text, result.format);
          this.AddItemBasketbyClick(barcode);
        }
      },
      err => {
        console.log(err);
        // An error occurred
      }
    );
  }

  AddItemBasketbyClick(item) {
    this.alreadyPushed = true;
    this.navCtrl.push(
      "PedidoAdicionarSacola",
      {
        item: item,
        headerPedido: this.commonServices.pedidoHeader,
        type: "N",
        mode: 1
        // item: item, headerPedido: this.dados
      },
      { animation: "fade-transition", direction: "forward" }
    );
  }

  AddItemBasketbySliding(event, item) {
    this.percent = event.getSlidingPercent();
    // if (this.percent > 1 && !this.alreadyPushed) {
    if (!this.alreadyPushed) {
      // Set the flag to true
      this.alreadyPushed = true;

      this.navCtrl.push("PedidoAdicionarSacola", {
        item: item,
        headerPedido: this.commonServices.pedidoHeader,
        type: "N",
        mode: 1
        // item: item, headerPedido: this.dados
      });
    }
  }

  ItemDetail(event, item) {
    if (!this.alreadyPushed) {
      this.navCtrl.push("ProdutoDetalhe", {
        item: item,
        images: this.images,
        headerPedido: this.commonServices.pedidoHeader,
        mode: 1,
        modoConsulta: this.modoConsulta
        // item: item, images: this.images, headerPedido: this.dados
      });

      // controla retorno de tela
      // if (thisionic serve.mode == 2) {
      //   this.mode = 0;
      // }
    }
  }

  showclient() {
    this.navCtrl.push("Cliente", { back: "ProdutoLista" });

    // comentado por ryuge 05/10/2018 - Favor NÃO REMOVER
    // if (this.platform.is("cordova")) {
    //   this.navCtrl.push("Cliente", { back: "ProdutoLista" });
    // }else{
    //   this.navCtrl.push("Cliente2", { back: "ProdutoLista" });
    // }

  }

  focusButton(): void {
    setTimeout(() => {
      if (this.search) {
        this.search.setFocus();
      }
    }, 500);
  }

  showSearch() {
    this.showsearch ? (this.showsearch = false) : (this.showsearch = true);
    return this.showsearch;
  }

  showDisplay(e: any) {
    // se não estiver processando  filtro
    if (!this.loadingImage) {
      var x = document.getElementById("DivWall");
      var y = document.getElementById("DivFilter");

      if (e.target.tagName == "ION-HEADER") {
        if (x.style.display === "none") {
          x.style.display = "block";
        } else {
          x.style.display = "none";
        }

        if (y.style.display === "none") {
          y.style.display = "block";
        } else {
          y.style.display = "none";
        }

        this.closeFilter();
      }
    }
  }

  // by ryuge 12/09/2019
  async optionsPopover() {
    if (this.abort) {
      await this.FilterProduct(this.itemSearch);
    }
    this.exibeFiltro = !this.exibeFiltro;
  }

  closeFilter() {
    this.Hide = false;
    this.Hide1 = false;
    this.Hide2 = false;
    this.Show = true;
    this.Show1 = true;
    this.Show2 = true;
    this.exibeFiltro = !this.exibeFiltro;

    this.aResult = this.itemFilters;

    // this.SendListProduct(this.itemSearch, this.aResult);
  }

  // metodos do filtro

  filtroSelected(idx) {
    this.filtroTitle = "";
    this.filter.expanded = 1;

    for (var i in this.filtros) {
      if (i == idx) {
        this.filtroTitle = this.filtros[i].description;
        if (this.filtros[i].selected == 0) {
          this.filtros[i].selected = 1;
          this.filtros[i].expanded = 1;
          // this.filtros[i].visible = 1;
        }
      } else {
        this.filtros[i].selected = 0;
        this.filtros[i].expanded = 0;
        // this.filtros[i].visible = 0;
      }
    }

    this.itemFilters.filtrador_por[0].items = this.filtros;
    this.aResult = this.itemFilters;
    this.SendListProduct(this.itemSearch, this.aResult);
  }

  // linhaSelected(idx,linha){
  //   this.linhaTitle = "";
  //   this.line.expanded = 1;
  //   for (var i in this.linhas) {
  //     if(i == idx){

  //        this.linhaTitle = this.linhas[i].description+','+this.linhaTitle;

  //         if(this.linhas[i].selected == 0){
  //           this.linhas[i].selected = 1
  //           this.linhas[i].expanded = 1;
  //         }else{
  //           this.linhas[i].selected = 0;
  //           this.linhas[i].expanded = 0;
  //           // this.linhaTitle = 'Todas as linhas';
  //         }
  //     }
  //   }

  // }

  exibeTituloLinha(linhas) {
    this.linhaTitle = "";
    this.line.expanded = 1;

    for (var i in this.linhas) {
      if (this.linhas[i].selected == 1) {
        this.linhaTitle = this.linhas[i].description + "," + this.linhaTitle;
      }
    }

    if (this.linhaTitle == "") {
      this.linhaTitle = "Todas as linhas";
      this.Show2 = true;
      this.Hide2 = false;
    } else {
      this.Show2 = false;
      this.Hide2 = true;
    }
  }

  exibeTituloSituacao(situacoes) {
    this.situacaoTitle = "";
    this.situation.expanded = 1;

    for (var i in this.situacoes) {
      if (this.situacoes[i].selected == 1) {
        this.situacaoTitle =
          this.situacoes[i].description + "," + this.situacaoTitle;
      }
    }

    if (this.situacaoTitle == "") {
      this.situacaoTitle = "Todas as situações";
      this.Show1 = true;
      this.Hide1 = false;
    } else {
      this.Show1 = false;
      this.Hide1 = true;
    }
  }

  situacaoSelected(x) {
    if (this.situacoes[x].selected == 0) {
      this.situation.expanded = 1;
      this.situacoes[x].selected = 1;
    } else {
      this.situation.expanded = 0;
      this.situacoes[x].selected = 0;
    }

    this.itemFilters.filtrador_por[1].items = this.situacoes;
    this.aResult = this.itemFilters;

    this.SendListProduct(this.itemSearch, this.aResult);
  }

  linhaSelected(x) {
    // this.linhaTitle = "";
    if (this.linhas[x].selected == 0) {
      this.line.expanded = 1;
      this.linhas[x].selected = 1;
    } else {
      this.line.expanded = 0;
      this.linhas[x].selected = 0;
    }

    this.itemFilters.filtrador_por[2].items = this.linhas;
    this.aResult = this.itemFilters;

    this.SendListProduct(this.itemSearch, this.aResult);
  }

  toggleSection(index) {
    if (!this.atributos[index].status) {
      this.atributos[index].status = !this.atributos[index].status;
      this.atributos[index].level = !this.atributos[index].level;
      this.atributos[index].expanded = 1;
    }
  }

  toggleSectionUp(index) {
    this.atributos[index].status = !this.atributos[index].status;
    this.atributos[index].level = !this.atributos[index].level;
    this.atributos[index].expanded = 0;
  }

  isLevel1Shown(idx) {
    return this.atributos[idx].level;
  }

  // private breakline(str: string) {
  //   return str.replace(/,/g, "<br>");
  // }

  toggleItem(j, x) {
    if (this.atributos[j].valores[x].selected == 0) {
      this.atributos[j].valores[x].selected = 1;
    } else {
      this.atributos[j].valores[x].selected = 0;
    }

    this.itemFilters.atributos = this.atributos;

    this.aResult = this.itemFilters;

    this.SendListProduct(this.itemSearch, this.aResult);

    // console.log(this.breakline( this.atributos[j].valores[x].atributo_valor_info));
  }

  unselectItems() {
    for (var i in this.filtros) {
      this.filtros[i].selected = 0;
    }
  }

  async SendListProduct(e: any, result: any) {
    try {
      console.log("SendListProduct");
      console.log(e);

      // this.zone.run(() => {
      this.skeletonLoading = this.commonServices.exibeSkeletonLoading;
      this.loadingImage = true;
      // });

      this.itemFiltersResult = await this.httpUtilProvider.post(
        ENV.WS_PRODUTO + API_URL +
        "list/" +
        localStorage.getItem("empresa") +
        "?filter=descricao:" +
        e,
        result
      );

      this.totalPages = this.itemFiltersResult.produtos.totalPages;
      this.totalElements = this.itemFiltersResult.produtos.totalElements;
      this.items = this.itemFiltersResult.produtos.content;

      this.filter = this.itemFiltersResult.filtros.filtrador_por[0];
      this.situation = this.itemFilters.filtrador_por[1];
      this.line = this.itemFiltersResult.filtros.filtrador_por[2];

      this.filtros = this.itemFiltersResult.filtros.filtrador_por[0].items;
      this.situacoes = this.itemFilters.filtrador_por[1].items;
      this.linhas = this.itemFiltersResult.filtros.filtrador_por[2].items;
      this.atributos = this.itemFiltersResult.filtros.atributos;

      this.qtdCheckedFilter = this.itemFiltersResult.filtros.qtdCheckedFilter;

      for (var v in this.atributos) {
        if (this.atributos[v].expanded == 1) {
          this.toggleSection(v);
        }
      }

      this.exibeTituloLinha(this.linhas);
      this.exibeTituloSituacao(this.situacoes);

      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      this.loadingImage = false;
      // });
    } catch (error) {
      this.loadingImage = false;
      // this.commonServices.showToast(error);
      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      this.loadingImage = false;
      // });
    }
  }

  async FilterProduct(e: any) {
    try {
      console.log("PROCESSANDO FILTROS");
      this.exibeBotaoLimpar = false;

      // this.zone.run(() => {
      this.skeletonLoading = this.commonServices.exibeSkeletonLoading;
      this.loadingImage = true;
      // });

      this.itemFilters = await this.httpUtilProvider.get(
        ENV.WS_PRODUTO + API_URL +
        "filter/" +
        localStorage.getItem("empresa") +
        "?filter=descricao:" +
        e
      );

      console.log(this.itemFilters);

      this.itemFiltersClone = JSON.parse(JSON.stringify(this.itemFilters));

      this.filter = this.itemFilters.filtrador_por[0];
      this.situation = this.itemFilters.filtrador_por[1];
      this.line = this.itemFilters.filtrador_por[2];

      this.filtros = this.itemFilters.filtrador_por[0].items;
      this.situacoes = this.itemFilters.filtrador_por[1].items;
      this.linhas = this.itemFilters.filtrador_por[2].items;
      this.atributos = this.itemFilters.atributos;

      this.qtdCheckedFilter = this.itemFilters.qtdCheckedFilter;

      this.exibeTituloLinha(this.linhas);
      this.exibeTituloSituacao(this.situacoes);

      this.exibeBotaoLimpar = this.itemFilters.atributos.length > 0;

      // this.zone.run(() => {
      this.loadingImage = false;
      // });
      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      // });
    } catch (error) {
      this.abort = false;
      this.loadingImage = false;
      // this.zone.run(() => {
      this.loadingImage = false;
      // });
      // this.zone.run(() => {
      this.skeletonLoading = false;
      this.content.resize();
      this.firstSkeletonLoading = false;
      // });

      // this.commonServices.showToast(error);
    }
  }

  showNext() {
    this.Show = !this.Show;
    this.Hide = !this.Hide;
    this.filtroTitle = "";
    this.filter.expanded = 0;
  }

  showNext1() {
    this.Show1 = !this.Show1;
    this.Hide1 = !this.Hide1;
    // this.linhaTitle = "Todas as linhas";
    this.situation.expanded = 0;
  }

  showNext2() {
    this.Show2 = !this.Show2;
    this.Hide2 = !this.Hide2;

    this.line.expanded = 0;
    // if (this.atributos) {
    //   this.toggleSectionUp(1);
    // }
  }

  atribStatus(idx) {
    this.atributos[idx].status = true;
    // console.log(this.atributos[idx].status);
  }

  showlog(exibe, idx, id) {
    this.atributos[idx].status = false;
  }

  getRandomColor() {
    var letters = "0123456789ABCDEF";
    var color = "#";
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  //Alterado por Ryuge 26/09/2018
  checkEstq(ligado: boolean) {
    this.exibeItemComEstq = ligado;
    if (this.itemSearch != '') {
      this.getProdutoPorDescricao(this.itemSearch)
    }
  }

  // tela para manutenção de pedido

  getManutencaoPedido(idPedido) {
    // cabeçalho do pedido
    try {
      // cabeçalho do pedido
      this.httpUtilProvider.getPedido(idPedido).then(result => {
        this.existBasket = result.numitens > 0;
        this.commonServices.qtdBasketItens = result.numitens;
        this.qtdItem = this.commonServices.qtdBasketItens;
      });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }

  exibePedidoManutencao() {
    let itPedido;
    let idxPedido;

    if (this.commonServices.sistuacaoPedido == "A") {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    // this.commonServices.numPedido = itPedido[0].numpedido;

    console.log("exibePedidoManutencao");
    console.log(this.commonServices.sistuacaoPedido);
    console.log(itPedido[idxPedido]);

    if (itPedido != {}) {
      this.navCtrl.push("PedidoSacola", { item: itPedido[idxPedido], mode: 3 });
    }
  }

  showCardClient() {
    if (this.platform.is("cordova")) {
      this.navCtrl.push("CartaoPedido", { back: "ProdutoLista" });
    } else {
      this.cardWeb();
    }
  }
}
export class BarcodeData {
  constructor(public text: String, public format: String) { }
}
