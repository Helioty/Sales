import { TranslateModule } from '@ngx-translate/core';

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { ConsultaCep } from './consulta-cep';
import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';

@NgModule({
  declarations: [
    ConsultaCep,
  ],
  imports: [
    IonicPageModule.forChild(ConsultaCep),
    PipesModule,DirectivesModule,TranslateModule
  ],
  exports: [
    ConsultaCep
  ]
})
export class  ConsultaCepModule {}