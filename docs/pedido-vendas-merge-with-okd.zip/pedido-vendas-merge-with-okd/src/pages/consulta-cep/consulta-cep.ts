import { Component, NgZone, ViewChild } from "@angular/core";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { Geolocation } from "@ionic-native/geolocation";
import {
  App, Content, IonicPage,
  NavController, NavParams,
  Platform, Searchbar,
  ToastController,
  ViewController
} from "ionic-angular";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

declare var google;

@IonicPage()
@Component({
  selector: "consulta-cep",
  templateUrl: "consulta-cep.html"
})
export class ConsultaCep {
  @ViewChild("searchbar")
  searchbar: Searchbar;

  // @ViewChild(Content) content: Content;
  @ViewChild("campo1") campo1;  // campo cep
  @ViewChild("campo2") campo2;  // campo endereco
  @ViewChild("campo3") campo3;  // campo numero
  @ViewChild("campo4") campo4;  // campo complemento
  @ViewChild("campo5") campo5;  // campo bairro
  @ViewChild("campo6") campo6;  // campo cidade
  @ViewChild("campoUf") campoUf // campo UF



  mapShow: boolean = true;
  geocoder: any;
  GoogleAutocomplete: any;
  autocomplete: { input: string };
  autocompleteItems: any[] = [];
  markers: any[] = [];
  onLoad: any;
  frmData: any;
  inputFocus: boolean;
  showLoading: boolean;
  // by Ryuge 26/09/2019
  // dadosEndereco: { cep: string; endereco: string; numero: string; bairro: string; cidade: string; uf: string; complemento: string; };
  dadosEndereco: address;
  clickEventTimout: boolean = false;

  public dados;
  public cep;
  public listaenderecos;
  private back;
  public userCep;
  public userAddress;
  public userNumber;
  public userComplement;
  public userBairro;
  public userCidade;
  public userEstado;
  private modoConsulta;

  @ViewChild("map")
  mapElement;
  @ViewChild("index")
  index: number;
  @ViewChild(Content) content: Content;

  map: any;
  start: string;
  end: string;

  directionsService = new google.maps.DirectionsService();
  directionsDisplay = new google.maps.DirectionsRenderer();
  latLng: any;
  public cepGenerico: boolean;
  public confirmaEnderecoTexto: string;

  constructor(
    public commonServices: CommonServices,
    public navParams: NavParams,
    private httpUtilProvider: HttpUtilProvider,
    public navCtrl: NavController,
    public viewCtrl: ViewController,
    public appCtrl: App,
    public geolocation: Geolocation,
    private zone: NgZone,
    private toastCtrl: ToastController,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    console.log('ENTREI AQUI!'); 

    this.modoConsulta = this.navParams.get("modoConsulta");
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();

    this.autocomplete = { input: "" };
    // by Ryuge 28/09/2019
    // this.dadosEndereco = { cep: null, endereco: null, numero: null, bairro: null, cidade: null, uf: null, complemento: null };
    this.dadosEndereco = new address();
    this.autocompleteItems = [];
    this.markers = [];
    this.onLoad = true;
    this.frmData = "";
    this.geocoder = new google.maps.Geocoder();
    this.confirmaEnderecoTexto = "Confirma Local";

    this.back = this.navParams.get("back");
  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ionViewWillEnter() {

    this.goToFullScreen();

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);
  }

  ionViewDidEnter() {
  
    this.latLng = new google.maps.LatLng(-8.1129892, -34.9126349);
    this.map = new google.maps.Map(document.getElementById("map"), {
      zoom: 15,
      center: this.latLng,
      disableDefaultUI: true
    });
    this.mostraMap();

    google.maps.event.addListener(this.map, "click", event => {
      this.showLoading = true;
      this.insereMarker(event.latLng);
      this.searchbar.inputBlurred();
      // this.getMarkerInfo(true);
    });

    // setTimeout(() => {
    // 	this.searchbar.setFocus();
    // }, 1000);
  }



  // by Helio 02/10/2019 
  // adiciona classe CSS em um objeto 
  addClass(id: string, classe: string) {
    // console.log(this.content)

    var elemento = document.getElementById(id);
    var classes = elemento.className.split(' ');
    var getIndex = classes.indexOf(classe);

    if (getIndex === -1) {
      classes.push(classe);
      elemento.className = classes.join(' ');
    }
  }

  // by Helio 02/10/2019  
  // remove classe CSS de objeto 
  delClass(id: string, classe: string) {
    var elemento = document.getElementById(id);
    var classes = elemento.className.split(' ');
    var getIndex = classes.indexOf(classe);

    if (getIndex > -1) {
      classes.splice(getIndex, 1);
    }
    elemento.className = classes.join(' ');
  }

  // by Helio 02/10/2019
  scrollNow(id: any) {
    //------------------------------------------------------------------//
    // by Helio 02/10/2019
    // move o scroll da tela
    if (id == "campo1") {
      this.content.scrollTo(0, 0, 200);
      console.log("scroll to campo 1")
    }
    else if (id == "campo2") {
      this.content.scrollTo(0, 70);
      console.log("scroll to campo 2")
    }
    else if (id == "campo3") {
      this.content.scrollTo(0, 128, 200);
    }
    else if (id == "campo4") {
      this.content.scrollTo(0, 186, 200);
    }
    else if (id == "campo5") {
      this.content.scrollTo(0, 240, 200);
    }
    else if (id == "campo6") {
      this.content.scrollTo(0, 296, 200);
    }
    //------------------------------------------------------------------//
  }

  // by Ryuge 03/12/2018
  // edit by Helio 01/10/2019
  // funcão para trocar o foco ao apertar enter
  next(campo: any) {
    this.goToFullScreen();

    if (campo == 'cep') {
      setTimeout(() => {
        this.campo1.setFocus();
      }, 100);
    }
    if (campo == 'uf') {
      setTimeout(() => {
        this.campoUf.setFocus();
      }, 100);
    }
    if (campo == 'endereco') {
      setTimeout(() => {
        this.campo2.setFocus();
      }, 100);
    }
    if (campo == 'numero') {
      setTimeout(() => {
        this.campo3.setFocus();
      }, 100);
    }
    if (campo == 'complemento') {
      setTimeout(() => {
        this.campo4.setFocus();
      }, 100);
    }
    if (campo == 'bairro') {
      setTimeout(() => {
        this.campo5.setFocus();
      }, 100);
    }
    if (campo == 'cidade') {
      setTimeout(() => {
        this.campo6.setFocus();
      }, 100);
    }
  }


  //Transformar valor de cordenada em adress
// async getMarkerInfo(formatado: boolean) {
//     this.cepGenerico = false;
//     await this.geocoder.geocode(
//       { latLng: this.markers[this.markers.length - 1].getPosition() },
//         (results, status) => {
//         if (status == google.maps.GeocoderStatus.OK && results[0]) {
//           if (formatado == true) {
//             this.zone.run(() => {
//               console.log(results[0].address_components);
//               this.autocomplete.input = results[0].formatted_address;
//               this.showLoading = false;
//               this.autocompleteItems = [];
//             });
//           } else {

//             // for (let item of results[0].address_components) {            
//             //     console.log('CONSULTA GOOGLE MAP');
//             //     console.log(item);
//             // }

//             this.confirmaEnderecoTexto = "Carregando...";
//             let item: any = results[0].address_components;

//             if(item.length == 7){

//               console.log('CONSULTA GOOGLE MAP');
//               console.log(item);

//               this.userAddress = item[0].long_name;
//               this.userBairro = item[1].long_name;
//               this.userCidade = item[2].long_name;
//               this.userEstado  = item[3].short_name;
//               this.userCep = item[5].long_name;
//             }

//             if(item.length == 6){

//               console.log('CEP GENERICO');
//               console.log(item);
            
//               this.userAddress = item[0].long_name;
//               this.userBairro = item[1].long_name;
//               this.userCidade = item[2].long_name;
//               this.userEstado  = item[3].short_name;
//               this.userCep = item[5].long_name;

//             }

//             if(item.length == 5){

//               console.log('CEP GENERICO');
//               console.log(item);
            
//               this.userAddress = item[1].long_name;
//               // this.userBairro = item[2].long_name;
//               this.userCidade = item[2].long_name;
//               this.userEstado  = item[3].short_name;
//               this.userCep = item[4].long_name;

//             }            

//             formatado = false;

//             // for (let item of results[0].address_components) {
//             //   switch (item.types[0]) {
//             //     case "postal_code": {
//             //       console.log('postal_code');
//             //       console.log(results[0]);
//             //       this.zone.run(() => {
//             //         this.userCep = item.long_name;
//             //         if (
//             //           this.userCep[5] == "-" &&
//             //           this.userCep[6] == 0 &&
//             //           this.userCep[7] == 0 &&
//             //           this.userCep[8] == 0
//             //         ) {
//             //           this.cepGenerico = true;
//             //           this.confirmaEnderecoTexto = "Carregando...";
//             //           console.log(this.confirmaEnderecoTexto);
//             //         } else if (this.userCep.length == 5) {
//             //           this.cepGenerico = true;
//             //           this.confirmaEnderecoTexto = "Carregando...";
//             //           console.log(this.confirmaEnderecoTexto);
//             //           this.userCep = this.userCep + "-000";
//             //         }
//             //       });
//             //       break;
//             //     }
//             //     case "street_address": {
//             //       this.zone.run(() => {
//             //         this.userAddress = item.long_name;
//             //       });
//             //       break;
//             //     }
//             //     case "route": {
//             //       this.zone.run(() => {
//             //         this.userAddress = item.long_name;
//             //       });
//             //       break;
//             //     }
//             //     case "street_number": {
//             //       this.zone.run(() => {
//             //         this.userNumber = item.short_name;
//             //       });
//             //       break;
//             //     }
//             //     case "political": {
//             //       this.zone.run(() => {
//             //         this.userBairro = item.long_name;
//             //       });
//             //       break;
//             //     }
//             //     case "locality": {
//             //       this.zone.run(() => {
//             //         this.userCidade = item.long_name;
//             //       });
//             //       break;
//             //     }
//             //     case "administrative_area_level_1": {
//             //       this.zone.run(() => {
//             //         this.userEstado = item.short_name;
//             //       });
//             //       break;
//             //     }
//             //   }
//             // } // fim for


//             // this.showLoading = false;
//             // if (this.cepGenerico) {
//             //   let cep: any = await this.httpUtilProvider.get(
//             //     API_URL + ENV.WS_PUBLIC +
//             //     "consultaViaCEP?cep=" +
//             //     this.userEstado +
//             //     "/" +
//             //     this.userCidade +
//             //     "/" +
//             //     this.userAddress.substr(this.userAddress.indexOf(" ") + 1)
//             //   );
//             //   this.zone.run(() => {
//             //     console.log(cep);
//             //   });
//             //   for (let c of cep) {
//             //     if (this.userCep == c.cep) {
//             //       this.zone.run(() => {
//             //         this.cepGenerico = false;
//             //         this.confirmaEnderecoTexto = "Confirmar Local";
//             //       });
//             //       break;
//             //     }
//             //   }
//             //   if (this.cepGenerico) {
//             //     this.zone.run(() => {
//             //       this.userCep = cep[0].cep;
//             //       this.zone.run(() => {
//             //         this.cepGenerico = false;
//             //         this.confirmaEnderecoTexto = "Confirmar Local";
//             //       });
//             //     });
//             //   }
//             // }

//           }
//         } else {
//           this.showLoading = false;
//           this.toastCtrl
//             .create({
//               message: "Operação falhou, tente novamente",
//               duration: 2000,
//               position: "bottom"
//             })
//             .present();
//           console.log("Geocoder failed due to: " + status);
//         }
//       }
//     );
//   }

  mostraMap() {
    this.mapShow = true;
    this.content.resize();
  }

  insereMarker(latlng) {
    this.clearLocations();
    let marker = new google.maps.Marker({
      position: latlng,
      map: this.map,
      visible: true
    });
    this.markers.push(marker);
    this.map.setCenter(latlng);
  }


showResultGoogleMap(item: any){
  if(item.length == 7){

    console.log('CONSULTA GOOGLE MAP');
    console.log(item);

    this.userAddress = item[1].long_name;
    this.userBairro = item[2].long_name;
    this.userCidade = item[3].long_name;
    this.userEstado  = item[4].short_name;
    this.userCep = item[6].long_name;
  }

  if(item.length == 6){

    console.log('CEP GENERICO');
    console.log(item);
  
    this.userAddress = item[0].long_name;
    this.userBairro = item[1].long_name;
    this.userCidade = item[2].long_name;
    this.userEstado  = item[3].short_name;
    this.userCep = item[5].long_name;

  }

  if(item.length == 5){

    console.log('CEP GENERICO');
    console.log(item);
  
    this.userAddress = item[1].long_name;
    // this.userBairro = item[2].long_name;
    this.userCidade = item[2].long_name;
    this.userEstado  = item[3].short_name;
    this.userCep = item[4].long_name;

  }       

}  

getAddressGoogleMap(){
    // this.clearLocations();
    this.geocoder.geocode(
      { latLng: this.markers[this.markers.length - 1].getPosition() },
     (results, status) => {

      if(status === 'OK' && results[0]) {
            this.insereMarker(results[0].geometry.location);
            // this.confirmaEnderecoTexto = "Carregando...";
            // let item: any = results[0].address_components;
            this.showResultGoogleMap(results[0].address_components);
      }

    });
  }

  confirmarLocal() {
    this.showLoading = true;
    // by Ryuge 26/09/2019
    this.getAddressGoogleMap();
    // comentado por Ryuge
    // this.getMarkerInfo(false);
    // this.latLng = this.markers[this.markers.length - 1].getPosition();
    // this.clearLocations();
    this.showLoading = false;
    this.mapShow = false;
    this.content.resize();
  }

  lostFocus() {
    this.inputFocus = false;
  }

  updateSearchResults() {

    if (!this.inputFocus) {
      return;
    }
    if (this.autocomplete.input == "") {
      this.autocompleteItems = [];
      this.mostraMap();
      return;
    }
    this.mostraMap();
    this.GoogleAutocomplete.getPlacePredictions(
      {
        input: this.autocomplete.input,
        componentRestrictions: { country: ["br"] }
      },
      (predictions, status) => {
        this.autocompleteItems = [];
        this.zone.run(() => {
          if (predictions) {
            predictions.forEach(prediction => {
              this.autocompleteItems.push(prediction);
            });
          }
        });
      }
    );
  }

  selectSearchResult(item) {

    console.log('ENTREI x AQUI!'); 

    this.showLoading = true;
    this.autocompleteItems = [];
    // this.clearLocations();
    this.geocoder.geocode({ placeId: item.place_id }, (results, status) => {
      if (status === "OK" && results[0]) {
        this.showLoading = false;
        this.insereMarker(results[0].geometry.location);

        this.zone.run(() => {
          this.autocomplete.input = item.description;
        });
      } else {
        this.showLoading = false;
      }
    });
  }

  putFocus(input) {
    input.setFocus();
  }

  initMap() {
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 15,
      center: { lat: -8.1129892, lng: -34.9126349 },
      disableDefaultUI: true
      // center: {lat: 41.85, lng: -87.65}
    });

    this.directionsDisplay.setMap(this.map);
  }

  retornarPagina() {
    if (this.modoConsulta) {
      let status: boolean = true;
      this.navCtrl.setRoot("PedidoLista", { refresh: status });
    } else {
      // this.viewCtrl.dismiss();
      this.navCtrl.pop();
    }
  }

  confirmarEndereco() {

    this.dadosEndereco.cep = this.userCep;
    this.dadosEndereco.endereco = this.userAddress; 
    this.dadosEndereco.numero = this.userNumber;
    this.dadosEndereco.bairro = this.userBairro;
    this.dadosEndereco.cidade = this.userCidade;
    this.dadosEndereco.uf = this.userEstado;
    this.dadosEndereco.complemento = this.userComplement
  
    console.log('RESULTADO');
    console.log(this.dadosEndereco);    
    this.viewCtrl.dismiss(this.dadosEndereco);
  }
  
  //--On search bar focus ---
  searchBarOnFocus() {
    this.onLoad = false;
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }
    return idx;
  }

  isEmptyObject(obj) {
    return Object.keys(obj).length > 0;
  }

  onKey(value) {
    this.cep = value;
  }

  async getCep(event: any) {
    this.commonServices.showLoader();
    try {
      this.cep = await this.httpUtilProvider.get(
        ENV.WS_PUBLIC+API_URL+ "consultaViaCEP?cep=" + event.target.value
      );
      console.log("CEP");
      console.log(this.cep);
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }

  async getGeoLocalizacao(endereco: any) {
    console.log('ENTREI C'); 

    this.commonServices.showLoader();
    try {
      let result = await this.httpUtilProvider.get(
        ENV.WS_PUBLIC+API_URL+ "geocode?endereco=" + endereco
      );

      console.log("getGeoLocalizacao");
      console.log(result);

      this.loadMap(result);

      this.commonServices.loading.dismiss();
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }

  loadMap(position) {

    console.log('ENTREI B'); 

    let latLng = new google.maps.LatLng(position.latitude, position.longitude);

    let mapOptions = {
      center: latLng,
      zoom: 15,
      disableDefaultUI: true
      // mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  }

  //clear markers before starting new search
  clearLocations() {
    console.log('ENTREI A'); 

    for (let mark of this.markers) {
      mark.setMap(null);
    }
    if (this.markers.length > 20) {
      this.markers = [];
    }
  }

  // calculateAndDisplayRoute() {
  // 	this.start = 'Av. Mal. Mascarenhas de Morais, 2967 - Imbiribeira, Recife - PE, 51150-905';
  // 	this.end = 'Rua Sa e SOuza,263 - Boa Viagem, Recife - PE, 51030-065';

  // 	this.directionsService.route({
  // 		origin: this.start,
  // 		destination: this.end,
  // 		travelMode: 'DRIVING'
  // 	}, (response, status) => {
  // 		if (status === 'OK') {
  // 			this.directionsDisplay.setDirections(response);
  // 		} else {
  // 			window.alert('A solicitação de rotas falhou devido a ' + status);
  // 		}
  // 	});
  // }
}

// by Ryuge 28/09/2019
export class address {
    cep: string; endereco: string; numero: string; bairro: string; cidade: string; uf: string; complemento: string; 
}
