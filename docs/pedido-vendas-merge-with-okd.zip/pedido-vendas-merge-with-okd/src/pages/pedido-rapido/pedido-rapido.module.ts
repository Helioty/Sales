import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HideKeyboardModule } from 'hide-keyboard';
import { IonicPageModule } from 'ionic-angular';
import { LongPressModule } from 'ionic-long-press';

import { DirectivesModule } from './../../directives/directives.module';
import { PipesModule } from './../../pipes/pipes.module';
import { PedidoRapido } from './pedido-rapido';

// import { IonicSwipeAllModule } from 'ionic-swipe-all';
// Import library
@NgModule({
  declarations: [
    PedidoRapido,
  ],
  imports: [
    IonicPageModule.forChild(PedidoRapido),
    PipesModule,DirectivesModule,TranslateModule,
    // IonicSwipeAllModule,
    LongPressModule,HideKeyboardModule
  ],
  exports: [
    PedidoRapido
  ]
})
export class  PedidoRapidoModule {}