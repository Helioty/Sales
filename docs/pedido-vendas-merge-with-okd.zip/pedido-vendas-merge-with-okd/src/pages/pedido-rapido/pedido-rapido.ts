import { Component, ViewChild } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { TranslateService } from '@ngx-translate/core';
import {
  AlertController,
  IonicPage,
  Item, ItemSliding,
  Keyboard,
  NavController,
  NavParams,
  Platform,
  ViewController
} from 'ionic-angular';
import 'rxjs/add/observable/fromEvent';
import "rxjs/add/operator/map";
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { Retiradas } from './../../class/class.pedido';
import { PedidoCab, PedidoItens } from './../../class/class.Pedido';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

// import { IonicSwipeAllModule } from 'ionic-swipe-all';

// import { Keyboard } from '@ionic-native/Keyboard';

// import { ShippingAddress_Listing } from '../../pages/cart/shippingAddress/shippingAddress';

// class

// declare var Honeywell: any;

@IonicPage()
@Component({
  selector: 'pedido-rapido-screen',
  templateUrl: 'pedido-rapido.html',
})

export class PedidoRapido {

  empresa;
  totalPedido: number = 0;
  value: any;
  selectedItem: any;
  ItemsPedido: any[];
  items: any;
  itdeleted;
  showButtonAdd: boolean = true;
  exibeProduto: boolean = false;
  isEnabled: boolean = true;
  itemsacola: any;
  modePageReturn;
  valueAtrib: any = '110%';
  overFlow: any = 'auto';

  // controle de requisições by Ryuge 28/11/2019
  maxRequest: number = 10;
  numRequest: number = 0;
  codProdRequest: any;


  subscription: Subscription;
  // private idScanner;
  private ativaBotaoAdd: boolean = false;
  private tipoEntrega;

  public pedidoItens: PedidoItens;
  public pedidoCab: PedidoCab;
  public retiradas: Retiradas;
  public qty: number = 1;
  public idPedido: any;
  private task;
  private codScanner: string = '';
  // public myCallbackFunction: any;
  public finalizar: boolean;
  public noCard: boolean;
  public TempoProc;
  public isDevelop: boolean = false;;

  @ViewChild('input') scanner: any;

  constructor(
    public platform: Platform,
    public navCtrl: NavController,
    public translateService: TranslateService,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    private alertCtrl: AlertController,
    // private menu: MenuController,
    public Keyb: Keyboard,
    // private barcodeScanner: BarcodeScanner,
    public viewCtrl: ViewController,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 28/11/2018
    this.isDevelop = ENV.mode == 'Development';

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.tipoEntrega = this.commonServices.tipoRetirada;
    this.modePageReturn = navParams.get('mode');

    window.addEventListener("contextmenu", (e) => { e.preventDefault(); });


  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }
    return idx;
  }

  ionViewDidEnter() {
    this.getItemPedido();
  }

  ionViewWillEnter() {

    this.goToFullScreen();

    // by Helio 26/12/2019
    this.commonServices.exibeBotaoComprar = true;

    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.exibeProduto = false;

    if (this.platform.is('ios') || this.platform.is('android')) {
      this.focusOn();
    }
  }

  HideKeyboard() {
    if (this.platform.is('ios') || this.platform.is('android')) {
      try {
        setTimeout(function () { this.Keyb.close() }, 0);
      } catch (error) {
        console.log(error)
      }
    }
  }

  presentAlert(msg) {
    let alert = this.alertCtrl.create({
      title: 'ATENÇÃO',
      subTitle: msg,
      buttons: [
        {
          text: 'Ok',
          handler: (data: any) => {
            this.getProdutoPorCodigodeBarra(this.scanner.value);
            //  this.scanner = '';
            //  this.scanner.setFocus();
          }
        }
      ]
    });
    alert.present();
  }

  focusOn() {
    this.isEnabled = true
    this.task = setInterval(() => {
      this.scanner.value = '';
      this.scanner.setFocus();
    }, 500);
  }

  ngOnInit() {
    // by Ryuge 28/11/2019

    this.subscription = Observable.fromEvent(document, 'keypress').subscribe((e: KeyboardEvent) => {

      if (e.keyCode != 13) {
        if (e.returnValue) {
          this.codScanner += e.key;
        }
      } else {
        this.scanner.setFocus();
        // console.log(this.codScanner);
        // this.getProdutoPorCodigodeBarra(this.codScanner);
        // this.codScanner = '';
      }

    });

  }

  async addItemPedido(pedidoBody) {

    try {

      // by ryuge 28/11/2018
      console.log('Timer Start');
      let pistolou = Date.now();

      let result: any = await this.httpUtilProvider.post2(ENV.WS_VENDAS + API_URL + 'PedidoVendaItem/' + localStorage.getItem('empresa') + '/'
        + this.commonServices.numPedido + '/addfast', pedidoBody)

      const buscou_info_e_montou = Date.now();

      console.log('ADD resut');
      console.log(result);

      this.commonServices.ItensPedidoAdd = result.pedido; // cabeçalho dp pedido
      this.totalPedido = result.pedido.totpedido;
      // this.exibeProduto = result.pedido.totpedido > 0;
      this.items = result.items.content;

      // by Helio 13/03/2020
      if (this.items.length > 0) {
        this.exibeProduto = true;
      }

      if (this.numRequest > 1) {
        this.numRequest -= 1;
      }

      // by ryuge 28/11/2018
      if (ENV.mode == 'Development') {
        let sec1 = buscou_info_e_montou - pistolou
        let sec2 = ((sec1 % 60000) / 1000);
        this.TempoProc = sec2;
        // this.commonServices.showAlert2('TEMPO PROCESSADO',sec2 );
      }

      // descomentado por helio 13/03/2020
      // this.getItemPedido();

    } catch (error) {

      // by Ryuge 28/11/2019
      if (error.status == 400) {
        await this.showMessage(error.json().title, error.json().detail);
      } else {
        // this.commonServices.showAlert2(error.json().title, error.json().detail);

        if (error.status == 503) {
          this.commonServices.showAlert3('Atenção!', 'Sem serviço, entrar em contato com suporte.');
        } else {
          if (error.json().detail != null) {
            this.commonServices.showAlert2(error.json().title, error.json().detail);
          } else {
            this.commonServices.showAlert2("Atenção!", error);
          }
        }
      }
    }
  }

  // by Ryuge 28/11/2019
  showMessage(titulo, msg) {
    if (this.isEnabled) {
      this.isEnabled = false;
      let alert = this.alertCtrl.create({
        title: titulo,
        subTitle: msg,
        buttons: [
          {
            text: 'ok',
            handler: () => {
              this.isEnabled = true;
              this.numRequest = 0;
            }
          }
        ]
      });
      alert.present();
    }
  }

  addItem(e: any) {

    try {

      // by Ryuge 27/11/2019 - Não permitir gravar item com pedido = '0';
      if (this.commonServices.numPedido != '0' || this.commonServices.numPedido != undefined) {

        let idPedido = this.commonServices.numPedido;
        this.empresa = localStorage.getItem('empresa');

        console.log('EMPRESA');
        console.log(this.empresa);

        //  Comentado por Ryuge 27/11/2018
        // this.pedidoItens = new PedidoItens(this.empresa, this.idPedido);
        // let codigo = e.target.value;
        // e.target.value = '';
        // this.getProdutoPorCodigodeBarra(codigo);

        // by ryuge 27/11/2018

        let tipo = this.commonServices.codigoTipoRetirada;
        let valor = 0;

        this.pedidoItens = new PedidoItens(this.empresa, this.idPedido);
        this.pedidoItens.idEmpresa = parseInt(this.empresa);
        this.pedidoItens.numPedido = parseInt(idPedido);
        this.pedidoItens.idProduto = e.target.value;
        this.pedidoItens.embalagem = 0;
        this.pedidoItens.qtdTotal = 0;
        this.pedidoItens.prcUnitario = 0;
        this.pedidoItens.prcTotal = 0;

        // this.adicionarSacola(tipo, valor);
        Promise.resolve(this.adicionarSacola(tipo, valor));
        e.target.value = ''; // by Ryuge 27/12/2018      

      }

    } catch (error) {
      // by Ryuge 27/11/2019
      if (error.status == 503) {
        this.commonServices.showAlert3('Atenção', 'Sem serviço, entrar em contato com suporte.');
      } else {
        this.commonServices.showAlert3('Atenção', error);
      }
    }

  }

  async getProdutoPorCodigodeBarra(codigo: any) {

    // this.commonServices.showLoader();

    try {

      if (codigo != '') {

        let dados;
        dados = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'list/'
          + localStorage.getItem('empresa')
          + '?filter=' + codigo);

        this.ItemsPedido = dados.content;

        console.log('ITEMS-PEDIDO');
        console.log(this.ItemsPedido);

        if (this.ItemsPedido) {

          console.log('ITEMS');

          let idPedido = this.commonServices.numPedido;
          let empresa = localStorage.getItem('empresa');

          let embalagem: string = this.ItemsPedido[0].codigodigitoembalagem;
          embalagem = embalagem.substr(embalagem.length - 1, 1);

          // this.valorProduto = this.items[0].prvd1;

          let tipo = this.commonServices.codigoTipoRetirada;
          let valor = this.ItemsPedido[0].prvd1;

          this.pedidoItens = new PedidoItens(empresa, this.idPedido);
          this.pedidoItens.idEmpresa = parseInt(empresa);
          this.pedidoItens.numPedido = parseInt(idPedido);
          this.pedidoItens.idProduto = this.ItemsPedido[0].codigodigitoembalagem;
          this.pedidoItens.embalagem = parseInt(embalagem);
          this.pedidoItens.qtdTotal = 0;
          this.pedidoItens.prcUnitario = 0;
          this.pedidoItens.prcTotal = 0;

          // this.commonServices.loading.dismiss();

          this.adicionarSacola(tipo, valor);
          this.ativaBotaoAdd = true;

        }

      }

    } catch (error) {
      // this.commonServices.loading.dismiss();
      console.debug(error);
    }

  }


  // by Ryuge 27/11/2019
  async adicionarSacola(tipo, valor) {
    let aRetiradas: any[] = [];
    try {

      this.retiradas = new Retiradas();
      this.retiradas.empresaRetirada = this.empresa;
      this.retiradas.idDeposito = 8;
      this.retiradas.tipoRetirada = parseInt(tipo);
      this.retiradas.qtd = 1;
      this.retiradas.precoUnitario = parseFloat(valor);

      console.log('this.retiradas');
      console.log(this.pedidoItens);

      //add array
      aRetiradas.push(this.retiradas);

      this.commonServices.sistuacaoPedido = 'A';  // altera situação do pedido
      this.pedidoItens.retiradas = aRetiradas;

      // by Ryuge 27/11/2019

      // controle de requisições para o mesmo produto escaneado
      if (this.codProdRequest == this.pedidoItens.idProduto) {
        this.numRequest += 1;
        if (this.numRequest <= this.maxRequest) {
          if (this.pedidoItens.retiradas != [] && this.pedidoItens.idProduto != null
            || this.pedidoItens.idProduto != '') {
            await this.addItemPedido(this.pedidoItens);
          }
        } else {
          this.commonServices.showToast('Favor aguarde processamento...');
        }

      } else {
        this.numRequest = 0;
        this.codProdRequest = this.pedidoItens.idProduto;
        if (this.pedidoItens.retiradas != [] && this.pedidoItens.idProduto != null
          || this.pedidoItens.idProduto != '') {
          await this.addItemPedido(this.pedidoItens);
        }
      }


    } catch (error) {
      // this.commonServices.showToast(error.json().detail);
      // by Ryuge 28/11/2019
      if (error.status == 503) {
        this.commonServices.showAlert3('Atenção', 'Sem serviço, entrar em contato com suporte.');
      } else {
        this.commonServices.showAlert3('Atenção', error);
      }
    }


  }

  async deleteItemPedido(codProduto) {

    try {
      this.itdeleted = await this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVendaItem/' + localStorage.getItem('empresa') + '/'
        + this.commonServices.numPedido + '/' + codProduto, {});
      console.log(this.itdeleted);

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }


  presentConfirm(item) {
    let alert = this.alertCtrl.create({
      title: 'Remover produto',
      message: 'Tem certeza que deseja remover o produto ' + item.descricao + ' do pedido?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Remover',
          handler: () => {
            this.deleteItemPedido(item.idProduto);
            this.removeItemList(item);

            this.exibeProduto = this.items.length > 0;

            // comentado por Helio 24/12/2019
            // // by Ryuge 04/01/2019
            // if (!this.exibeProduto) {
            //   // this.resizeElementHeight('OPEN')
            // }
            // console.log('confirmed clicked');
          }
        }
      ]
    });
    alert.present();
  }

  // Controla para qual tela retornar
  retornarPagina() {

    switch (this.modePageReturn) {
      case 1:
        this.navCtrl.pop();
        break;

      default:
        this.commonServices.exibeBotaoComprar = true;
        this.navCtrl.push("ProdutoLista");
        break;
    }

  }

  finalizaPedido() {

    // comentado por Ryuge 01/12/2018

    // if (this.commonServices.ItensPedidoAdd.informarCliente == 'S' || this.commonServices.tipoRetirada == 'ENTREGA') {
    //   if (this.commonServices.docCliente == '' && this.commonServices.nomeCliente == ''
    //     || this.commonServices.nomeCliente == 'Não Identificado') {
    //     this.navCtrl.push("Cliente", { back: "PedidoRapido", finalizar: true, callback: this.myCallbackFunction},{animate:false});
    //     return;
    //   }
    // }

    // if(!this.commonServices.cardSelected && !this.noCard){
    //   this.navCtrl.push("CartaoPedido",{back:"PedidoRapido", finalizar: true, callback: this.myCallbackFunction},{animate:false});
    //   return;
    // }else{
    //   this.navCtrl.push("FormasPagamento", {
    //     item: this.commonServices.ItensPedidoAdd
    //   })
    // }

    // by Ryuge 01/12/2018
    if (
      this.commonServices.ItensPedidoAdd.informarCliente == "S" ||
      this.commonServices.tipoRetirada == "ENTREGA"
    ) {
      if (
        ((this.commonServices.docCliente == "" &&
          this.commonServices.nomeCliente == "") ||
          this.commonServices.nomeCliente == "Não Identificado")
      ) {
        this.navCtrl.push("Cliente", { back: "PedidoRapido", finalizar: true }, { animate: false });
      } else {

        if (this.commonServices.tipoRetirada == "ENTREGA") {
          this.navCtrl.push("EntregaFrete", {
            item: this.commonServices.ItensPedidoAdd
          });
        } else {
          // by Ryuge 20/11/2019
          this.navCtrl.push("FormasPagamento", {
            item: this.commonServices.ItensPedidoAdd, mode: 2
          });
        }
      }
    } else {
      if (!this.commonServices.cardSelected && !this.noCard) {
        this.navCtrl.push("CartaoPedido", {
          back: "PedidoRapido",
          finalizar: true
        });
      } else {
        this.navCtrl.push("FormasPagamento", {
          item: this.commonServices.ItensPedidoAdd
        });
      }
    }

  }

  async getItemPedido() {

    try {

      // cabeçalho do pedido
      this.httpUtilProvider
        .getPedido(this.commonServices.numPedido)
        .then(result => {
          this.totalPedido = result.totpedido;
          // this.exibeProduto = result.totpedido > 0;
        });

      // item do pedido
      this.items = await this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
        'PedidoVendaItem/' + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido + '/itens');

      this.items = this.items.content;

      console.log('getItemPedido');
      console.log(this.items);

      // by Ryuge 07/12/2018
      if (this.items.length > 1) {
        this.exibeProduto = true;
        // this.resizeElementHeight('OPEN')
      } else {
        if (this.items.length == 1) {
          this.exibeProduto = true;
          // this.resizeElementHeight('LOCK')
        }
      }

      // if (this.items) {
      //   this.exibeProduto = this.items.length>0;
      //   this.totalPedido = this.items.totpedido;
      // }

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  removeItemList(item) {

    this.totalPedido = this.totalPedido - item.prcTotal;
    if (this.totalPedido < 0) {
      this.totalPedido = 0;
    }
    this.items.splice(this.items.indexOf(item), 1);
    // for (let i = 0; i < this.items.length; i++) {
    //   if (this.items[i] == item) {
    //     this.items.splice(i, 1);
    //   }
    // }
  }



  async editItemPedido(cod: string) {

    try {

      // cabeçalho do pedido
      this.httpUtilProvider
        .getPedido(this.commonServices.numPedido)
        .then(result => {
          this.pedidoCab = result;
        });

      this.itemsacola = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'list/'
        + localStorage.getItem('empresa')
        + '?filter=' + cod);
      this.itemsacola = this.itemsacola.content;

      this.navCtrl.push("PedidoAdicionarSacola", {
        item: this.itemsacola[0], headerPedido: this.pedidoCab, pedidoRapido: true, mode: 2
      })


    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  editItem(item) {

    try {
      this.editItemPedido(item.idProduto);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  };


  // by Helio
  ionDragEvent(event: any) {
    // console.log(event)
    this.focusOff()
    this.HideKeyboard()
    setTimeout(() => {
      this.focusOn()
    }, 300);
  }

  focusOff() {
    setTimeout(() => {
      this.scanner.setBlur()
    }, 100);
  }

  // by Helio 
  adicionaQuantidade(id: any) {
    try {
      // by Ryuge 27/11/2019 - Não permitir gravar item com pedido = '0';
      if (this.commonServices.numPedido != '0' || this.commonServices.numPedido != undefined) {

        let idPedido = this.commonServices.numPedido;
        this.empresa = localStorage.getItem('empresa');

        // by ryuge 27/11/2018
        let tipo = this.commonServices.codigoTipoRetirada;
        let valor = 0;

        this.pedidoItens = new PedidoItens(this.empresa, this.idPedido);
        this.pedidoItens.idEmpresa = parseInt(this.empresa);
        this.pedidoItens.numPedido = parseInt(idPedido);
        this.pedidoItens.idProduto = this.items[id].idProduto;
        this.pedidoItens.embalagem = 0;
        this.pedidoItens.qtdTotal = 0;
        this.pedidoItens.prcUnitario = 0;
        this.pedidoItens.prcTotal = 0;

        Promise.resolve(this.adicionarSacola(tipo, valor));

      }

    } catch (error) {
      // by Ryuge 27/11/2019
      if (error.status == 503) {
        this.commonServices.showAlert3('Atenção', 'Sem serviço, entrar em contato com suporte.');
      } else {
        this.commonServices.showAlert3('Atenção', error);
      }
    }
  }

  removeQuantidade(id: any) {

  }

  async removerSacola() {

  }

  async detalhesProduto(id: any) {
    this.commonServices.exibeBotaoComprar = false;
    let dados: any = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + "list/" + localStorage.getItem("empresa") + "?filter=" + id);
    let item: any[] = dados.content;

    this.navCtrl.push("ProdutoDetalhe", {
      item: item[0],
      // images: this.images,
      headerPedido: this.commonServices.pedidoHeader,
      mode: 1,
      modoConsulta: true
      // item: item, images: this.images, headerPedido: this.dados
    });
  }

  open(itemSlide: ItemSliding, item: Item) {
    // reproduce the slide on the click
    itemSlide.setElementClass("active-sliding", true);
    itemSlide.setElementClass("active-slide", true);
    itemSlide.setElementClass("active-options-right", true);
    item.setElementStyle("transform", "translate3d(-151px, 0px, 0px)");
  }

  // close(itemSlide: ItemSliding, item: Item) {
  //   if (itemSlide != undefined) {
  //     itemSlide.close();
  //     item.setElementStyle("transform", "translate3d(0px, 0px, 0px)");
  //     setTimeout(() => {
  //       itemSlide.setElementClass("active-slide", false);
  //       itemSlide.setElementClass("active-slide", false);
  //       itemSlide.setElementClass("active-options-right", false);
  //     }, 500);
  //   }
  // }

}
