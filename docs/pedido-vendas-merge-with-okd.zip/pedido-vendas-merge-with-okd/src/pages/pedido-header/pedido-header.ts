import { Component } from '@angular/core';
import { IonicPage, MenuController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-pedido-header',
  templateUrl: 'pedido-header.html'
})
export class PedidoHeader {
  item;
  constructor(
    params: NavParams,
    private menu: MenuController
  ) { 
    this.item = params.data.item;
  }

  ionViewDidLeave() {
    this.menu.swipeEnable(true);
  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }
 

}
