import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { PedidoHeader } from './pedido-header';
 
@NgModule({
  declarations: [
    PedidoHeader,
  ],
  imports: [
    IonicPageModule.forChild(PedidoHeader),
  ],
  exports: [
    PedidoHeader
  ]
})
export class  PedidoModule {}