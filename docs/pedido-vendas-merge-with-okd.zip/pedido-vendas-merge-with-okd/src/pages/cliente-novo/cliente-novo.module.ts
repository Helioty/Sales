import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClienteNovoPage } from './cliente-novo';


import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { IonicSwipeAllModule } from 'ionic-swipe-all';
import { LongPressModule } from 'ionic-long-press';

@NgModule({
  declarations: [
    ClienteNovoPage,
  ],
  imports: [
    IonicPageModule.forChild(ClienteNovoPage),
    PipesModule,DirectivesModule,
	  IonicSwipeAllModule,LongPressModule,
  ],
})
export class ClienteNovoPageModule {}
