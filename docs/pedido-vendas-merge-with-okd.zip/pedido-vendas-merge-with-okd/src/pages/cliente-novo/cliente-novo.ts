import { Component, NgZone, ViewChild } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { AlertController, Content, IonicPage, ModalController, NavController, NavParams } from 'ionic-angular';
import { Celular, Clientes, Email, Empresa, Endereco, Sequence, Telefone, Tipo } from "../../class/class.cliente";
import { PedidoTable } from '../../class/class.pedido';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "../../providers/http-util/http-util";
import { CommonServices } from "../../services/common-services";

/*
 
  Nova pagina de cadastro de cliente.
  by Hélio - 27/09/2019

*/

@IonicPage()
@Component({
  selector: 'page-cliente-novo',
  templateUrl: 'cliente-novo.html',
})
export class ClienteNovoPage {
  @ViewChild(Content) content: Content;
  public scroll: boolean;
  public showLoading: boolean = false;

  @ViewChild("campo1") campo1;  // campo nome
  @ViewChild("campo2") campo2;  // campo rg
  @ViewChild("campo3") campo3;  // campo email
  @ViewChild("campo4") campo4;  // campo celular
  @ViewChild("campo5") campo5;  // campo telefone

  @ViewChild("campo6") campo6;  // campo cep
  @ViewChild("campo7") campo7;  // campo rua
  @ViewChild("campo8") campo8;  // campo numero
  @ViewChild("campo9") campo9;  // campo complemento
  @ViewChild("campo10") campo10;  // campo bairro

  @ViewChild("campoUf") campoUf // campo UF
  @ViewChild("campoCidade") campoCidade // campo cidade


  // @ViewChild("selectProfissao") selectProfissao: Select; // select profissao

  // by Helio
  public tipoCadastro: any; // Novo ou Edicao
  public tipoCliente: any;  // CPF ou CNPJ


  // by Helio
  public cliente: any; // Dados do cliente ja cadastrado
  public identificadorCliente: any; // CPF ou CNPJ do cliente
  public showHeaderInfo: any; // CPF ou CNPJ formatado para exibicao


  // by Helio
  public showDados: boolean = true; // inicia a tela exibindo os dados
  public showEndereco: boolean = false; // para mostrar os dados de endereço
  public finalizaCadSkeleton: boolean = false; // esqueletom de finalização


  // dados do cliente
  public nome: any = "";
  public email: any = "";
  public celular: string = "";  // recebe o numero digitado com o ddd
  public telefone: string = ""; // recebe o numero digitado com o ddd

  // dados do endereço do cliente
  public cep: any;
  public endereco: string = "";
  public numero: any;
  public complemento: string = "";
  public bairro: string = "";
  public cidade: string = "";
  public uf: string = "";

  public ruaDisabled = false;
  public cidadeDisabled = false;
  public bairroDisabled = false;
  public colocouCep = true;


  // celular formatado em ddd e numero
  public ddd: any;
  public numeroCelular: any;  // recebe o numero digitado SEM o ddd
  public numeroTelefone: any; // recebe o numero digitado SEM o ddd


  // sequenciais
  public seq1: Sequence;
  public seq2: Sequence;
  public seq3: Sequence;

  // arrays dos dados abaixo
  public enderecos: Endereco;
  public telefones: Telefone;
  public celulares: Celular;
  public emails: Email;
  public empresa: Empresa;
  public tipo: Tipo;

  public aEmail: any;
  public aCelular: any;
  public aTelefone: any;

  // by Helio 13/03/2020
  public aEnderecos: any;

  // by Helio 08/10/2019
  // marcaras dinamicas
  public maskCelular: any;


  public isChecked: boolean = false;

  public retornar: any;
  public pedido: any;
  public finalizar: boolean = false;
  public callback: any;

  // by Helio 09/01/2020
  public novoPedidoEntrega: boolean = false;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    public androidFullScreen: AndroidFullScreen,
    public httpUtilProvider: HttpUtilProvider,
    public http: Http,
    public nZone: NgZone,
    public alertCtrl: AlertController,
    public modalCtrl: ModalController
  ) {

    this.goToFullScreen();
    // this.getProfissoes()

    this.cliente = new Clientes();
    this.seq1 = new Sequence;
    this.seq2 = new Sequence;
    this.seq3 = new Sequence;
    this.empresa = new Empresa();
    this.tipo = new Tipo();

    this.telefones = new Telefone;
    this.celulares = new Celular;
    this.emails = new Email();

    this.tipoCadastro = navParams.get("tipoCadastro")
    this.tipoCliente = navParams.get("tipoCliente")

    // by Helio 09/01/2020
    this.novoPedidoEntrega = this.navParams.get("pedidoEntrega")

    if (this.tipoCadastro == "novo") {
      this.colocouCep = false;
      if (this.tipoCliente == "cpf") {
        this.identificadorCliente = navParams.get("cpf")
        this.showHeaderInfo = this.commonServices.formata(this.identificadorCliente, "CPFCGC")
        setTimeout(() => {
          this.campo1.setFocus();
        }, 500);
      }
      else if (this.tipoCliente == "cnpj") {
        this.identificadorCliente = navParams.get("cnpj")
        this.showHeaderInfo = this.commonServices.formata(this.identificadorCliente, "CNPJ")
        setTimeout(() => {
          this.campo1.setFocus();
        }, 500);
      }
    }
    else if (this.tipoCadastro == "edicao") {
      if (this.tipoCliente == "cpf") {
        this.identificadorCliente = navParams.get("cpf")
        this.showHeaderInfo = this.commonServices.formata(this.identificadorCliente, "CPFCGC")
        this.getCliente(this.identificadorCliente);
      }
      else if (this.tipoCliente == "cnpj") {
        this.identificadorCliente = navParams.get("cnpj")
        this.showHeaderInfo = this.commonServices.formata(this.identificadorCliente, "CNPJ")
        this.getCliente(this.identificadorCliente);
      }

    }

    this.retornar = this.navParams.get("back");
    this.pedido = this.navParams.get("pedido");
    this.finalizar = this.navParams.get("finalizar");
    this.callback = this.navParams.get("callback");


  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  retornarPagina() {
    this.navCtrl.pop();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ClienteNovoPage');
  }
  ionViewDidEnter() {
    this.goToFullScreen();
  }

  // alertar usuario sobre campo invalido
  // by Helio 07/10/2019
  alertCampos(msg: string, campo: any) {
    let alert = this.alertCtrl.create({
      title: "Erro!",
      message: msg,
      buttons: [{
        text: "OK",
        handler: () => {

        }
      }]
    });
    alert.onDidDismiss(callback => { this.next(campo) })
    alert.present();
  }

  alertCamposNumero(msg: string) {
    let alert = this.alertCtrl.create({
      title: "Erro!",
      message: msg,
      buttons: [{
        text: "Celular",
        handler: () => {
          alert.onDidDismiss(callback => { this.next("celular") })
        }
      }, {
        text: "Telefone",
        handler: () => {
          alert.onDidDismiss(callback => { this.next("telefone") })
        }
      }]
    });
    alert.present();
  }


  // by Helio 08/10/2019
  // mascara dinamica
  dynamicMask(inputName: string) {
    console.log("dynamic")
    if (inputName == "celular") {
      if (this.celular != "") {
        let celular = this.celular.replace(/\D/g, '');
        console.log("Celular aqui!")
        console.log(celular)
        this.celular = this.commonServices.formata(celular, "FONE")
      }
    }
    else if (inputName == "tele") {
      if (this.telefone != "") {
        let telefone = this.telefone.replace(/\D/g, '');
        console.log("Telefone aqui!")
        console.log(telefone)
        this.telefone = this.commonServices.formata(telefone, "FONE")
      }
    }

  }

  // by ryuge 19/10/2018
  scrollToTop() {
    console.log("Scroll sim para TOP")
    this.content.scrollToTop();
  }
  // by ryuge 06/11/2018	
  scrollToBottom() {
    setTimeout(() => {
      this.content.scrollToBottom();
    });
    // this.content.resize();
  }
  // by ryuge 19/10/2018	
  // scrollTo(y: number) {
  //     console.log("Scroll sim para " + y)
  //     this.content.scrollTo(0, y, 200);
  // }


  // pegando os dados de um cliente ja cadastrado
  // by Helio 07/10/2019
  async getCliente(cli: any) {
    console.log("Cliente aqui!!")
    console.log(cli)

    // let dadosClienteExistente: any = await this.httpUtilProvider.getNoAlert(
    //   API_URL + ENV.WS_CRM + "cliente/" + cli);
    // console.log(dadosClienteExistente)

    let dadosClienteExistente = this.navParams.get("dadosCli")

    console.log("DADOS DO CLIENTE");
    console.log(dadosClienteExistente)

    this.nome = dadosClienteExistente.nome;
    console.log("nome")
    console.log(dadosClienteExistente.nome)

    // this.identidade = dadosClienteExistente.identidade;
    // console.log("identidade")
    // console.log(dadosClienteExistente.identidade)

    // this.profissao = dadosClienteExistente.tipo.description;
    // console.log("profissão")
    // console.log(dadosClienteExistente.tipo)

    if (dadosClienteExistente.emails.length > 0) {
      this.email = dadosClienteExistente.emails[0].email_site;
      console.log("email")
      console.log(dadosClienteExistente.emails[0].email_site)
    }

    // Pegando o celular de um cliente cadastrado
    if (dadosClienteExistente.celulares.length > 0) {
      if (dadosClienteExistente.celulares[0].ddd != null && dadosClienteExistente.celulares[0].numero != null) {
        this.celular = this.commonServices.formata(dadosClienteExistente.celulares[0].ddd + dadosClienteExistente.celulares[0].numero, "FONE");
        console.log("celular")
        console.log(dadosClienteExistente.celulares[0].ddd + dadosClienteExistente.celulares[0].numero)
      }
    }

    // Pegando o telefone de um cliente cadastrado
    if (dadosClienteExistente.telefones.length > 0) {
      if (dadosClienteExistente.telefones[0].ddd != null && dadosClienteExistente.telefones[0].numero != null) {
        this.telefone = this.commonServices.formata(dadosClienteExistente.telefones[0].ddd + dadosClienteExistente.telefones[0].numero, "FONE");
        console.log("telefone")
        console.log(dadosClienteExistente.telefones[0].ddd + dadosClienteExistente.telefones[0].numero)
      }
    }

    this.aEnderecos = dadosClienteExistente.enderecos;
    console.log("ENDERECOS AQUI VEI")
    console.log(dadosClienteExistente.enderecos)
    dadosClienteExistente.enderecos.forEach(ende => {
      if (ende.id.sequencialId === 0) {
        this.cep = ende.ds_cep;
        this.endereco = ende.ds_ende;
        this.numero = ende.nu_ende;
        this.complemento = ende.ds_compl;
        this.bairro = ende.ds_bairro;
        this.cidade = ende.cidade;
        this.uf = ende.ds_uf;
      }
    });

    this.cliente.cgccpf = dadosClienteExistente.cgccpf;
    this.cliente.identidade = dadosClienteExistente.identidade;
    this.cliente.nome = dadosClienteExistente.nome;
    this.cliente.natureza = dadosClienteExistente.natureza;
    this.cliente.empresa = dadosClienteExistente.empresa;
    this.cliente.tipo = dadosClienteExistente.tipo;
    this.cliente.emails = dadosClienteExistente.emails;
    this.cliente.celulares = dadosClienteExistente.celulares;
    this.cliente.telefones = dadosClienteExistente.telefones;
    this.cliente.cep = dadosClienteExistente.enderecos[0].ds_cep;
    this.cliente.endereco = dadosClienteExistente.enderecos[0].ds_ende;
    this.cliente.numero = dadosClienteExistente.enderecos[0].nu_ende;
    this.cliente.complemento = dadosClienteExistente.enderecos[0].ds_compl;
    this.cliente.bairro = dadosClienteExistente.enderecos[0].ds_bairro;
    this.cliente.cidade = dadosClienteExistente.enderecos[0].cidade;
    this.cliente.uf = dadosClienteExistente.enderecos[0].ds_uf;
  }

  toDadosToEndereco() {
    this.showDados = !this.showDados;
    this.showEndereco = !this.showEndereco;
    this.finalizaCadSkeleton = false;
  }


  // by Ryuge 03/12/2018
  // edit by Helio 01/10/2019
  // funcão para trocar o foco ao apertar enter
  next(campo: any) {
    this.goToFullScreen();

    if (campo == 'nome') {
      setTimeout(() => {
        this.campo1.setFocus();
      }, 100);
    }
    if (campo == 'rg') {
      setTimeout(() => {
        this.campo2.setFocus();
      }, 100);
    }
    if (campo == 'email') {
      setTimeout(() => {
        this.campo3.setFocus();
      }, 100);
    }
    if (campo == 'celular') {
      setTimeout(() => {
        this.campo4.setFocus();
      }, 100);
    }
    if (campo == 'telefone') {
      setTimeout(() => {
        this.campo5.setFocus();
      }, 100);
    }


    if (campo == 'cep') {
      setTimeout(() => {
        this.campo6.setFocus();
      }, 500);
    }
    if (campo == 'rua') {
      setTimeout(() => {
        this.campo7.setFocus();
      }, 150);
    }
    if (campo == 'numero') {
      setTimeout(() => {
        this.campo8.setFocus();
      }, 150);
    }
    if (campo == 'complemento') {
      setTimeout(() => {
        this.campo9.setFocus();
      }, 150);
    }
    if (campo == 'bairro') {
      setTimeout(() => {
        this.campo10.setFocus();
      }, 150);
    }
    if (campo == 'uf') {
      setTimeout(() => {
        this.campoUf.setFocus();
      })
    }
    if (campo == 'cidade') {
      setTimeout(() => {
        this.campoCidade.setFocus();
      }, 150);
    }
  }

  // by Helio 01/10/2019
  // abrirSelect() {
  //   this.selectProfissao.open();
  // }


  // by Helio 02/10/2019
  scrollNow(id: any) {
    //------------------------------------------------------------------//
    // by Helio 02/10/2019
    // move o scroll da tela
    if (id == "campo1") {
      this.content.scrollTo(0, 0, 200);
    }
    else if (id == "campo2") {
      this.content.scrollTo(0, 72, 200);
    }
    else if (id == "campo3") {
      this.content.scrollTo(0, 73, 200);
    }
    else if (id == "campo4") {
      this.content.scrollTo(0, 140, 200);
    }
    else if (id == "campo5") {
      this.content.scrollTo(0, 212, 200);
    }
    else if (id == "campo6") {
      this.content.scrollTo(0, 0, 200);
    }
    else if (id == "campo7") {
      this.content.scrollTo(0, 100, 200);
    }
    else if (id == "campo8") {
      this.content.scrollTo(0, 165, 200);
    }
    else if (id == "campo9") {
      this.content.scrollTo(0, 228, 200);
    }
    else if (id == "campo10") {
      this.content.scrollTo(0, 300, 200);
    }
    else if (id == "campo11") {
      this.content.scrollTo(0, 365, 200);
    }
    //------------------------------------------------------------------//
  }

  // by Helio 02/10/2019 
  // adiciona classe CSS em um objeto 
  addClass(id: string, classe: string) {
    // console.log(this.content)

    var elemento = document.getElementById(id);
    var classes = elemento.className.split(' ');
    var getIndex = classes.indexOf(classe);

    if (getIndex === -1) {
      classes.push(classe);
      elemento.className = classes.join(' ');
    }
  }

  // by Helio 02/10/2019  
  // remove classe CSS de objeto 
  delClass(id: string, classe: string) {
    var elemento = document.getElementById(id);
    var classes = elemento.className.split(' ');
    var getIndex = classes.indexOf(classe);

    if (getIndex > -1) {
      classes.splice(getIndex, 1);
    }
    elemento.className = classes.join(' ');
  }


  // by Ryuge
  // async getProfissoes() {
  //   try {
  //     let result: any = await this.httpUtilProvider.get(
  //       API_URL + ENV.WS_COMMONS + "AreaAtuacao/list/profissoes"
  //     );
  //     this.profissoes = result.content;
  //     console.log('Lista Profissoes');
  //     console.log(this.profissoes);
  //   } catch (error) {
  //     this.commonServices.showToast(error.json().detail);
  //   }
  // }


  validar_CPF_CNPJ(e: any) {
    // by Ryuge 20/12/2018
    if (e.target.value != '') {
      let doc = e.target.value.replace(/\D/g, "");

      if (doc.length > 11) {
        if (!this.commonServices.validarCNPJ(e.target.value)) {
          this.commonServices.showAlert2("Erro!", "Número de CNPJ inválido!");
          // this.focusOn();
        } else {
          // by Ryuge 23/10/2018
          // this.getCliente(e);
        }
      } else {
        if (!this.commonServices.validCPF(e.target.value)) {
          this.commonServices.showAlert2("Erro!", "Número de CPF inválido!");
          // this.focusOn();
        } else {
          // by Ryuge 23/10/2018
          // this.getCliente(e);
        }
      }
    }
  }

  // validar nome do cliente
  validateFieldNome(e: any) {
    let isName = e == '';
    console.log(isName);
    if (this.nome.length < 1) {
      console.log("Nome vazio")
      this.alertCampos("O campo nome deve ser preenchido!", "nome")
      return false
    };
    return true
  }

  // valida o email
  // by Ryuge
  validarEmail(e: any) {
    console.log("validando")
    if (e != '') {
      if (!this.commonServices.validateEmail(e)) {

        // this.commonServices.showToastTop('Email inválido.');
        let task = setInterval(() => {
          clearInterval(task);
          this.campo3.setFocus();
        }, 1000);
        return false
      }
      else {
        return true
      }
    }
  }

  // verifica se o campo da profissão está nulo
  // verificaProfissaoNull() {
  //   console.log(this.profissao)
  //   if (this.profissao == null || this.profissao == "" || this.profissao == undefined) {
  //     console.log("Escolha cancelada")
  //   } else {
  //     this.next('email')
  //     console.log("Selecionado")
  //   }
  // }


  // formatando o numero de celular caso ele esteja ou não com a mascara
  // by Helio 07/10/2019
  validarDddNumero() {
    let celular = this.celular.replace(/\D/g, '');
    this.celulares.id = this.seq2; // Quando for um novo registro add+1 no sequencial
    this.celulares.ddd = celular.substring(0, 2);
    this.celulares.numero = celular.substring(2);
    this.celulares.tipo = "TITULAR";
    this.celulares.subtipo = "CELULAR";
    this.aCelular = [this.celulares]
  }
  validarDddTele() {
    let telefone = this.telefone.replace(/\D/g, '');
    this.telefones.id = this.seq3; // Quando for um novo registro add+1 no sequencial
    this.telefones.ddd = telefone.substring(0, 2);
    this.telefones.numero = telefone.substring(2);
    this.telefones.tipo = "TITULAR";
    this.telefones.subtipo = "TELEFONE";
    this.aTelefone = [this.telefones];
  }

  // vereficando se um dos numeros de contato foi preenchido
  // by Helio 08/10/2019
  async validateFieldCelTelefone() {
    let celular = await this.validateFieldPhone()
    let telefone = await this.validateFieldTelefone()
    if (celular && telefone) {
      this.validarDddNumero()
      this.validarDddTele()
      return true;
    }
    else if (celular && !telefone) {
      this.validarDddNumero()
      this.aTelefone = [];
      return true;
    }
    else if (!celular && telefone) {
      this.validarDddTele()
      this.aCelular = [];
      return true;
    }
    else {
      // this.alertCamposNumero("Pelo menos um número deve ser informado!")
      this.aTelefone = [];
      this.aCelular = []
      return true;
    }
  }

  // validação do numero de celular
  // edit by Helio 08/10/2019
  validateFieldPhone() {
    if (this.celular == "") {
      console.log("Celular vazio")
      // this.alertCamposNumero("O campo celular deve ser preenchido!", "celular")
      return false
    }
    else {
      let celular = this.celular.replace(/\D/g, "");
      if (celular.length >= 10) {
        console.log("Numero valido!");
        return true
      }
      else {
        // this.commonServices.showToastTop("Celular invalido")
        return false
      }
    }
  }

  // validação do numero de telefone
  // edit by Helio 08/10/2019
  validateFieldTelefone() {
    if (this.telefone == "") {
      console.log("Telefone vazio")
      // this.alertCamposNumero("O campo celular deve ser preenchido!", "telefone")
      return false
    }
    else {
      let telefone = this.telefone.replace(/\D/g, "");
      if (telefone.length >= 10) {
        console.log("Numero valido!");
        return true
      }
      else {
        // this.commonServices.showToastTop("Telefone invalido")
        return false
      }
    }
  }


  // validando os campos antes de prosseguir parar o endereço
  // by Helio 07/10/2019
  async validarCampos() {
    let statusValidacao: boolean;

    // sequenciais
    this.seq1.clienteId = this.identificadorCliente.replace(/\D/g, "");
    this.seq2.clienteId = this.identificadorCliente.replace(/\D/g, "");
    this.seq3.clienteId = this.identificadorCliente.replace(/\D/g, "");

    // validando nome 
    console.log("validando nome")
    let statusNome = await this.validateFieldNome(this.nome)
    if (statusNome) {
      // this.commonServices.showToastTop("Nome Valido")
      statusValidacao = true;
      console.log("validando nome: " + statusValidacao)
      if (this.nome.length < 4) {
        statusValidacao = false;
        this.alertCampos("O campo nome deve conter pelo menos 4 caracteres!", "nome")
        return statusValidacao;
      }
    } else {
      statusValidacao = false;
      console.log("validando nome: " + statusValidacao)
      return statusValidacao;
    }


    // validação de email
    console.log("validando email")
    let statusEmail = await this.validarEmail(this.email)
    if (statusEmail) {
      // this.commonServices.showToastTop("Email Valido")
      statusValidacao = true;

      // caso email não seja informado
      if (this.email == "" || this.email == undefined) {
        this.aEmail = [];
      }
      else {
        this.seq1.sequencialId = 99;
        this.emails.id = this.seq1; // Quando for um novo registro add+1 no sequencial
        this.emails.email_site = this.email;
        this.emails.tipo = "TITULAR";
        this.emails.subtipo = "EMAIL";

        this.aEmail = [this.emails];
      }
      console.log("validando email: " + statusValidacao)
    }
    else {
      this.aEmail = [];
    }


    // validando celular e/ou telefone
    console.log("validando celular e/ou telefone")
    let statusPhone = await this.validateFieldCelTelefone()
    if (statusPhone) {
      // this.commonServices.showToastTop("Celular Valido")
      statusValidacao = true;
      console.log("validando celular: " + statusValidacao)
    } else {
      // this.commonServices.showToastTop("Celular invalido")
      statusValidacao = false;
      console.log("validando celular: " + statusValidacao)
      return statusValidacao;
    }

    return statusValidacao;
  }



  async continuar() {
    // this.commonServices.showLoader()
    let a = await this.validarCampos()
    if (a) {
      if (this.tipoCadastro == "novo") {
        this.empresa.id = parseInt(localStorage.getItem("empresa"));
        this.tipo = null;

        this.cliente.cgccpf = this.identificadorCliente.replace(/\D/g, "");
        this.cliente.identidade = null;
        this.cliente.nome = this.nome;
        this.cliente.natureza = "FISICA";
        this.cliente.empresa = this.empresa;
        this.cliente.tipo = this.tipo;
        this.cliente.emails = this.aEmail;
        this.cliente.celulares = this.aCelular;
        this.cliente.telefones = this.aTelefone;

        console.log("Continuou")
        console.log(this.cliente)

        this.showDados = false;
        this.showEndereco = true;
        this.next("cep")

        // this.navCtrl.push("NovaEntrega", { tipo: "novo", dadosCli: cliente, back: this.retornar, pedido: this.pedido, finalizar: this.finalizar, callback: this.callback })
      }
      else {
        this.empresa.id = parseInt(localStorage.getItem("empresa"));
        this.tipo = this.cliente.tipo;

        this.cliente.cgccpf = this.identificadorCliente.replace(/\D/g, "");
        this.cliente.identidade = null;
        this.cliente.nome = this.nome;
        this.cliente.natureza = "FISICA";
        this.cliente.empresa = this.empresa;
        this.cliente.tipo = this.tipo;
        this.cliente.emails = this.aEmail;
        this.cliente.celulares = this.aCelular;
        this.cliente.telefones = this.aTelefone;

        console.log("Continuou")
        console.log(this.cliente)

        this.showDados = false;
        this.showEndereco = true;
        // this.navCtrl.push("NovaEntrega", { tipo: "edicao", dadosCli: cliente, back: this.retornar, pedido: this.pedido, finalizar: this.finalizar, callback: this.callback })
      }
    }
    else {
      console.log("Deu ruim!")
    }
    // this.commonServices.dismiss()
  }




  //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
  // Endereço

  pesquisaCEP() {
    let mymodal = this.modalCtrl.create('ConsultaCep', { modoConsulta: false }, {
      showBackdrop: false,
      enterAnimation: 'modal-md-slide-in',
      leaveAnimation: 'modal-md-slide-out',
    });
    mymodal.onDidDismiss(data => {
      if (data) {

        this.cep = this.commonServices.formata(data.cep, 'CEP');
        this.numero = data.numero;
        this.complemento = data.complemento;
        // this.exibeButaoNext = this.cep != '';
        this.getCep2(this.cep);
      }
    })
    mymodal.present();
  }


  getCep2(cep: string) {
    this.showLoading = true;

    if (cep == '') {
      console.log("Sem cep")
      this.showLoading = false;
      this.alertCampos("Informe um CEP", "cep")
    } else {

      // this.clearFields(); // limpa campos
      // this.showSkeleton = true;
      let valor: any = cep;
      valor = valor.replace(/\D/g, ''); // remove mascara

      let headers = new Headers();
      headers.append('x-auth-token', localStorage.getItem('token'));
      let options = new RequestOptions({ headers: headers });

      return new Promise(resolve => {
        this.http.get(ENV.WS_PUBLIC + API_URL + 'consultaCEP/' + valor, options).subscribe(data => {
          resolve(data);
          console.log(data.json());
          let dados = data.json();
          this.cep = this.commonServices.formata(valor, 'CEP');
          this.endereco = dados.logradouro;
          if (this.endereco) {
            this.ruaDisabled = true;
          } else {
            this.ruaDisabled = false;
          }
          this.bairro = dados.bairro;
          if (this.bairro) {
            this.bairroDisabled = true;
          } else {
            this.bairroDisabled = false;
          }
          this.uf = dados.estado;
          this.cidade = dados.cidade;
          if (this.cidade) {
            this.cidadeDisabled = true;
          } else {
            this.cidadeDisabled = false;
          }

          this.nZone.run(() => {
            this.finalizaCadSkeleton = false;
          })

          this.colocouCep = true;
          document.getElementById('cepInput').blur();

          this.showLoading = false;
          setTimeout(() => {
            this.campo6.setBlur()
          }, 50);

        }, err => {
          this.showLoading = false;
          this.finalizaCadSkeleton = false;
          console.log(err);
          if (err.status == 404) {
            this.alertCampos("Endereço não encontrado!", "cep");
          }
        });
      });
    }
  }



  // ação do botão finalizar
  // by Helio 09/10/2019
  finalizarCadastroCli() {

    // by Ryuge 19/11/2019
    try {

      this.finalizaCadSkeleton = true;
      this.showLoading = true;
      console.log(this.cliente)

      // cep
      if (this.cep.length > 0) {
        this.cliente.cep = this.cep.replace(/\D/g, "");
      }
      else {
        this.alertCampos("Informe um cep valido", "cep")
        this.finalizaCadSkeleton = false;
        this.showLoading = false;
        return
      }

      // uf
      if (this.uf != null && this.uf.length > 0) {
        this.cliente.uf = this.uf;
      }
      else {
        this.alertCampos("Informe o estado", "uf")
        this.finalizaCadSkeleton = false;
        this.showLoading = false;
        return
      }

      // cidade
      if (this.cidade != null && this.cidade.length > 0) {
        this.cliente.cidade = this.cidade;
      }
      else {
        this.alertCampos("Informe a cidade", "cidade")
        this.finalizaCadSkeleton = false;
        this.showLoading = false;
        return
      }

      // endereço
      if (this.endereco != null && this.endereco.length > 0) {
        this.cliente.endereco = this.endereco;
      }
      else {
        this.alertCampos("Informe um endereço!", "rua")
        this.finalizaCadSkeleton = false;
        this.showLoading = false;
        return
      }

      // numero
      this.cliente.numero = this.numero;

      // complemento
      this.cliente.complemento = this.complemento;

      // bairro
      if (this.bairro.length > 0) {
        this.cliente.bairro = this.bairro;
      }
      else {
        this.alertCampos("Informe o bairro", "bairro")
        this.finalizaCadSkeleton = false;
        this.showLoading = false
        return
      }

      if (this.aEnderecos === undefined) {
        this.cliente.enderecos = [];
      } else{
        this.cliente.enderecos = this.aEnderecos;
      }

      console.log('THIS.CLIENTE');
      console.log(this.cliente);
      this.cadastraCliente(this.cliente);

    } catch (error) {
      // by Ryuge 19/11/2019
      this.finalizaCadSkeleton = false;
      this.showLoading = false
      if (error.status == 400) {
        this.commonServices.showToast(error.json().detail);
        console.log('400')
        console.log(error);
      } else {

        if (error.status == 503) {
          this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
          console.log('503')
          console.log(error);
        } else {
          this.commonServices.showToast(error);
          console.log('err')
          console.log(error);
        }

      }
    }

  }

  //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
  // Finalização

  async cadastraCliente(cli: any) {

    try {
      let headers = new Headers();
      headers.append("x-auth-token", localStorage.getItem("token"));
      let options = new RequestOptions({ headers: headers });

      console.log(cli);

      return await new Promise(() => {
        this.http
          .post(ENV.WS_CRM + API_URL + "cliente/save/", cli, options)
          .subscribe(
            data => {
              if (!this.commonServices.isEmptyObject(data)) {
                this.saveAll(cli);
                // this.atualizaCadastro = false;
              }
            },
            err => {
              this.commonServices.showAlert2(err.json().title, err.json().detail);
              this.finalizaCadSkeleton = false;
              this.showLoading = false
              this.alertCampos("Falha de processamento, tente novamente", "")
            }
          );
      });
    }
    catch (error) {
      this.finalizaCadSkeleton = false;
      this.showLoading = false;
    }

  }


  saveAll(cli: any) {
    this.commonServices.pedidoAtualizado.cliente = cli.cgccpf;
    this.commonServices.pedidoAtualizado.seq_endereco_entrega = cli.id;
    this.commonServices.nomeCliente = cli.nome;
    this.commonServices.docCliente = cli.cgccpf;

    let table: PedidoTable = new PedidoTable();
    table.name = "cliente";
    table.value = cli.cgccpf;
    let aResult = [];
    aResult.push(table);

    let headers = new Headers();
    headers.append("x-auth-token", localStorage.getItem("token"));
    let options = new RequestOptions({ headers: headers });

    this.http
      .post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult,
        options
      )
      .subscribe(
        data => {
          // this.validarCliente = true;
          this.commonServices.clientSelected = true;

          // by Helio 09/01/2020
          if (this.novoPedidoEntrega) {
            return this.navCtrl.push("NovaEntrega", { item: this.commonServices.ItensPedidoAdd, modulo: 5 });
          }

          // teste
          // by Ryuge 07/01/2019
          if (this.retornar == "PedidoRetirada" && this.finalizar == true) {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.pedido });
          }

          if (this.retornar == "PedidoSacola") {
            this.navCtrl.push("PedidoSacola", { finalizar: this.finalizar });
          } else if (this.retornar == "PedidoRapido") {
            this.navCtrl.pop();
          }
          else {
            // if (!this.existDados) {
            // 	this.exibeCadastro = false;
            // } 
            // else {
            let itPedido;
            let idxPedido;
            if (this.commonServices.sistuacaoPedido == "A") {
              itPedido = this.commonServices.itemPedidoAberto.content;
              idxPedido = this.getIndexPedido(
                this.commonServices.numPedido,
                itPedido
              );
            } else {
              itPedido = this.commonServices.itemPedidoFinalizado.content;
              idxPedido = this.getIndexPedido(
                this.commonServices.numPedido,
                itPedido
              );
            }
            // }
            this.navCtrl.push("CartaoPedido", { back: "Cliente", finalizar: this.finalizar });
          }
          // this.disabled = false;

        },
        error => {
          this.commonServices.showAlert2(
            error.json().title,
            error.json().detail
          );

          // this.validarCliente = false;
          this.commonServices.cardSelected = false;

          this.commonServices.nomeCliente = "";
          this.commonServices.docCliente = "";
          this.commonServices.pedidoAtualizado.cliente = "";
          this.commonServices.pedidoAtualizado.seq_endereco_entrega = "";

          // this.disabled = false;
          this.navCtrl.pop();
        }
      );
  }
  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }
    return idx;
  }


}
