import { Component } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoCab, PedidoItens } from './../../class/class.Pedido';
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

// class
@IonicPage()
@Component({
  selector: 'pedido-retirada',
  templateUrl: 'pedido-retirada.html'
})
export class PedidoRetirada {

  item: any;
  selected;

  public modePageReturn = 0;
  public pedido;
  public images;
  public PedidoCab: PedidoCab;
  public pedidoItens: PedidoItens;
  public pedidoNovo: PedidoCab;
  public isUpdated: boolean = false; // by Ryuge 27/12/2018
  public isDisabled: boolean = false; // by Ryuge 03/01/2019
  public unregisterBackButtonAction: any;

  constructor(
    public navCtrl: NavController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public navParams: NavParams,
    // private _http: Http,
    // private menu: MenuController,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);

    this.modePageReturn = this.navParams.get("modulo");

    console.log(this.modePageReturn);

    if (this.modePageReturn == undefined || this.modePageReturn == 0) {
      // cria um novo pedido
      this.criarPedido();
      this.commonServices.statusPedido = 'I';
    }

  }


  // by Ryuge 03/01/2018
  ionViewDidLoad() {
    this.platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);
    this.isDisabled = false;
  }


  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  // by Ryuge 29/11/2018
  retornarPagina() {

    switch (this.modePageReturn) {
      case 1:
        // by Ryuge 07/01/2019
        if (
          (this.commonServices.docCliente == "" &&
            this.commonServices.nomeCliente == "") && this.commonServices.pedidoHeader.informarCliente == "S" ||
          this.commonServices.nomeCliente == "Não Identificado" && this.commonServices.pedidoHeader.informarCliente == "S"
        ) {
          this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true });
        } else {
          if (this.commonServices.tipoRetirada == "ENTREGA") {
            this.navCtrl.pop();
          } else {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.pedidoHeader, modulo: 1 });
          }

        }
        break;
      case 2:
        this.navCtrl.pop();
        break;
      default:
        let status: boolean = true;
        this.navCtrl.setRoot("PedidoLista", { refresh: status });
        this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
        break;
    }
  }


  // by Ryuge 26/12/2018
  gravaPedido(parameters: string, body: {}) {

    return new Promise((resolve, reject) => {
      // let headers = new Headers();

      // headers.append("x-auth-token", localStorage.getItem("token"));
      // let options = new RequestOptions({ headers: headers });
      this.httpUtilProvider
        .post(parameters, body)
        .then(
          (result: any) => {
            resolve(result);
          },
          error => {
            this.isDisabled = true
            this.commonServices.showAlert2(error.json().title, error.json().detail);
            reject(error.json());
          }
        );
    });

  }

  // by Ryuge 18/12/2018
  async atualizaPedido() {
    try {
      let aResult = [];

      let table: PedidoTable = new PedidoTable();
      table.name = "entrega";
      table.value = this.commonServices.tipoRetirada;
      aResult.push(table);

      // by Ryuge 27/12/2018
      // let result: any = await this.httpUtilProvider.post(
      //   ENV.WS_VENDAS +
      //   "PedidoVenda/update/" +
      //   localStorage.getItem("empresa") +
      //   "/" +
      //   this.commonServices.numPedido,
      //   aResult
      // );

      // by Ryuge 27/12/2018
      let result: any = await this.gravaPedido(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      );


      console.log('atualizaPedido');
      console.log(result);

      this.commonServices.pedidoHeader = result;

      if (this.commonServices.tipoRetirada == "ENTREGA") {
        if (
          ((this.commonServices.docCliente == "" &&
            this.commonServices.nomeCliente == "") ||
            this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
        ) {
          // by Ryuge 07/01/2019
          if (this.modePageReturn == 1) {
            this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true });
          }
          else {
            this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: false });
          }

        } else {
          // by Ryuge 09/01/2019
          if (
            (this.commonServices.docCliente == "" &&
              this.commonServices.nomeCliente == "") ||
            this.commonServices.nomeCliente == "Não Identificado") {

            if (this.modePageReturn == 1) {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true });
            }
            else {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: false });
            }

          } else {
            let tms = localStorage.getItem("tms");
            if (tms == 'true') {
              this.navCtrl.push("NovaEntrega", {
                item: this.commonServices.pedidoHeader, modulo: 2
              });
            } else {
              this.navCtrl.push("EntregaFrete", {
                item: this.commonServices.pedidoHeader, modulo: 1
              });
            }
          }

        }
      } else {

        console.log('teste');
        console.log(this.commonServices.statusPedido);

        // by Ryuge 26/12/2018
        if (this.commonServices.statusPedido == 'I') {
          console.log('teste A');
          this.retornarPagina();
        }
        else {

          console.log('teste B');
          // alert('CLIENTE: '+this.commonServices.pedidoHeader.informarCliente);

          // by Ryuge 07/01/2019
          if (
            ((this.commonServices.docCliente == "" &&
              this.commonServices.nomeCliente == "") ||
              this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
          ) {
            // by Ryuge 07/01/2019
            if (this.modePageReturn == 1) {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true });
            }
            else {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: false });
            }
          } else {
            this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.pedidoHeader, modulo: 1 });
          }

        }
      }

    } catch (error) {
      console.log(error);
    }

  }

  openProductListingPage(retirada) {
    this.commonServices.sistuacaoPedido = "A";
    this.selected = retirada;

    this.commonServices.codigoTipoRetirada = retirada;
    this.commonServices.tipoRetirada = this.commonServices.opcaoRetirada[retirada];

    // console.log(retirada);
    // console.log(this.commonServices.tipoRetirada);

    // atualiza objeto pedidoAtualizado
    // by Ryuge 27/12/2018
    if (this.commonServices.pedidoAtualizado.entrega == 'ENTREGA'
      && this.commonServices.pedidoAtualizado.entrega != this.commonServices.pedidoAtualizado.entrega) {
      this.isUpdated = true;
    } else {
      this.isUpdated = false;
    }

    this.commonServices.pedidoAtualizado.entrega = this.commonServices.tipoRetirada;

    this.commonServices.exibeBotaoComprar = true;

    // by Ryuge 29/11/2018 
    if (this.modePageReturn == 1) {

      // by Ryuge 18/12/2018
      try {
        this.atualizaPedido();

        // by Ryuge 27/12/2018 *** comentado provisoriamente
        if (this.isUpdated) {
          this.navCtrl.push("FormasPagamento", {
            item: this.pedido, mode: 3
          });
        }

      }
      catch (error) {
        console.log(error);
      }

    } else {

      // by Ryuge 14/11/2019
      if (this.commonServices.tipoRetirada == "ENTREGA") {
        if (
          ((this.commonServices.docCliente == "" &&
            this.commonServices.nomeCliente == "") ||
            this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
        ) {
          // by Ryuge 07/01/2019
          if (this.modePageReturn == 1) {
            this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true, pedidoEntrega: true });
          }
          else {
            this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: false, pedidoEntrega: true });
          }

        } else {
          // by Ryuge 21/11/2019
          if (
            (this.commonServices.docCliente == "" &&
              this.commonServices.nomeCliente == "") ||
            this.commonServices.nomeCliente == "Não Identificado" && this.commonServices.pedidoHeader.informarCliente == "S") {

            if (this.modePageReturn == 1) {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: true, pedidoEntrega: true });
            }
            else {
              this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader, finalizar: false, pedidoEntrega: true });
            }

          } else {
            let tms = localStorage.getItem("tms");
            if (tms == 'true') {
              this.navCtrl.push("NovaEntrega", {
                item: this.commonServices.pedidoHeader, modulo: 2
              });
            } else {
              this.navCtrl.push("EntregaFrete", {
                item: this.commonServices.pedidoHeader, modulo: 1
              });
            }
          }

        }
      } else {
        let currentIndex = this.navCtrl.getActive().index;
        this.navCtrl.push("ProdutoLista", {
          tiporetirada: retirada, dados: this.pedido, mode: 0
        }).then(() => {
          this.navCtrl.remove(currentIndex);
        });

      }
    }
  }

  criarPedido() {
    return new Promise((resolve, reject) => {
      // let headers = new Headers();
      // headers.append('X-Auth-Token', localStorage.getItem('token'));

      this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/' + localStorage.getItem('empresa') + '/criar', {})
        .then(res => {
          // this.pedido = res.json();
          // this.commonServices.numPedido = this.pedido.id;
          this.commonServices.pedidoHeader = res;

          console.log('PEDIDO NOVO');
          console.log(this.commonServices.pedidoHeader);

          this.commonServices.numPedido = this.commonServices.pedidoHeader.numpedido;
          this.commonServices.digitoPedido = this.commonServices.pedidoHeader.digito;

        }, (err) => {
          // reject(err);
          this.commonServices.showToast(err.json().detail);
        });
    });
  }


}
