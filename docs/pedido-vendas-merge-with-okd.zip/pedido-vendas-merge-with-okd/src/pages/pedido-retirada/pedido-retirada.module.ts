import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { PipesModule } from './../../pipes/pipes.module';
import { PedidoListaModule } from './../pedido-lista/pedido-lista.module';
import { ProdutoListaModule } from './../produto-lista/produto-lista.module';
import { PedidoRetirada } from './pedido-retirada';


 
@NgModule({
  declarations: [
    PedidoRetirada,
  ],
  imports: [
    IonicPageModule.forChild(PedidoRetirada),
    PipesModule,ProdutoListaModule,PedidoListaModule,
    TranslateModule
  ],
  exports: [
    PedidoRetirada
  ]
})
export class  PedidoRetiradaModule {}