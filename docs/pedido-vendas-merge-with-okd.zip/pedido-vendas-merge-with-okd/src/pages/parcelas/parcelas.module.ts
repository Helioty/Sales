import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { TranslateModule } from '@ngx-translate/core';
import { Parcelas } from './parcelas';
 
@NgModule({
  declarations: [
    Parcelas,
  ],
  imports: [
    IonicPageModule.forChild(Parcelas),
    TranslateModule
  ],
  exports: [
    Parcelas
  ]
})
export class  ParcelasModule {}