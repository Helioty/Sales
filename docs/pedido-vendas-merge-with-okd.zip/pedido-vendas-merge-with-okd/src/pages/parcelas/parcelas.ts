import { Component } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';


@IonicPage()
@Component({
  selector: 'parcelas-page',
  templateUrl: 'parcelas.html'
})
export class Parcelas {

  item: any;
  dados: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    // private menu: MenuController,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);

    this.item = navParams.data.item;

    this.getCondicaoPagamento('CC', this.commonServices.numPedido);
  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ionViewWillEnter() {

    this.goToFullScreen();

    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);
  }

  async getCondicaoPagamento(codCondicao, idPedido) {

    this.commonServices.showLoader();

    try {
      this.dados = await this.httpUtilProvider.get(ENV.WS_VENDAS+API_URL+
        'condicaoPagto/list/' + localStorage.getItem('empresa') + '/' + codCondicao + '?pedido=' + idPedido)

      // console.log(this.dados);

      this.commonServices.loading.dismiss();
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }

}
