import { Component, ViewChild } from '@angular/core';
// import { Http } from '@angular/http';
import { ENV } from '@app/env';
import { PedidoCab, PedidoItens, Retiradas } from 'class/class.pedido';
import { AlertController, IonicPage, NavController, NavParams, Slides } from 'ionic-angular';
import "rxjs/add/operator/map";
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "../../providers/http-util/http-util";
import { CommonServices } from '../../services/common-services';

/**
 * Generated class for the TintaManipuladaPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tinta-manipulada',
  templateUrl: 'tinta-manipulada.html',
})
export class TintaManipuladaPage {

  @ViewChild(Slides) slide: Slides;

  // by Helio
  public showInfo: boolean = false;

  // 
  public items: any = [];
  public colors: any = [];
  public itemsCorante: any = [];
  public bases: any;

  // 
  public pedidoItens: PedidoItens;
  public pedidoCab: PedidoCab;
  public retiradas: Retiradas;


  // fors: any = [{ a: 'cA', b: 'cA', hex: "#682649" },
  // { a: 'cB', b: 'cB', hex: "#2bc09d" },
  // { a: 'cC', b: 'cC', hex: "#923f61" },
  // { a: 'cs', b: 'cA', hex: "#d2ea86" },
  // { a: 'cB', b: 'cB', hex: "#86b695" },
  // { a: 'cC', b: 'cC', hex: "#88c9d2" },
  // { a: 'cv', b: 'cA', hex: "#e94b38" }];

  // Valor dos inputs de pesquisa
  public valorPesquisaBase: string;
  public valorPesquisaCore: string;

  // Valores derivados das pesquisas 
  public resultPesquisaBase: any = [];
  public resultPesquisaCore: any = [];

  // 
  public dados: any;
  public itEstq: any;
  public info: any;

  // 
  public codigofc: string;
  public codigobase: string;
  public codigoemb: string;
  public codProd: string;
  public qtdPedido: number = 0;


  // Base selected
  public baseObject: any[] = [];
  public relacaoBase: any;
  public corObject: any[] = [];
  public qty: number = 0;

  constructor(
    private alert: AlertController,
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpUtilProvider: HttpUtilProvider,
    public commonServices: CommonServices,
    // public http: Http,
  ) {
    
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad TintaManipuladaPage');
    this.slide.lockSwipes(true);
  }

  verificaLinha(linha: string): boolean {
    let L: string = linha.substr(0, 3);
    if (L == "SAB") {
      return true
    } else {
      return false
    }
  }


  async pesquisaBase(valor: string) {
    console.log(this.resultPesquisaBase);
    this.commonServices.showLoader();
    // console.log(valor);
    // let p: string = valor.replace(/ /g, "%");
    // console.log(p);
    // let p2: string = "%" + p + "%";
    // console.log(p2);
    let it: any = await this.httpUtilProvider.get(
      ENV.WS_PRODUTO + API_URL +
      "list/" +
      localStorage.getItem("empresa") +
      "?filter=descricao:" +
      valor
    );
    console.log("tinta aqui2");
    console.log(it);
    this.resultPesquisaBase = it.content;
    console.log(this.resultPesquisaBase);
    this.commonServices.loading.dismiss();
  }

  // guarda a base selecionada
  async saveBase(item: {}) {
    this.commonServices.showLoader();
    if (this.baseObject.length > 0) {
      let alert = this.alert.create({
        title: 'Atenção!',
        message: 'Deseja remover a base anterior?',
        buttons: ['Cancelar', {
          text: 'Sim',
          handler: () => {
            this.baseObject.pop();
            this.baseObject.push(item);
            this.qty = 1;
            console.log(this.baseObject);
            this.getRelacao(item);
            this.goSlide(1);
            this.commonServices.loading.dismiss();
          }
        }]
      });
      alert.present();
    }
    else {
      this.baseObject.pop();
      this.baseObject.push(item);
      this.qty = 1;
      console.log(this.baseObject);
      await this.getRelacao(item);
      this.goSlide(1);
      this.commonServices.loading.dismiss();
    }

  }

  // remove a base selecionada
  removeBase() {
    let alert = this.alert.create({
      title: 'Atenção!',
      message: 'Deseja remover a base anterior?',
      buttons: ['Cancelar', {
        text: 'Sim',
        handler: () => {
          this.baseObject.pop();
          this.corObject.pop();
          this.qty = 0;
          this.showInfo = false;
          this.goSlide(0);
        }
      }]
    });
    alert.present();

  }

  async getRelacao(item: any) {
    let result: any = await this.httpUtilProvider.get("http://10.131.9.81:8080/api/tintas/getRelacao/" + item.cod_produto);
    this.relacaoBase = result[0];
    console.log(this.relacaoBase);
  }

  async pesquisaCor(valor: string) {
    console.log(this.resultPesquisaCore);
    this.commonServices.showLoader();
    let link: string = '';
    if (this.relacaoBase.length) {
      link = "http://10.131.9.81:8080/api/tintas/getCorPorNome/" +
      valor.toUpperCase() + "&" +
      this.relacaoBase[0].COD_BASECORANTE + "&" +
      this.relacaoBase[0].COD_FORN + "&" +
      this.relacaoBase[0].COD_EMBALAGEM + "&" +
      this.baseObject[0].cod_produto
    } else {
      link = "http://10.131.9.81:8080/api/tintas/getCorPorNome/" +
      valor.toUpperCase() + "&" +
      this.relacaoBase.COD_BASECORANTE + "&" +
      this.relacaoBase.COD_FORN + "&" +
      this.relacaoBase.COD_EMBALAGEM + "&" +
      this.baseObject[0].cod_produto
    }
    let it: any = await this.httpUtilProvider.get(link);
    console.log("COR");
    console.log(it);
    this.resultPesquisaCore = it;
    this.commonServices.loading.dismiss();
  }

  // guarda a base selecionada
  async saveCor(item: {}) {
    this.commonServices.showLoader();
    if (this.corObject.length > 0) {
      let alert = this.alert.create({
        title: 'Atenção!',
        message: 'Deseja remover a cor anterior?',
        buttons: ['Cancelar', {
          text: 'Sim',
          handler: () => {
            this.corObject.pop();
            this.corObject.push(item);
            console.log(this.corObject);
            this.commonServices.loading.dismiss();
          }
        }]
      });
      alert.present();
    }
    else {
      this.corObject.pop();
      this.corObject.push(item);
      console.log(this.corObject);
      this.commonServices.loading.dismiss();
    }

  }

  goSlide(slide: number) {
    this.slide.lockSwipes(false);
    this.slide.slideTo(slide);
    this.slide.lockSwipes(true);
  }

  // by Helio adiciona um na quantidade
  addQty() {
    this.qty++;
  }
  // by Helio remove um na quantidade
  rmQty() {
    if (this.qty > 1) {
      this.qty--;
    }
  }

  // by Helio
  // sobre as informações do pedido no footer
  closeInfo() {
    if (this.showInfo == true) {
      this.showInfos()
    }
  }
  showInfos() {
    this.showInfo = !this.showInfo;
  }



  // getCorPorNome() {
  //   let link: string = "http://10.131.9.81:8080/api/tintas/getCorPorNome/AZUL&24&2&6&";
  //   new Promise((resolve, reject) => {
  //     this.http.get(link).map(result => result.json())
  //       .subscribe(
  //         (res: any) => {
  //           console.log(res);
  //           for (let i = 0; i < res.length; i++) {
  //             this.fors.push(res[i])
  //           }
  //           console.log(this.fors)
  //           resolve(res)
  //         });
  //   })
  // }

  // by Ryuge 2019
  // Alterado por Hélio 02/2020
  decimalColorToHTMLcolor(number: any): string {
    if (number != null) {
      //converts to a integer
      let intnumber = number - 0;

      // isolate the colors - really not necessary
      let red: any, green: any, blue: any;

      // needed since toString does not zero fill on left
      let template = "#000000";

      // in the MS Windows world RGB colors
      // are 0xBBGGRR because of the way Intel chips store bytes
      red = (intnumber & 0x0000ff) << 16;
      green = intnumber & 0x00ff00;
      blue = (intnumber & 0xff0000) >>> 16;

      // mask out each color and reverse the order
      intnumber = red | green | blue;

      // toString converts a number to a hexstring
      let HTMLcolor = intnumber.toString(16);

      //template adds # for standard HTML #RRGGBB
      HTMLcolor = template.substring(0, 7 - HTMLcolor.length) + HTMLcolor;

      return HTMLcolor;
    }
  }

  // by Hélio 02/2020
  RGBToHex(r: any, g: any, b: any): string {
    r = r.toString(16);
    g = g.toString(16);
    b = b.toString(16);

    if (r.length == 1)
      r = "0" + r;
    if (g.length == 1)
      g = "0" + g;
    if (b.length == 1)
      b = "0" + b;

    return "#" + r + g + b;
  }
  // by Hélio 02/2020
  hexToRGB(h: any): string {
    let r: any = 0, g: any = 0, b: any = 0;

    // 3 digits
    if (h.length == 4) {
      r = "0x" + h[1] + h[1];
      g = "0x" + h[2] + h[2];
      b = "0x" + h[3] + h[3];

      // 6 digits
    } else if (h.length == 7) {
      r = "0x" + h[1] + h[2];
      g = "0x" + h[3] + h[4];
      b = "0x" + h[5] + h[6];
    }

    return "rgb(" + +r + "," + +g + "," + +b + ")";
  }

}
