import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TintaManipuladaPage } from './tinta-manipulada';

@NgModule({
  declarations: [
    TintaManipuladaPage,
  ],
  imports: [
    IonicPageModule.forChild(TintaManipuladaPage),
  ],
})
export class TintaManipuladaPageModule {}
