import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
// by Ryuge 14/02/2019
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { AppVersion } from '@ionic-native/app-version';
import { Network } from '@ionic-native/network';
import { Content, IonicPage, Keyboard, MenuController, NavController, Platform } from 'ionic-angular';
import { API_URL, AppConfig, getHTTP, setURL } from '../../config/app.config';
import { AuthProvider } from '../../providers/auth/auth';
import { CommonServices } from '../../services/common-services';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage implements OnInit {

  ngOnInit() {

    // by Ryuge 29/11/2019
    if (localStorage.getItem("host")) {
      this.commonServices._API_URL = localStorage.getItem('host');
    }
    if (API_URL == '' || API_URL == undefined) {
      if (this.commonServices._API_URL != undefined || this.commonServices._API_URL != '') {
        setURL(this.commonServices._API_URL);
        getHTTP();
      } else {
        getHTTP();
      }
    } else {
      if (!localStorage.getItem("host")) {
        this.commonServices._API_URL = API_URL;
      }
    }
    console.log('environment.message');
    console.log('_APIURL: ' + this.commonServices._API_URL);
    console.log('APIURL: ' + API_URL);
  }

  public versao: string = '';
  public isLoggedIn: boolean;
  public isFocused: boolean = false;
  public foto;
  public usuarioLogado;
  public noPhoto: boolean = false;
  public disableButton: boolean = false;

  private loginCount: number = 0;

  // public token;

  // loading: any;

  // loginData = { login: 'R6543MRM', senha: 'japa1966' };
  loginData = { login: '', senha: '' };
  data: any;

  public ionScroll;
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;
  @ViewChild(Content) content: Content;  // by ryuge 19/10/2018	

  // by ryuge 05/09/2019
  @ViewChild("login") login;  // campo login
  @ViewChild("senha") senha;  // campo senha

  constructor(
    public appConfig: AppConfig,
    public navCtrl: NavController,
    public authService: AuthProvider,
    public commonServices: CommonServices,
    private menu: MenuController,
    public Keyb: Keyboard,
    public platform: Platform,
    private appVersion: AppVersion,
    public network: Network,
    // private insomnia: Insomnia,
    private androidFullScreen: AndroidFullScreen,
    // @Inject(EnvVariables) public envVariables
  ) {

    // console.log('process.env.IONIC_ENV');
    // console.log(envVariables.ionicEnvName);


    if (ENV.mode == 'Production') {
      this.loginData.login = '';
      this.loginData.senha = '';
    } else {
      this.loginData.login = 'R6543MRM';
      this.loginData.senha = 'japa1966';

      // salvador
      // this.loginData.login = 'S7396AMJ';
      // this.loginData.senha = 'CAIO90';

      // João Pessoa
      // this.loginData.login = 'F16052DFL';
      // this.loginData.senha = 'DIEGO1107';
    }

    if (this.platform.is('ios') || this.platform.is('android')) {
      // by Helio 20/11/2019
      this.commonServices.getVersionNumber()
      this.versao = '';
    }

    this.stopWays(); // desativa o timer da lista de pedido

    if (localStorage.getItem("token")) {
      this.isLoggedIn = JSON.parse(localStorage.getItem("isLoggedIn"));
      this.foto = localStorage.getItem("foto");
      this.usuarioLogado = localStorage.getItem("nome");
      this.loginData.login = localStorage.getItem("login");

      if (localStorage.getItem("foto") === 'null') {
        this.noPhoto = true;
      }
    }

    // By Ryuge 30/11/2019
    // if (this.platform.is('ios') || this.platform.is('android')) {
    //   getIP();
    //   console.log("TCPIP: " + TCPIP);
    // }


  }

  // ionViewDidLoad() {
  //   console.log('ionViewDidLoad BatteryStatus');
  //   // watch change in battery status
  //   this.subscription = this.batteryStatus.onChange().subscribe(
  //   (status: BatteryStatusResponse) => {
  //    console.log(status.level, status.isPlugged);
  //    this.levelBattery = status.level;
  //   });
  // }

  // by Ryuge 04/09/2019
  scrollTo(element: string) {
    let yOffset = document.getElementById(element).offsetTop;
    this.content.scrollTo(0, yOffset, 200);
    this.content.resize();
  }
  // by ryuge 13/11/2018	
  scrollToNext(y: number) {
    this.content.scrollTo(0, y, 200);
  }

  // by Ryuge 13/09/2019
  scrollToBottom() {
    setTimeout(() => {
      this.content.scrollToBottom();
    });
  }

  // by ryuge 05/092019
  setFocusPass() {
    setTimeout(() => {
      this.senha.setFocus();
    }, 200);
  }

  // by Ryuge 05/09/2019
  setFocusLogin() {
    setTimeout(() => {
      this.login.setFocus();
    }, 200);
  }

  setHeightUnic(div) {
    div[0].style.height = "auto";
  }

  setHeight(div, valor) {
    for (var i = 0; i < div.length; i++) {
      div[i].style.height = valor + "vh";
    }
  }

  resizeElementHeight(tipo: any) {
    if (tipo == 'LOCK') {
      this.isFocused = true;
      // this.scrollToNext(200);
    } else {
      this.isFocused = false;
      // this.scrollToBottom();
    }

    // // by Ryuge 16/09/2019
    // if (tipo == 'CLEAR') {
    //   if( this.loginData.login != '' &&  this.loginData.senha != ''){
    //     this.doLogin();
    //   }
    // }

    // var element = document.getElementsByClassName("loginFormSection");
    // // Loop over matching divs
    // for (var i = 0; i < element.length; i++) {
    //   var ele = element[i];
    // }
    // if (tipo == 'LOCK') {
    //   this.setHeight(element, 100);
    // } else {
    //   this.setHeightUnic(element);
    // }

  }

  // ngAfterViewChecked() {
  //   this.scrollToBottom();
  // }

  // scrollToBottom(): void {
  //   // method used to enable scrolling
  //   // this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  //   this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
  // }

  ionViewDidLeave() {
    this.menu.swipeEnable(true);
    // by Ryuge 23/09/2019
    this.commonServices.dismiss();
  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
  }

  showVersion() {
    if (this.platform.is('ios') || this.platform.is('android')) {
      this.getVersionCode();
    }
  }


  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }


  ionViewWillEnter() {
    this.goToFullScreen();
  }


  // ionViewWillEnter(){
  //   this.insomnia.keepAwake()
  //   .then(
  //     () => console.log('success'),
  //     () => console.log('error')
  //   );

  //   this.insomnia.allowSleepAgain()
  //     .then(
  //       () => console.log('success'),
  //       () => console.log('error')
  //     );

  // }

  async getVersionCode() {
    let versionCode = await this.appVersion.getVersionCode();
    let versionNumber: string = await this.appVersion.getVersionNumber();

    let value = versionCode.toString();
    value = value.replace(/^(\d{1})(\d)/, '$1.$2');

    let value2 = versionNumber.toString();

    value = 'Versão: ' + value2 + '<br/> Version Code: ' + value;

    this.commonServices.showAlert2('Pedido de Vendas', value);

    console.log(versionCode);
  }


  doLogin() {

    try {
      if (this.platform.is('ios') || this.platform.is('android')) {

        // var networkState = this.network.type;
        // alert("networktype"+JSON.stringify(networkState));

        this.commonServices.showLoader();
        this.authService.login(this.loginData.login.toUpperCase(), this.loginData.senha).then((result) => {

          this.data = result;
          this.commonServices.loading.dismiss();

          console.log('doLogin');
          console.log(result);

          if (this.data.status == 'OK') {
            //this.commonServices.showToast(this.data.message);
            this.commonServices.showAlert2(this.data.json().title, this.data.json().detail);
          } else {

            console.log('doLogin A');
            console.log(this.data);

            localStorage.setItem('token', this.data.authorization);
            localStorage.setItem('login', this.loginData.login);
            localStorage.setItem('foto', this.data.foto);
            localStorage.setItem('empresa', this.data.empresa.id);
            localStorage.setItem('nome', this.data.nomeDisplay);
            localStorage.setItem('host', API_URL);
            // comentado por Helio em 02/07/2020 para testes do TMS na produção
            // localStorage.setItem('tms', this.data.empresa.usaFreteTMS);
            localStorage.setItem('tms', 'true');
            localStorage.setItem('isLoggedIn', 'true');

            // this.commonServices.fotoLogin = localStorage.getItem("foto");

            this.authService.menuAcesso = 'Logout';

            if (localStorage.getItem("foto") === 'null') {
              this.noPhoto = true;
            }

            // this.navCtrl.setRoot("PedidoLista");
            let status: boolean = true;
            this.navCtrl.setRoot("PedidoLista", { refresh: status });
            this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
          }

        }
          // , (err) => {
          //   this.isLoggedIn = false;
          //   this.commonServices.loading.dismiss();
          //   this.loginData.senha = '';
          //   //this.commonServices.showToast(err);

          //   // by Ryuge 05/09/2019
          //   // if (err.json().detail != null) {
          //   //   this.commonServices.showAlert2(err.json().title, err.json().detail);
          //   // } else {
          //   //   this.commonServices.showAlert2("Ops!", err);
          //   // }

          //   if (err.status == 0) {
          //     this.commonServices.showAlert2(err.json().title, err.json().detail);
          //     // this.commonServices.showAlert2("Ops!", "Ocorreu algum erro na conexão!");
          //     // this.loginCount += 1;
          //     // if(this.loginCount <= 3){
          //     //   this.disableButton = true; // desabilita o botão login
          //     //   this.waitLoginAccess();
          //     // }else{
          //     //   this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
          //     // }

          //   } else {
          //     this.commonServices.showAlert2("Ops!", err);
          //   }
          // }
        );

      } else {

        this.commonServices.showLoader();
        this.authService.login(this.loginData.login.toUpperCase(), this.loginData.senha).then((result) => {

          this.data = result;
          this.commonServices.loading.dismiss();

          if (this.data.status == 'OK') {
            this.commonServices.showAlert2(this.data.json().title, this.data.json().detail);
          } else {

            console.log('doLogin B');
            console.log(this.data);

            localStorage.setItem('token', this.data.authorization);
            localStorage.setItem('login', this.loginData.login);
            localStorage.setItem('foto', this.data.foto);
            localStorage.setItem('empresa', this.data.empresa.id);
            localStorage.setItem('nome', this.data.nomeDisplay);
            localStorage.setItem('host', API_URL);
            // comentado por Helio em 02/07/2020 para testes do TMS na produção
            // localStorage.setItem('tms', this.data.empresa.usaFreteTMS);
            localStorage.setItem('tms', 'true');
            console.log(localStorage.getItem('tms'));
            localStorage.setItem('isLoggedIn', 'true');

            // this.commonServices.fotoLogin = localStorage.getItem("foto");

            this.authService.menuAcesso = 'Logout';

            if (localStorage.getItem("foto") === 'null') {
              this.noPhoto = true;
            }

            // this.navCtrl.setRoot("PedidoLista");
            let status: boolean = true;
            this.navCtrl.setRoot("PedidoLista", { refresh: status });
            this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
          }

        }
          // , (err) => {
          //   this.isLoggedIn = false;
          //   this.commonServices.loading.dismiss();
          //   this.loginData.senha = '';
          //   // if (err.json().detail != null) {
          //   //   this.commonServices.showAlert2(err.json().title, err.json().detail);
          //   // } else {
          //   //   this.commonServices.showAlert2("Ops!", err);
          //   // }
          //   if (err.status == 0) {
          //     // this.commonServices.showAlert2("Ops!", "Ocorreu algum erro na conexão!");
          //     // by Ryuge 18/11/2019
          //     this.commonServices.showAlert2(err.json().title, err.json().detail);

          //   } else {
          //     this.commonServices.showAlert2("Atenção!", err);
          //   }
          // }
        );

      }

    } catch (error) {
      // by Ryuge 27/11/2019
      if (error.status == 401) {
        this.logout();
      } else {
        this.commonServices.loading.dismiss();
        this.commonServices.showToast(error.json().detail);
      }

    }


  }


  stopWays() {
    setTimeout(() => {
      clearInterval(this.commonServices.task);
    }, 500);
  }

  // by Ryuge 18/11/2019
  waitLoginAccess() {
    setTimeout(() => {
      this.doLogin();
    }, 3000);
  }

  logout() {
    this.isLoggedIn = false;
    this.authService.menuAcesso = 'Login';

    if (localStorage.getItem("token")) {
      localStorage.clear();
      // grava no storage API_URL
      localStorage.setItem('host', this.commonServices._API_URL);
      console.log(localStorage.getItem("host"));
      setURL(this.commonServices._API_URL);
      // by Ryuge 05/09/2019
      this.setFocusLogin();
    }
    this.navCtrl.setRoot("LoginPage");

  }


}
