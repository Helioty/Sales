import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NovaEntrega } from './nova-entrega';

import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { IonicSwipeAllModule } from 'ionic-swipe-all';
import { LongPressModule } from 'ionic-long-press';

@NgModule({
  declarations: [
    NovaEntrega,
  ],
  imports: [
    IonicPageModule.forChild(NovaEntrega),
	  PipesModule,DirectivesModule,
	  IonicSwipeAllModule,LongPressModule,
  ],
})
export class NovaEntregaPageModule {}
