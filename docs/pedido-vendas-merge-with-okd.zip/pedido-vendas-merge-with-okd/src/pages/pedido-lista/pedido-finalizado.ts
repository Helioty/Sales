import { Component, ViewChild } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import {
  AlertController,
  App, InfiniteScroll,
  IonicPage,
  Item, ItemSliding,
  MenuController,
  ModalController, NavController,
  NavParams
} from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';
import { PedidoLista } from './pedido-lista';

// import { Cliente } from './../cliente/cliente';
@IonicPage()
@Component({
  selector: 'pedido-finalizado',
  templateUrl: 'pedido-finalizado.html'
})
export class PedidoFinalizado {

  public totalPages: number = 0;
  public currentPage: number = 1; 
  private itemSearch;
  public existOne: boolean = false;
  public exibeImagemFinalizado: boolean = false;

  // private refresh: boolean = false;
  // private mode;

  isEnabled: boolean = true; // controle re refresh de tela - by Ryuge 28/11/2019

  itemsFinalizados;
  query: string = "";

  @ViewChild(InfiniteScroll) infiniteScroll: InfiniteScroll;
  itemAberto: any;
  itemSlidingAberto: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public pedidolista: PedidoLista,
    private menu: MenuController,
    public app: App,
    private alertCtrl: AlertController,
    private modalCtrl: ModalController,
    private androidFullScreen: AndroidFullScreen
  ) {
    this.navCtrl = navCtrl;
    this.exibeImagemFinalizado = false;

  }


  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ionViewWillLeave() {
    this.close(this.itemSlidingAberto, this.itemAberto);
  }

  ionViewWillEnter() {

    this.goToFullScreen();

    this.commonServices.sistuacaoPedido = 'F';
    this.getPedidoFaturado();
    // this.getPedidoAberto();
  }


  getAllPedido(e: string, page: number) {

    return this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
      'PedidoVenda/list/' + localStorage.getItem('empresa') + '/faturados' + '?page=' + page);

  }

  getAllPedidoFaturado(page: number) {

    // by Ryuge 28/11/2019
    // by Ryuge 28/11/2019
    if(this.isEnabled){

      this.isEnabled = false; // by Ryuge 28/11/2019
      this.getAllPedido(this.itemSearch, page)
      .then((result: any) => {
        for (let i = 0; i < result.content.length; i++) {
          let it = result.content[i];
          this.itemsFinalizados.push(it);
        }

        if (this.infiniteScroll) {
          this.infiniteScroll.complete();
          if (this.itemsFinalizados.length == result.total) {
            this.infiniteScroll.enable(false);
          }
        }

        this.isEnabled = true; // by Ryuge 28/11/2019
      })
      .catch((error: any) => {
        this.isEnabled = true; // by Ryuge 28/11/2019
        this.commonServices.showToast(error.json().detail);
      });
    }


  }

  getItemsPedidoFaturado(infiniteScroll) {

    this.currentPage += 1;
    setTimeout(() => {
      if (this.currentPage <= this.totalPages) {
        this.getAllPedidoFaturado(this.currentPage);
      }
      infiniteScroll.complete();

      if (this.currentPage > this.totalPages) {
        infiniteScroll.enable(false);
      }

    }, 5000);
  }


  getPedidoAberto() {

    try {
      this.pedidolista.listaPedidoAberto().then(result => {
        let itemsAbertos = result;
        let existeItem: boolean = itemsAbertos.totalElements > 0;
        this.pedidolista.contaPedidoEmAberto(existeItem, itemsAbertos.totalElements);
      });

    }
    catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }

  getPedidoFaturado() {
    try {
      this.pedidolista.listaPedidoFaturado().then(result => {
        this.itemsFinalizados = result;

        this.totalPages = this.itemsFinalizados.totalPages;
        this.commonServices.totalPedidoFinalizado = this.itemsFinalizados.totalElements;
        let existeItem: boolean = this.itemsFinalizados.totalElements > 0;
        this.pedidolista.contaPedidoFinalizado(existeItem, this.itemsFinalizados.totalElements);
        this.exibeImagemFinalizado = existeItem;

        this.itemsFinalizados = this.itemsFinalizados.content;

      });

    }
    catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }


  // async getPedidoFaturado() {

  //   this.commonServices.showLoader();

  //   try {
  //     this.commonServices.itemPedidoFinalizado = await this.httpUtilProvider.get(environment.WS_VENDAS +
  //       'PedidoVenda/list/' + localStorage.getItem('empresa') + '/faturados')

  //     this.itemsFinalizados = this.commonServices.itemPedidoFinalizado;

  //     this.totalPages = this.itemsFinalizados.totalPages;
  //     this.commonServices.totalPedidoFinalizado = this.itemsFinalizados.totalElements;
  //     let existeItem: boolean = this.itemsFinalizados.totalElements>0;
  //     this.pedidolista.contaPedidoFinalizado(existeItem,this.itemsFinalizados.totalElements);
  //     this.exibeImagemFinalizado = existeItem;

  //     this.itemsFinalizados = this.itemsFinalizados.content;

  //     this.commonServices.loading.dismiss();

  //     // console.log('Finalizado: '+this.exibeImagem );

  //   } catch (error) {
  //     this.commonServices.loading.dismiss();
  //     this.commonServices.showToast(error);
  //   }

  // }



  async RefresPage(refresher) {
    // by Ryuge 28/11/2019
    try {
      await this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
        'PedidoVenda/list/' + localStorage.getItem('empresa') + '/faturados').then(result => {

          this.commonServices.itemPedidoFinalizado = result;
          this.itemsFinalizados = this.commonServices.itemPedidoFinalizado;
          this.totalPages = this.itemsFinalizados.totalPages;
          this.commonServices.totalPedidoFinalizado = this.itemsFinalizados.totalElements;
          let existeItem: boolean = this.itemsFinalizados.totalElements > 0;
          this.pedidolista.contaPedidoFinalizado(existeItem, this.itemsFinalizados.totalElements);
          this.exibeImagemFinalizado = existeItem;

          this.itemsFinalizados = this.itemsFinalizados.content;

          // this.pedidolista.refresh();
          this.pedidolista.getTotalPedidosFaturados();

          refresher.complete();
        });

    } catch (err) {
      // this.commonServices.showToast(error.json().detail);

      if (err.status == 400) {
        this.commonServices.showToast(err.json().detail);
      } else {

        if (err.status == 503) {
          this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
        } else {
          if (err.json().detail != null) {
            this.commonServices.showAlert2(err.json().title, err.json().detail);
          } else {
            this.commonServices.showAlert2("Atenção!", err);
          }
        }
      }
    }

  }



  async SearchOrder(event: any) {

    this.commonServices.showLoader();

    try {
      this.itemsFinalizados = await this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
        'PedidoVenda/' + localStorage.getItem('empresa') + '/' + event.target.value)
      // console.log(this.items);

      // this.items = this.items.content
      this.commonServices.loading.dismiss();
      this.itemSearch = event.target.value;
      this.existOne = true;
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
    this.pedidolista.getTotalPedidosFaturados();
    // this.pedidolista.getTotalPedidos('faturados');
  }

  getOpcaoRetirada(tipo) {
    for (var i = 0; i < this.commonServices.opcaoRetirada.length; i++) {
      if (this.commonServices.opcaoRetirada[i] == tipo) {
        this.commonServices.codigoTipoRetirada = i;
        break;
      }
    }
  }

  stopWays() {
    if (this.itemSlidingAberto) {
      this.close(this.itemSlidingAberto, this.itemAberto);
    }
    setTimeout(() => {
      clearInterval(this.commonServices.task);
    }, 500);
  }
  open(itemSlide: ItemSliding, item: Item) {
    // reproduce the slide on the click
    this.stopWays();
    itemSlide.setElementClass("active-sliding", true);
    itemSlide.setElementClass("active-slide", true);
    itemSlide.setElementClass("active-options-right", true);
    item.setElementStyle("transform", "translate3d(-240px, 0px, 0px)")
    this.itemSlidingAberto = itemSlide,
      this.itemAberto = item;

  }

  close(item: ItemSliding, itemA: Item) {
    if (item != undefined) {
      item.close();
      itemA.setElementStyle("transform", "translate3d(0px, 0px, 0px)");
      setTimeout(() => {

        item.setElementClass("active-slide", false);
        item.setElementClass("active-slide", false);
        item.setElementClass("active-options-right", false);
      }, 500);
    }
    this.itemSlidingAberto = undefined;
    this.itemAberto = undefined;
  }

  showPrompt(pedido) {
    const prompt = this.alertCtrl.create({
      title: 'Login',
      message: "Entre com o Usuario e Senha",
      inputs: [
        {
          name: 'usuario',
          placeholder: 'Usuario'
        },
        {
          name: 'senha',
          placeholder: 'Senha',
          type: 'password'
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
        },
        {
          text: 'Confirmar',
          handler: data => {
            this.getDesconto(pedido);
          }
        }
      ],
      cssClass: 'prompts'
    });
    prompt.present();
  }

  getDesconto(pedido) {
    let produtosModal = this.modalCtrl.create('PedidoListaModalDescontoPage', { pedido: pedido });
    produtosModal.onWillDismiss((data) => {
      this.getPedidoFaturado();
    });
    produtosModal.present({ animate: false });
  }


  //Alterado por Nicollas Bastos em 25/09/2018
  getProdutosPedido(pedido) {
    let produtosModal = this.modalCtrl.create('PedidoListaModalPage', { pedido: pedido });
    produtosModal.present({ animate: false });
  }

  edititem(item, slidingItem: ItemSliding) {

    slidingItem.close();

    this.commonServices.ItensPedidoAdd = item;
    this.commonServices.valorFrete = item.frete.valor;
    this.commonServices.sistuacaoPedido = "F"
    this.commonServices.enderecoSelected = false;
    this.commonServices.codigoCartaoPedido = item.cartaoPedido;
    this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '0' || this.commonServices.codigoCartaoPedido != '';

    this.commonServices.alteracaoItemPedido = true;
    this.commonServices.numPedido = item.numpedido;
    this.commonServices.digitoPedido = item.digito;
    this.commonServices.statusPedido = 'M';
    this.commonServices.docCliente = item.cgccpf_cliente;
    this.commonServices.nomeCliente = item.nome_cliente;

    this.commonServices.clientSelected = item.cgccpf_cliente != null && item.cgccpf_cliente.trim().length > 0;
    this.commonServices.pedidoAtualizado.entrega = item.tipoEntrega;

    this.commonServices.tipoRetirada = item.tipoEntrega;
    this.commonServices.tipoDocumento = item.tipodoc;

    this.getOpcaoRetirada(this.commonServices.tipoRetirada);

    this.pedidolista.reabrirPedido(this.commonServices.numPedido);

    // by Ryuge 29/11/2018
    let nav = this.app.getRootNav();
    console.log(item);
    nav.push("PedidoFinalizacao", { pedido: item })

    // let nav = this.app.getRootNav();
    // nav.push("PedidoSacola", {
    //   item: item, mode: 2
    // });
  }

  removeItem(item) {
    let prompt = this.alertCtrl.create({
      title: 'Apagar Pedido',
      // message: "Tem certeza? Apagando um pedido, os dados inseridos não poderão ser recuperados. Para confirmar, por favor digite \"APAGAR\" na caixa abaixo e clique em \"Apagar Pedido\".",
      message: "Tem certeza? Apagando um pedido, os dados inseridos não poderão ser recuperados.",

      // inputs: [
      //   {
      //     id: "idinput",
      //     name: 'title',
      //     placeholder: 'Digite APAGAR'
      //   },
      // ],
      buttons: [
        {
          text: 'Voltar',
          handler: () => {
            console.log('Cancelado');
          }
        },
        {
          text: 'Apagar Pedido',
          handler:  () => {
              this.RemoveOrder(item.numpedido);
              this.removeItemList(item);
              this.getPedidoFaturado();
            // if ('APAGAR' == data.title.toUpperCase()) {
            //   this.RemoveOrder(item.numpedido);
            //   this.removeItemList(item);
            //   this.getPedidoFaturado();
            // } else {
            //   this.removeItem(item);
            //   this.commonServices.showToast('Texto incorreto ou não digitado!');
            // }
          }
        }
      ],
      cssClass: 'alertCustomCss',
    });
    prompt.present()
      .then(() => {
        document.getElementById('idinput').focus();
      })
      .catch()
  }

  RemoveOrder(PedidoId) {

    try {
      this.httpUtilProvider.delete(ENV.WS_VENDAS + API_URL +
        'PedidoVenda/' + localStorage.getItem('empresa') + "/" + PedidoId);
      this.pedidolista.refresh();
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  removeItemList(item) {
    for (let i = 0; i < this.itemsFinalizados.length; i++) {
      if (this.itemsFinalizados[i] == item) {
        this.itemsFinalizados.splice(i, 1);
      }
    }
    this.pedidolista.refresh();
  }


}
