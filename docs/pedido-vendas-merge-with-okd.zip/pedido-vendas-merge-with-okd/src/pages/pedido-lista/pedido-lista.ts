import { Component, ViewChild } from "@angular/core";
// import { Http } from "@angular/http";
import { ENV } from '@app/env';
import { Network } from "@ionic-native/network";
import {
  IonicPage,
  MenuController,
  NavController,
  NavParams,
  Platform,
  Tabs
} from "ionic-angular";
// import { Cliente } from './../cliente/cliente';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

@IonicPage({
  priority: "high",
  segment: "tab"
})
@Component({
  selector: "pedido-lista",
  templateUrl: "pedido-lista.html"
})
export class PedidoLista {
  result: any;
  // open_orders = "PedidoAberto";
  // finalized = "PedidoFinalizado";

  public totalEmAberto = 0;
  public totalFinalizado = 0;
  public exibeSearch: boolean = false;

  public status: boolean = false;
  public disableButton: boolean = false;
  // tabs:Tabs;

  tab1Root = "PedidoAberto";
  tab2Root = "PedidoFinalizado";

  public tabIndex: Number;
  subscription: any;
  levelBattery: any;

  @ViewChild("input") search: any;
  @ViewChild("myTabs") tabRef: Tabs;

  constructor(
    // public http: Http,
    public navCtrl: NavController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    private menu: MenuController,
    public navParams: NavParams,
    public network: Network,
    public platform: Platform,
    // private batteryStatus: BatteryStatus,

  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);

    this.status = this.navParams.get("refresh");
  }


  ionViewDidLeave() {
    this.menu.swipeEnable(false);
    this.disableButton = false;
  }

  ionViewWillEnter() {

    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    }, 1);

    this.tabRef.select(0);
  }

  ionViewDidEnter() {

    // console.log('ionViewDidLoad BatteryStatus');
    // // watch change in battery status
    // this.subscription = this.batteryStatus.onChange().subscribe(
    // (status: BatteryStatusResponse) => {
    //   console.log(status.level, status.isPlugged);
    //   // this.levelBattery = status.level;
    //   if(status.level < 20){
    //     this.commonServices.showToastAlert('Nível de bateria está baixo: '+ status.level +'%');         
    //   }
    // });

    if (this.platform.is("ios") || this.platform.is("android")) {
      // by Ryuge 03/09/2019
      // if (this.httpUtilProvider.checkNetwork()) {
      this.refresh();
      this.menu.swipeEnable(true);
      this.commonServices.exibeBotaoComprar = false;
      // }
    } else {
      this.refresh();
      this.menu.swipeEnable(true);
      this.commonServices.exibeBotaoComprar = false;
    }
    this.tabRef.select(0);
  }

  // ionViewWillEnter() {
  //   if (this.platform.is('ios') || this.platform.is('android')) {
  //     if (this.network.type == 'wifi') {
  //       this.refresh();
  //       this.commonServices.qtdBasketItens = 0;
  //     }
  //   } else {
  //     this.refresh();
  //     this.commonServices.qtdBasketItens = 0;
  //   }
  // }

  selectTab(index: number) {
    var t: Tabs = this.navCtrl.parent;
    t.select(index);
  }

  async refresh() {
    // this.getTotalPedidosAbertos();
    // this.getTotalPedidosFaturados();
    await Promise.all([
      this.getTotalPedidosAbertos(),
      this.getTotalPedidosFaturados()
    ]);
  }

  public async getTotalPedidosAbertos() {
    try {
      console.log("ABERTOS");

      this.result = await this.httpUtilProvider.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/list/" +
        localStorage.getItem("empresa") +
        "/abertos"
      );

      if (this.result.content.length > 0) {
        this.commonServices.totalPedidoEmAberto = this.result.totalElements;
        let existeElements: boolean = this.result.totalElements > 0;
        this.contaPedidoEmAberto(existeElements, this.result.totalElements);
      }
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  public async getTotalPedidosFaturados() {
    try {
      console.log("FATURADOS");

      this.result = await this.httpUtilProvider.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/list/" +
        localStorage.getItem("empresa") +
        "/faturados"
      );

      if (this.result.content.length > 0) {
        this.commonServices.totalPedidoFinalizado = this.result.totalElements;
        let existeElements: boolean = this.result.totalElements > 0;
        this.contaPedidoFinalizado(existeElements, this.result.totalElements);
      }
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  public contaPedidoEmAberto(exibe: boolean, qtd: number) {
    setTimeout(() => {
      this.totalEmAberto = qtd;
      this.commonServices.exibeImagemPedidoEmAberto = exibe;
    }, 150);
  }

  public contaPedidoFinalizado(exibe: boolean, qtd: number) {
    setTimeout(() => {
      this.totalFinalizado = qtd;
      this.commonServices.exibeImagemPedidoFinalizado = exibe;
    }, 150);
  }

  public async listaPedidoAberto() {
    try {
      if (this.platform.is("ios") || this.platform.is("android")) {
        // by Ryuge 03/09/2019
        // if (this.httpUtilProvider.checkNetwork()) {
        if (this.totalEmAberto > 10) {
          this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(
            ENV.WS_VENDAS + API_URL +
            "PedidoVenda/list/" +
            localStorage.getItem("empresa") +
            "/abertos?size=" +
            this.totalEmAberto
          );
        } else {
          this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(
            ENV.WS_VENDAS + API_URL +
            "PedidoVenda/list/" +
            localStorage.getItem("empresa") +
            "/abertos"
          );
        }

        // console.log('ABERTO');
        // console.log(this.commonServices.itemPedidoAberto);

        return this.commonServices.itemPedidoAberto;
        // }
      } else {
        if (this.totalEmAberto > 10) {
          this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(
            ENV.WS_VENDAS + API_URL +
            "PedidoVenda/list/" +
            localStorage.getItem("empresa") +
            "/abertos?size=" +
            this.totalEmAberto
          );
        } else {
          this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(
            ENV.WS_VENDAS + API_URL +
            "PedidoVenda/list/" +
            localStorage.getItem("empresa") +
            "/abertos"
          );
        }

        return this.commonServices.itemPedidoAberto;
      }
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  public async listaPedidoFaturado() {
    this.stopWays();

    try {
      if (this.totalFinalizado > 10) {
        this.commonServices.itemPedidoFinalizado = await this.httpUtilProvider.get(
          ENV.WS_VENDAS + API_URL +
          "PedidoVenda/list/" +
          localStorage.getItem("empresa") +
          "/faturados?size=" +
          this.totalFinalizado
        );
      } else {
        this.commonServices.itemPedidoFinalizado = await this.httpUtilProvider.get(
          ENV.WS_VENDAS + API_URL +
          "PedidoVenda/list/" +
          localStorage.getItem("empresa") +
          "/faturados"
        );
      }

      // console.log('FECHADO');
      // console.log(this.commonServices.itemPedidoFinalizado);

      return this.commonServices.itemPedidoFinalizado;
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  public async reabrirPedido(idPedido) {
    let result: any = await this.httpUtilProvider.post(
      ENV.WS_VENDAS + API_URL +
      "PedidoVenda/reopen/" +
      localStorage.getItem("empresa") +
      "/" +
      idPedido,
      {}
    );

    console.log("reabrirPedido");
    console.log(result);
  }

  //---Get the withdrawal screen on button click --
  addNovoPedido() {
    try {
      this.disableButton = true;
      if (this.platform.is("ios") || this.platform.is("android")) {
        // by Ryuge 03/09/2019
        // if (this.httpUtilProvider.checkNetwork()) {
        this.stopWays();
        this.commonServices.limpaDadosPedido();
        this.navCtrl.push("PedidoRetirada");
        // } else {
        //   this.disableButton = false;
        //   this.commonServices.showToast("Sem conexão na rede, tente novamente !");
        // }
      } else {
        this.stopWays();
        this.commonServices.limpaDadosPedido();
        this.navCtrl.push("PedidoRetirada");
      }

    } catch (error) {
      this.disableButton = false;
    }
  }

  stopWays() {
    setTimeout(() => {
      clearInterval(this.commonServices.task);
    }, 500);
  }

  searchShow() {
    if (this.exibeSearch) {
      this.exibeSearch = false;
    } else {
      this.exibeSearch = true;
    }
    this.focusButton();
  }

  focusButton() {
    setTimeout(() => {
      if (this.search) {
        this.search.setFocus();
      }
    }, 500);
  }
}
