import { Component, ViewChild } from "@angular/core";
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { Network } from "@ionic-native/network";
import {
  AlertController,
  App, Content,
  InfiniteScroll,
  IonicPage,
  Item, ItemSliding,
  MenuController,
  ModalController,
  NavController,
  NavParams,
  Platform
} from "ionic-angular";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";
import { PedidoLista } from "./pedido-lista";

// import { Cliente } from './../cliente/cliente';
@IonicPage()
@Component({
  selector: "pedido-aberto",
  templateUrl: "pedido-aberto.html"
})
export class PedidoAberto {
  public totalPages: number = 0;
  public currentPage: number = 1;
  private itemSearch;
  public existOne: boolean = false;
  public exibeImagemEmAberto: boolean = false;
  public exibeProdutosPedido: boolean;
  public exibeProdutos: boolean = true;
  public produtos: any;

  // private refresh: boolean = false;
  
  isEnabled: boolean = true; // controle re refresh de tela - by Ryuge 28/11/2019
  // private task;

  selectedItem: any;
  data: any;
  items;
  condicao: any; // by Ryuge 27/11/2018
  query: string = "";
  itemSlidingAberto: any;
  itemAberto: any;
  task: any;

  @ViewChild(Content) content: Content;
  @ViewChild(InfiniteScroll) infiniteScroll: InfiniteScroll;
  // @ViewChild("input") search: any;
  taskFlag: boolean;
  pedidoNumero: any;
  distance: number;


  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public modalCtrl: ModalController,
    public app: App,
    public pedidolista: PedidoLista,
    private alertCtrl: AlertController,
    private menu: MenuController,
    public network: Network,
    public platform: Platform,
    private androidFullScreen: AndroidFullScreen
  ) {
    this.navCtrl = navCtrl;
    this.exibeImagemEmAberto = false;
  }

  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  getAllPedido(e: string, page: number) {
    return this.httpUtilProvider.get(
      ENV.WS_VENDAS+API_URL+
      "PedidoVenda/list/" +
      localStorage.getItem("empresa") +
      "/abertos" +
      "?page=" +
      page
    );
  }

  getAllPedidoAberto(page: number) {
    // by Ryuge 28/11/2019
    if(this.isEnabled){

      this.isEnabled = false; // by Ryuge 28/11/2019

      this.getAllPedido(this.itemSearch, page)
      .then((result: any) => {
        for (let i = 0; i < result.content.length; i++) {
          let it = result.content[i];
          this.items.push(it);
        }

        if (this.infiniteScroll) {
          this.infiniteScroll.complete();
          if (this.items.length == result.total) {
            this.infiniteScroll.enable(false);
            this.infiniteScroll.complete();
          }
        }

        this.isEnabled = true; // by Ryuge 28/11/2019
      })
      .catch((error: any) => {
        this.isEnabled = true; // by Ryuge 28/11/2019
        this.commonServices.showToast(error.json().detail);
      });      

    }
    

  }

  getItemsPedidoAberto(infiniteScroll) {
    this.currentPage += 1;
    if (this.currentPage <= this.totalPages) {
      this.getAllPedidoAberto(this.currentPage);
    }
    infiniteScroll.complete();

    if (this.currentPage > this.totalPages) {
      infiniteScroll.enable(false);
    }
  }

  async RefresPage(refresher) {
    // by Ryuge 28/11/2019
    try {
      // this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(
        await this.httpUtilProvider.get(
        ENV.WS_VENDAS+API_URL+
        "PedidoVenda/list/" +
        localStorage.getItem("empresa") +
        "/abertos"
      ).then( result => {
      this.commonServices.itemPedidoAberto = result;
      this.items = this.commonServices.itemPedidoAberto;
      this.totalPages = this.items.totalPages;
      this.commonServices.totalPedidoEmAberto = this.items.totalElements;
      let existeItem: boolean = this.items.totalElements > 0;
      this.pedidolista.contaPedidoEmAberto(
        existeItem,
        this.items.totalElements
      );
      this.exibeImagemEmAberto = existeItem;
      this.items = this.items.content;

      // this.pedidolista.refresh();
      this.pedidolista.getTotalPedidosAbertos();

      refresher.complete();
      });

    } catch (err) {
      // this.commonServices.showToast(error.json().detail);
      
      if (err.status == 400) {
        this.commonServices.showToast(err.json().detail);
      } else {

        if (err.status == 503) {
          this.commonServices.showToast('Sem serviço, entrar em contato com suporte.');
        }else{
          if (err.json().detail != null) {
            this.commonServices.showAlert2(err.json().title, err.json().detail);
          } else {
            this.commonServices.showAlert2("Atenção!", err);
          }
        }
      }

    }
  }

  getPedidoAberto() {
    try {
      this.pedidolista.listaPedidoAberto().then(result => {
        this.items = result;

        this.totalPages = this.items.totalPages;
        this.commonServices.totalPedidoEmAberto = this.items.totalElements;
        let existeItem: boolean = this.items.totalElements > 0;
        this.pedidolista.contaPedidoEmAberto(
          existeItem,
          this.items.totalElements
        );
        this.exibeImagemEmAberto = existeItem;

        this.items = this.items.content;
      });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  getPedidoFaturado() {
    try {
      this.pedidolista.listaPedidoFaturado().then(result => {
        let itemsFinalizados = result;
        let existeItem: boolean = itemsFinalizados.totalElements > 0;
        this.pedidolista.contaPedidoFinalizado(
          existeItem,
          itemsFinalizados.totalElements
        );
      });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  // async getPedidoAberto() {

  //   try {
  //     this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(environment.WS_VENDAS +
  //       'PedidoVenda/list/' + localStorage.getItem('empresa') + '/abertos');

  //     // console.log('ABERTO') ;
  //     // console.log(this.commonServices.itemPedidoAberto) ;

  //     this.items = this.commonServices.itemPedidoAberto;

  //     this.totalPages = this.items.totalPages;
  //     this.commonServices.totalPedidoEmAberto = this.items.totalElements;
  //     let existeItem: boolean = this.items.totalElements>0;
  //     this.pedidolista.contaPedidoEmAberto(existeItem,this.items.totalElements);
  //     this.exibeImagemEmAberto = existeItem;

  //     this.items = this.items.content;

  //     // this.commonServices.loading.dismiss();

  //   } catch (error) {
  //     // this.commonServices.loading.dismiss();
  //     this.commonServices.showToast(error);
  //   }
  // }

  stopWays() {
    if (this.itemSlidingAberto) {
      this.close(this.itemSlidingAberto, this.itemAberto, true);
    }
    // clearInterval(this.task);

    setTimeout(() => {
      clearInterval(this.task);
    }, 500);
    this.taskFlag = false;
    this.task = 0;
  }

  open(itemSlide: ItemSliding, item: Item) {
    // reproduce the slide on the click
    this.stopWays();
    itemSlide.setElementClass("active-sliding", true);
    itemSlide.setElementClass("active-slide", true);
    itemSlide.setElementClass("active-options-right", true);
    item.setElementStyle("transform", "translate3d(-240px, 0px, 0px)");
    (this.itemSlidingAberto = itemSlide), (this.itemAberto = item);
  }

  close(item: ItemSliding, itemA: Item, interno?: boolean) {
    if (item != undefined) {
      item.close();
      itemA.setElementStyle("transform", "translate3d(0px, 0px, 0px)");
      setTimeout(() => {
        item.setElementClass("active-slide", false);
        item.setElementClass("active-slide", false);
        item.setElementClass("active-options-right", false);
      }, 500);
    }
    this.itemSlidingAberto = undefined;
    this.itemAberto = undefined;
  }

  closeSliding(slidingItem: ItemSliding) {
    slidingItem.close();
  }

  refreshWays() {
    if (this.platform.is("ios") || this.platform.is("android")) {
      // by Ryuge 03/09/2019
      // if (this.httpUtilProvider.checkNetwork()) {
        if (this.commonServices.refreshTelaPedido) {
          if (!this.taskFlag) {
            this.taskFlag = true;
            this.task = setInterval(() => {
              clearInterval(this.task);
              this.getPedidoAberto();
            }, 6000);
          }
        }
      // }
    } else {
      if (this.commonServices.refreshTelaPedido) {
        if (!this.taskFlag) {
          this.taskFlag = true;
          this.task = setInterval(() => {
            clearInterval(this.task);
            this.getPedidoAberto();
          }, 6000);
        }
      }
    }
  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
    this.pedidolista.getTotalPedidosAbertos();
    // this.pedidolista.getTotalPedidos('abertos');
    // this.exibeImagemEmAberto = false;
    this.getPedidoAberto();
    // ativa timer

    // this.refresh = true;
    // this.RefresPage(this.refresh);
  }
  ionViewWillLeave() {
    this.stopWays();
  }

  ionViewWillEnter() {
    this.commonServices.sistuacaoPedido = "A";
    // this.getPedidoAberto();
    this.commonServices.refreshTelaPedido = true;
    
    // by Ryuge 04/09/2019 
    // comentado para verficar problemas no oracle 11
    // this.refreshWays();

    this.goToFullScreen();
  }

  // async ionViewWillEnter() {
  //   // this.getPedidoAberto();

  //   this.commonServices.showLoader();

  //   try {
  //     this.commonServices.itemPedidoAberto = await this.httpUtilProvider.get(environment.WS_VENDAS +
  //       'PedidoVenda/list/' + localStorage.getItem('empresa') + '/abertos');

  //     // if(this.commonServices.itemPedidoAberto != {} ) {
  //     this.items = this.commonServices.itemPedidoAberto;
  //     this.totalPages = this.items.totalPages;
  //     this.commonServices.totalPedidoEmAberto = this.items.numberOfElements;

  //     this.items = this.items.content;

  //     this.commonServices.loading.dismiss();
  //     // this.pedidolista.contaPedidoEmAberto();

  //     this.exibeImagemEmAberto = this.commonServices.exibeImagemPedidoEmAberto;

  //     // }
  //   } catch (error) {
  //     this.commonServices.loading.dismiss();
  //     this.commonServices.showToast(error);
  //   }

  // }

  async RemoveOrder(PedidoId) {
    // let result = [];
    try {
      await this.httpUtilProvider.delete(
        ENV.WS_VENDAS+API_URL+
        "PedidoVenda/" +
        localStorage.getItem("empresa") +
        "/" +
        PedidoId
      );
    } catch (error) {
      console.log(error);
      // this.commonServices.showAlert2("Ops!",error);
    }
  }

  async SearchOrder(event: any) {
    this.commonServices.showLoader();

    try {
      this.items = await this.httpUtilProvider.get(
        ENV.WS_VENDAS+API_URL+
        "PedidoVenda/" +
        localStorage.getItem("empresa") +
        "/" +
        event.target.value
      );

      // console.log(this.items);

      // this.items = this.items.content
      this.commonServices.loading.dismiss();
      this.itemSearch = event.target.value;
      this.existOne = true;
    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }

  getNextPage(page: number) {
    return this.httpUtilProvider.get(
      ENV.WS_VENDAS+API_URL+
      "PedidoVenda/list/" +
      localStorage.getItem("empresa") +
      "?page=" +
      page
    );
  }

  getOrders(page: number) {
    this.getNextPage(page)
      .then((result: any) => {
        for (let i = 0; i < result.content.length; i++) {
          let it = result.content[i];
          this.items.push(it);
        }

        if (this.infiniteScroll) {
          this.infiniteScroll.complete();
          if (this.items.length == result.total) {
            this.infiniteScroll.enable(false);
          }
        }
      }, (error) => {

      }
      )
      .catch((error: any) => {
        this.commonServices.showToast(error.json().detail);
      });
  }

  loadingOrders(infiniteScroll) {
    this.currentPage += 1;
    if (this.currentPage <= this.totalPages) {
      this.getOrders(this.currentPage);
    }
    infiniteScroll.complete();
  }

  getItems(ev) {
    // Reset items back to all of the items
    // this.initializeItems();

    // set val to the value of the ev target
    var val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != "") {
      this.items = this.items.filter(items => {
        return items.toLowerCase().indexOf(val.toLowerCase()) > -1;
      });
    }
  }

  doInfinite(infiniteScroll) {
    setTimeout(() => {
      for (let i = 0; i < 30; i++) {
        this.items.push(this.items.length);
      }
      infiniteScroll.complete();
    }, 500);
  }

  getOpcaoRetirada(tipo) {
    for (var i = 0; i < this.commonServices.opcaoRetirada.length; i++) {
      if (this.commonServices.opcaoRetirada[i] == tipo) {
        this.commonServices.codigoTipoRetirada = i;
        break;
      }
    }
  }

  closeListaProduto() {
    this.exibeProdutosPedido = false;
    this.produtos = [];
    this.content.scrollTo(0, this.distance);
  }

  getProdutosPedido(pedido) {
    let produtosModal = this.modalCtrl.create('PedidoListaModalPage', { pedido: pedido }, {
      showBackdrop: false
    });
    produtosModal.present({ animate: false });
  }

  edititem(item) {
    // this.navCtrl.pop();
    this.commonServices.ItensPedidoAdd = item;
    this.commonServices.sistuacaoPedido = "A";
    this.commonServices.valorFrete = item.frete.valor;
    this.commonServices.enderecoSelected = false;
    this.commonServices.codigoCartaoPedido = item.cartaoPedido;
    this.commonServices.codigoBarraCartaoPedido = item.barCodecartaoPedido;

    console.log(item)
    this.commonServices.pedidoAtualizado.seq_endereco_entrega = item.seqEnderecoEntrega;
    console.log("codigoCartaoPedido");
    console.log(this.commonServices.codigoCartaoPedido);
    this.commonServices.cardSelected =
      this.commonServices.codigoCartaoPedido != "0" ||
      this.commonServices.codigoCartaoPedido != "";

    this.commonServices.alteracaoItemPedido = true;
    this.commonServices.numPedido = item.numpedido;
    this.commonServices.digitoPedido = item.digito;
    this.commonServices.statusPedido = "M";
    this.commonServices.docCliente = item.cgccpf_cliente;
    this.commonServices.nomeCliente = item.nome_cliente;

    this.commonServices.clientSelected = item.cgccpf_cliente != null && item.cgccpf_cliente.trim().length > 0;
    this.commonServices.pedidoAtualizado.entrega = item.tipoEntrega;

    this.commonServices.tipoRetirada = item.tipoEntrega;
    this.commonServices.tipoDocumento = item.tipodoc;
    this.commonServices.refreshTelaPedido = false;
    this.getOpcaoRetirada(this.commonServices.tipoRetirada);

    this.stopWays();

    this.pedidolista.reabrirPedido(this.commonServices.numPedido);

    let nav = this.app.getRootNav();
    nav.push("PedidoSacola", {
      item: item,
      mode: 2
    });


  }

  removeItemList(item) {
    for (let i = 0; i < this.items.length; i++) {
      if (this.items[i] == item) {
        this.items.splice(i, 1);
      }
    }
  }



  removeItem(item) {
    let prompt = this.alertCtrl.create({
      title: "Apagar Pedido",
      // message:'Tem certeza? Apagando um pedido, os dados inseridos não poderão ser recuperados. Para confirmar, por favor digite "APAGAR" na caixa abaixo e clique em "Apagar Pedido".',
      message: "Tem certeza? Apagando um pedido, os dados inseridos não poderão ser recuperados.",
      
      // inputs: [
      //   {
      //     id: "idinput",
      //     name: "title",
      //     placeholder: "Digite APAGAR"
      //   }
      // ],
      buttons: [
        {
          text: "Voltar",
          handler: () => {
            console.log("Cancelado");
          }
        },
        {
          text: "Apagar Pedido",
          handler: () => {

              // by Ryuge 28/11/2019
              try {
                this.RemoveOrder(item.numpedido);
                this.removeItemList(item);
                this.getPedidoAberto();
              } catch (error) {
                this.commonServices.showToast(error);
              }

          //   if ("APAGAR" == data.title.toUpperCase()) {
          //     try {
          //       this.RemoveOrder(item.numpedido);
          //       this.removeItemList(item);
          //       this.getPedidoAberto();
          //     } catch (error) {
          //       this.commonServices.showToast(error);
          //     }
          //   } else {
          //     this.removeItem(item);
          //     this.commonServices.showToast("Texto digitado está incorreto !");
          //   }
          }
        }
      ],
      cssClass: "alertCustomCss"
    });

    prompt.present()

    // .present()
    // .then(() => {
    //   setTimeout(
    //   document.getElementById("idinput").focus(), 250 )
    // })
    // .catch();
  }

}
