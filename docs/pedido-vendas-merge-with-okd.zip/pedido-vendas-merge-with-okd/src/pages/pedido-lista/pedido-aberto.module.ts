import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { PipesModule } from './../../pipes/pipes.module';
import { PedidoAberto } from './pedido-aberto';


 
@NgModule({
  declarations: [
    PedidoAberto,
  ],
  imports: [
    IonicPageModule.forChild(PedidoAberto),
    PipesModule,TranslateModule

  ],
  exports: [
    PedidoAberto
  ]
})
export class PedidoAbertoModule {}