import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { PipesModule } from './../../pipes/pipes.module';
import { PedidoFinalizado } from './pedido-finalizado';


 
@NgModule({
  declarations: [
    PedidoFinalizado,
  ],
  imports: [
    IonicPageModule.forChild(PedidoFinalizado),
    PipesModule,TranslateModule
  ],
  exports: [
    PedidoFinalizado
  ]
})
export class PedidoFinalizadoModule {}