import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { PipesModule } from './../../pipes/pipes.module';
import { PedidoFinalizadoModule } from './pedido-finalizado.module';
import { PedidoLista } from './pedido-lista';

 
@NgModule({
  declarations: [
    PedidoLista,
  ],
  imports: [
    IonicPageModule.forChild(PedidoLista),
    PipesModule,
    TranslateModule,
    PedidoFinalizadoModule,PedidoFinalizadoModule
  ],
  exports: [
    PedidoLista
  ]
})
export class PedidoListaModule {}