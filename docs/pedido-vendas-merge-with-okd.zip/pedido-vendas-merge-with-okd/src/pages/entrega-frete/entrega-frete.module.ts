import { NgModule } from "@angular/core";
import { IonicPageModule } from "ionic-angular";
import { EntregaFrete } from './entrega-frete';

import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { IonicSwipeAllModule } from 'ionic-swipe-all';
import { LongPressModule } from 'ionic-long-press';

@NgModule({
	declarations: [EntregaFrete],
	imports: [
	  IonicPageModule.forChild(EntregaFrete),
	  PipesModule,DirectivesModule,
	  IonicSwipeAllModule,LongPressModule,
	],	
})
export class EntregaModule {

}
