import { Component, ElementRef, NgZone, ViewChild } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
// Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA 
import { NavigationBar } from '@ionic-native/navigation-bar';
import { StatusBar } from '@ionic-native/status-bar';
import { AlertController, Button, Content, IonicPage, Keyboard, ModalController, NavController, NavParams, Platform, Slides } from 'ionic-angular';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Clientes, Endereco, Sequence } from '../../class/class.cliente';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from './../../environments/environments';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

// class
@IonicPage()
@Component({
	selector: 'page-entrega-frete',
	templateUrl: 'entrega-frete.html'
})
export class EntregaFrete {

	@ViewChild(Content) content: Content;   // by ryuge 19/10/2018	

	public idFreteSelecionado;
	public seqEnderecoEntrega;

	public showHeaderTexts: boolean;
	public exibeButaoNext: boolean = false;
	public exibeButaoBack: boolean = false;
	public exibeEndereco: boolean = false;
	public showSkeleton: boolean = false;
	public isFocused: boolean = false;

	public hideImage: boolean = false;
	public selectedIndex: number;
	public fieldsEndereco: DataFieldsEndereco;

	public modePageReturn: any = 0;

	numeroPedido;
	pedidoCab: any;
	pedidoItem;
	item: any;
	dados: any;

	endereco;
	condicao;
	retirada;
	pagamento;
	qtdItens;
	icmsRetido;
	frete;
	total;
	qtdParcela;
	parcela;
	entrada;

	MSG_AVISO = 'Não existe entrega nessa localidade.';

	existeFrete: boolean = false;
	existeEntrada: boolean = false;
	exibeImagem: boolean = false;


	public showCadastro: boolean = false;
	public valorTotal;
	public seq: Sequence;
	public cliente: Clientes;
	public clientesEndereco: Endereco;

	// private modulo: any = 0;
	public enderecos: any;
	public valorFretes = [];

	@ViewChild('slideForm') slideForm: Slides;
	@ViewChild('sliderHeader') sliderHeader: Slides;
	@ViewChild('sliderBody') sliderBody: Slides;

	@ViewChild('map') mapElement: ElementRef;
	@ViewChild('index') index: number;

	@ViewChild('campo1') campo1;
	@ViewChild('campo2') campo2;
	@ViewChild('campo3') campo3;
	@ViewChild('campo4') campo4;

	@ViewChild('nextButton', { read: Button }) private nextButton: Button;
	@ViewChild('backButton', { read: Button }) private backButton: Button;
	public skeletonLoading: boolean = false;

	constructor(
		public commonServices: CommonServices,
		private httpUtilProvider: HttpUtilProvider,
		public navCtrl: NavController,
		public Keyb: Keyboard,
		public navParams: NavParams,
		private alertCtrl: AlertController,
		public modalCtrl: ModalController,
		public http: Http,
		public nZone: NgZone,
		public platform: Platform,
		public statusBar: StatusBar,
		private navigationBar: NavigationBar,
		private androidFullScreen: AndroidFullScreen
	) {

		// Deve ser comnetado (SplashScreen, StatusBar) quando for gerar versão PWA 
		let autoHide: boolean = true;
		this.navigationBar.setUp(autoHide);
		this.statusBar.hide();


		// by ryuge 27/09/2018	
		platform.registerBackButtonAction(() => {
			this.navCtrl.pop();
		}, 1);

		this.showCadastro = false;
		this.fieldsEndereco = new DataFieldsEndereco();

		this.seq = new Sequence();
		this.clientesEndereco = new Endereco();

		this.numeroPedido = this.commonServices.numPedido + '-' + this.commonServices.digitoPedido;
		this.item = this.navParams.get('item');
		this.modePageReturn = this.navParams.get('modulo');

		console.log('PARAMETROS');
		console.log(this.item);
		console.log(this.condicao);

		this.valorTotal = this.item.totpedido;

		if (this.valorTotal == NaN) {
			this.valorTotal = this.commonServices.ItensPedidoAdd.totpedido;
		}

		// this.enderecos =  this.commonServices.dadosCliente.enderecos;
		
		// by ryuge 24/12/2018
		platform.registerBackButtonAction(() => {
			console.log("backPressed 1");
		}, 1);
	}

	goToFullScreen() {
		this.androidFullScreen.isImmersiveModeSupported()
			.then(() => this.androidFullScreen.immersiveMode())
			.catch((error: any) => console.log(error));
	}


	// by ryuge 19/10/2018	
	scrollToTop() {
		// Scrolls to the top, ie 0px to top.
		this.content.scrollToTop();
	}

	// by ryuge 06/11/2018	
	scrollToBottom() {
		setTimeout(() => {
			this.content.scrollToBottom();
		});
		// this.content.resize();
	}

	// by ryuge 19/10/2018	
	scrollTo(y: number) {
		// set the scrollLeft to 0px, and scrollTop to 500px
		// the scroll duration should take 200ms
		this.content.scrollTo(0, y, 200);
	}


	ionViewDidLoad() {
		this.getEnderecoEntrega();
	}

	//Criado por Nicollas Bastos em 25/09/2018
	ionViewDidEnter() {
		// by ryuge 27/09/2018	
		this.platform.registerBackButtonAction(() => {
			this.navCtrl.pop();
		}, 1);

	}

	ionViewWillEnter() {
		this.goToFullScreen();
		this.isFocused = false;
	}

	//Comentado por Nicollas bastos em 19-09-2018
	// Motivo: Nenhum dos dados buscados nesse método estavam em uso

	// ionViewWillEnter() {

	// 	// cabeçalho do pedido
	// 	this.httpUtilProvider
	// 		.getPedido(this.commonServices.numPedido)
	// 		.then(result => {
	// 			this.pedidoCab = result;

	// 			console.log('pedidoCab');
	// 			console.log(this.pedidoCab);

	// 			this.retirada = this.commonServices.tipoRetirada;
	// 			// this.pagamento = this.pedidoCab.descricao_condpag;
	// 			this.icmsRetido = this.pedidoCab.icmsRetido;
	// 			this.qtdItens = this.pedidoCab.numitens;
	// 			this.frete = this.pedidoCab.frete.valor;
	// 			this.endereco = this.pedidoCab.frete.endereco;
	// 			this.total = this.pedidoCab.totpedido;

	// 		});

	// 	// item do pedido
	// 	this.httpUtilProvider
	// 		.getItensPedido(this.commonServices.numPedido)
	// 		.then(result => {
	// 			this.pedidoItem = result.content;
	// 		});

	// }

	ngAfterViewInit() {
		let el1 = this.nextButton._elementRef.nativeElement;
		let el2 = this.backButton._elementRef.nativeElement;

		//Button Next
		el1.addEventListener('click', (event) => {
			this.stopBubble(event);
		});
		el1.addEventListener('mousedown', (event) => {
			this.stopBubble(event);
		});
		el1.addEventListener('touchdown', (event) => {
			this.stopBubble(event);
		});
		el1.addEventListener('touchmove', (event) => {
			this.stopBubble(event);
		});
		el1.addEventListener('touchstart', (event) => {
			this.stopBubble(event);
		});
		el1.addEventListener('touchend', (event) => { //Triggered by a phone
			this.stopBubble(event);
			this.next(event);
		});
		el1.addEventListener('mouseup', (event) => { //Triggered by the browser
			this.next(event);
		});

		//Button Back
		el2.addEventListener('click', (event) => {
			this.stopBubble(event);
		});
		el2.addEventListener('mousedown', (event) => {
			this.stopBubble(event);
		});
		el2.addEventListener('touchdown', (event) => {
			this.stopBubble(event);
		});
		el2.addEventListener('touchmove', (event) => {
			this.stopBubble(event);
		});
		el2.addEventListener('touchstart', (event) => {
			this.stopBubble(event);
		});
		el2.addEventListener('touchend', (event) => { //Triggered by a phone
			this.stopBubble(event);
			this.back();
		});
		el2.addEventListener('mouseup', (event) => { //Triggered by the browser
			this.back();
		});
	}
	stopBubble(event) {
		event.preventDefault();
		event.stopPropagation(); //Stops event bubbling
	}

	presentAlert(msg) {
		let alert = this.alertCtrl.create({
			title: 'Pedido: ' + this.commonServices.numPedido + '-' + this.commonServices.digitoPedido,
			subTitle: msg,
			buttons: [
				{
					text: 'Ok',
					handler: data => {

						let ststusPedido: boolean = true;
						this.navCtrl.setRoot("PedidoLista", { refresh: ststusPedido });
						this.navCtrl.popToRoot(); // by Ryuge 21/11/2019

					}
				}
			]
		});
		alert.present();
	}



	changeHeaderSlide() {
		let currentIndex1 = this.sliderHeader.getActiveIndex();
		this.index = currentIndex1;
		this.sliderBody.slideTo(currentIndex1, 500);

		// if (this.sliderHeader.length() != this.sliderHeader.getActiveIndex() + 1) {
		// 	let e: string = this.enderecos[currentIndex1].ds_ende+','+ this.enderecos[currentIndex1].ds_bairro
		// 	+','+ this.enderecos[currentIndex1].ds_uf
		// 	this.getGeoLocalizacao(e);
		// }

	}

	changeBodySlide() {
		let currentIndex1 = this.sliderBody.getActiveIndex();
		this.index = currentIndex1;
		this.sliderHeader.slideTo(currentIndex1, 500);
	}

	// by Ryuge 29/11/2018
	retornarPagina() {

		// by Ryuge 13/12/2018
		if(this.commonServices.valorFrete == 0)
		{
			this.modePageReturn = 0;
		}

		switch (this.modePageReturn) {
			case 1:
				this.navCtrl.push("PedidoFinalizacao", {pedido: this.commonServices.pedidoHeader, modulo: 1 })
				break;
			default:
				this.navCtrl.pop();
				break;
		}
		
	}


	//Alterado por Nicollas Bastos em 25/09/2018
	selectFrete(idx, frete) {

		this.seqEnderecoEntrega = this.enderecos[idx].seq_endereco;
		this.idFreteSelecionado = frete.id;

		this.commonServices.valorFrete = frete.valor;
		// console.log('VALOR FRETE');
		// console.log(this.commonServices.valorFrete);

		this.atualizaFrete();
		this.commonServices.enderecoSelected = true;

	}

	async atualizaFrete() {
		await this.httpUtilProvider.post(ENV.WS_VENDAS+API_URL+ 'PedidoVenda/'
			+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido + '/entrega'
			+ '?' + 'seqEnderecoEntrega=' + this.seqEnderecoEntrega
			+ '&' + 'idTransportadora=' + this.idFreteSelecionado, {}).then(result => {

				if (this.commonServices.manutencaoPedido) {
					this.navCtrl.pop();
					// this.navCtrl.push("PedidoFinalizacao", {pedidoCab: p1, condicao: p2 })
				} else {
					this.commonServices.ItensPedidoAdd = result;

					console.log('atualizaFrete');
					console.log(result);

					if(this.modePageReturn == 1){
						this.navCtrl.push("PedidoFinalizacao", {pedido: result, modulo: 1 })
					}else{
						this.navCtrl.push("FormasPagamento", { item: result })
					}
					
				}
			});

	}

	async getEnderecoEntrega() {
		this.skeletonLoading = true;
		try {

			let result: any = await this.httpUtilProvider.get(ENV.WS_VENDAS+API_URL+ 'PedidoVenda/'
				+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido + '/listEnderecos');

			this.enderecos = result;
			// this.fretes = this.enderecos.fretes;

			console.log('getEnderecoEntrega');
			console.log(this.item);

			for (let i = 0; i < this.enderecos.length; i++) {

				// this.fretes[i+1] = this.enderecos[i].fretes;
				console.log('Frete:' + i);
				// console.log(this.enderecos[i].fretes);

				if (this.enderecos[i].fretes.length > 0) {
					this.enderecos[i].status = 1
				} else {
					this.enderecos[i].status = 0
				}

				console.log(this.enderecos);

			}


		} catch (error) {
			this.commonServices.showToast(error.json().detail);
		}

		this.nZone.run(() => {
			this.skeletonLoading = false;
		});
	}


	onFocus(e) {

		if (e.target.tagName == 'INPUT') {

			// let texto: string = e.target.value;
			// this.exibeButaoNext = texto.length > 0;

			if (e.target.value != "" || e.target.value != null) {
				this.showHeaderTexts = true;
			} else {
				this.showHeaderTexts = false;
			}
		}

		if (this.platform.is('ios') || this.platform.is('android')) {
			this.hideImage = this.Keyb.isOpen();
			// this.scrollToBottom();
			this.scrollTo(10);
		}
	}


	getCep2(cep: string) {

		if (cep == '') {
			this.selectedIndex = 5;
		} else {

			this.clearFields(); // limpa campos
			this.showSkeleton = true;
			let valor: any = cep;
			valor = valor.replace(/\D/g, ''); // remove mascara

			let headers = new Headers();
			headers.append('x-auth-token', localStorage.getItem('token'));
			let options = new RequestOptions({ headers: headers });

			return new Promise(resolve => {
				this.http.get(ENV.WS_PUBLIC+API_URL+ 'consultaCEP/' + valor, options).subscribe(data => {
					resolve(data);
					console.log(data.json());
					this.dados = data.json();
					this.fieldsEndereco.cep = this.commonServices.formata(valor, 'CEP');
					this.fieldsEndereco.endereco = this.dados.logradouro;
					this.fieldsEndereco.bairro = this.dados.bairro;
					this.fieldsEndereco.uf = this.dados.estado;
					this.nZone.run(() => {
						this.exibeEndereco = true
						this.showSkeleton = false;
					})
					this.exibeButaoNext = true;
					this.isFocused = true;
				}, err => {
					console.log(err);
					this.exibeButaoNext = false;
					this.isFocused = false;
					this.nZone.run(() => {
						this.showSkeleton = false;
					})
					this.setFocusBack(1);
				});
			});

		}

	}



	async getCep(e) {

		if (e == '') {
			this.selectedIndex = 5;
			//  this.getFocusBack();
		} else {

			try {

				this.showSkeleton = true;
				let valor: any = e;
				valor = valor.replace(/\D/g, ''); // remove mascara

				this.dados = await this.httpUtilProvider.getNoAlert(ENV.WS_PUBLIC+API_URL+ 'consultaCEP/' + valor);
				console.log(this.dados);

				if (this.dados != null) {
					this.fieldsEndereco.cep = this.commonServices.formata(valor, 'CEP');
					this.fieldsEndereco.endereco = this.dados.logradouro;
					this.fieldsEndereco.bairro = this.dados.bairro;
					// this.clientesEndereco.cidade = this.dados.cidade;
					this.fieldsEndereco.uf = this.dados.estado;

					console.log(this.fieldsEndereco.cep);
					console.log(this.fieldsEndereco.endereco);
					console.log(this.fieldsEndereco.bairro);

					this.nZone.run(() => {
						this.exibeEndereco = true
						this.showSkeleton = false;
					})
				}

			} catch (error) {
				this.showSkeleton = false;
				this.setFocusBack(1);
				// this.commonServices.showToast(error);
			}

		}
	}

	pesquisaCEP(event) {
		let mymodal = this.modalCtrl.create('ConsultaCep', { modoConsulta: false }, {
			showBackdrop: false,
			enterAnimation: 'modal-md-slide-in',
			leaveAnimation: 'modal-md-slide-out',
		});
		mymodal.onDidDismiss(data => {
			if (data) {

				this.fieldsEndereco.cep = this.commonServices.formata(data.cep, 'CEP');
				this.fieldsEndereco.numero = data.numero;
				this.fieldsEndereco.complemento = data.complemento;
				// this.exibeButaoNext = this.fieldsEndereco.cep != '';
				this.getCep2(this.fieldsEndereco.cep);
				setTimeout(() => {
					this.campo1.setFocus();
				}, 500);
			}
		})
		mymodal.present();
	}
	// async getCliente() {
	// 	let result: any = await this.httpUtilProvider.getNoAlert(environment.WS_CRM + 'cliente/' + this.commonServices.docCliente);
	// 	this.cliente = result;
	// }


	async gravaCliente() {

		let result: any;

		try {

			let alistItems: {
				id: Sequence;
				cd_status: string;
				tp_ende: string;
				ds_ende: string;
				nu_ende: string;
				ds_compl: string;
				ds_bairro: string;
				ds_cep: string;
				ds_uf: string;
				nu_praca: number;
				ds_obs: string;
				nu_referencia_pessoal: string;
				cd_inscricao: string;
				usuario_cadastrou: string;
				latitude: string;
				longitude: string;
			};


			let cep = this.fieldsEndereco.cep;
			cep = cep.replace(/\D/g, ''); // remove mascara

			alistItems = {
				id: this.seq,
				cd_status: 'L',
				tp_ende: 'ENTREGA',
				ds_ende: this.fieldsEndereco.endereco,
				nu_ende: this.fieldsEndereco.numero,
				ds_compl: this.fieldsEndereco.complemento,
				ds_bairro: this.fieldsEndereco.bairro,
				ds_cep: cep,
				ds_uf: this.fieldsEndereco.uf,
				nu_praca: 0,
				ds_obs: '',
				nu_referencia_pessoal: '',
				cd_inscricao: '',
				usuario_cadastrou: '',
				latitude: '',
				longitude: ''

			};


			// this.getCliente();
			let dados: any = await this.httpUtilProvider.getNoAlert(ENV.WS_CRM+API_URL+ 'cliente/' + this.commonServices.docCliente);
			this.cliente = dados;

			this.cliente.enderecos.push(alistItems);

			console.log('dados cliente');
			console.log(this.cliente);

			result = await this.httpUtilProvider.post(ENV.WS_CRM+API_URL+ 'cliente/save/', this.cliente);

			this.getEnderecoEntrega();

		} catch (error) {
			this.commonServices.showToast(result);
		}

	}

	validField(e) {

		let texto: string = e.target.value;

		if (texto.length == 0) {
			this.exibeButaoNext = false;
			this.isFocused = false;
			// this.clearFields();
		}else{
			this.exibeButaoNext = true;	
			this.isFocused = true;
		}
		// this.exibeButaoNext = texto.length > 0;

		// button back virtual keyboard
		if (e.keyCode === 229 || e.key == "Backspace" || e.keyCode == 8) {

			if (e.target.name === 'cep') {

				let numero: any = e.target.value;
				numero = numero.replace(/\D/g, ''); // remove mascara
				e.target.value = numero;

				this.getCep2(texto);

				// this.clientesEndereco.ds_cep = numero;
				// this.exibeEndereco = numero > 0;
			}
		}

	}

	goToLastSlide(idx) {
		this.slideForm.slideTo(idx, 500);
	}

	next(e) {

		if (e.target.name === 'cep') {
			let numero: any = e.target.value;
			this.getCep2(numero);
		}

		if (this.exibeButaoNext) {

			// grava os dados do novo enderço;
			if (this.slideForm.length() == this.slideForm.getActiveIndex() + 1) {

				this.exibeEndereco = false;
				this.showCadastro = false;
				console.log('GRAVAR ENDEREÇO');
				this.gravaCliente();

				// // retorna a tela lista de endereço
				// let currentIndex1: any = this.slideForm.getActiveIndex();
				this.goToLastSlide(0);
				// setTimeout(() => {
				// 	this.slideForm.slideTo(currentIndex1, 0);
				// });


			} else {

				if (this.slideForm.length() > this.slideForm.getActiveIndex()) {
					let currentIndex1: any = this.slideForm.getActiveIndex();

					this.slideForm.slideTo(currentIndex1 + 1, 500);

					this.exibeButaoNext = true;
					this.exibeButaoBack = true;

					// this.selectedIndex = currentIndex1;
					console.log('INDEX');
					console.log(currentIndex1)
					this.setFocus(currentIndex1);
				}

			}


		}

	}

	back() {

		let currentIndex1: any = this.slideForm.getActiveIndex();
		this.slideForm.slideTo(currentIndex1 - 1, 500);

		if (this.clientesEndereco.ds_ende != '') {
			this.exibeButaoNext = true;
			this.showHeaderTexts = true;
		} else {
			this.exibeButaoNext = false;
			this.showHeaderTexts = false;
		}

		console.log('BACK-INDEX');
		console.log(currentIndex1)

		this.setFocusBack(currentIndex1);

	}

	HideKeyboard() {
		this.Keyb.close();
	}

	setFocus(index) {
		switch (index) {
			case 0:
				if (this.platform.is('ios') || this.platform.is('android')) {
					this.hideImage = this.Keyb.isOpen();
				}
				setTimeout(() => {
					this.campo2.setFocus();
				}, 500);
				this.selectedIndex = 2;
				break;
			case 1:
				if (this.platform.is('ios') || this.platform.is('android')) {
					this.hideImage = this.Keyb.isOpen();
				}
				this.exibeButaoNext = true;
				setTimeout(() => {
					this.campo3.setFocus();
				}, 500);
				this.selectedIndex = 3;
				break;
		}
	}


	setFocusBack(index) {
		switch (index) {
			case 1:
				this.hideImage = false;
				this.exibeButaoBack = false;
				setTimeout(() => {
					this.campo1.setFocus();
				}, 500);
				this.selectedIndex = 1;
				break;
			case 2:
				setTimeout(() => {
					this.campo2.setFocus();
				}, 500);
				this.selectedIndex = 2;
				break;
		}
	}

	getFocus() {

		if (this.selectedIndex == 1) {
			setTimeout(() => {
				this.campo1.setFocus();
			}, 0);
		}

		if (this.selectedIndex == 2) {
			setTimeout(() => {
				this.campo2.setFocus();
			}, 0);
		}

		if (this.selectedIndex == 3) {
			setTimeout(() => {
				this.campo3.setFocus();
			}, 0);
		}

	}

	clearFields(){
		this.fieldsEndereco.cep = '';
		this.fieldsEndereco.endereco = '';
		this.fieldsEndereco.bairro = '';
		this.fieldsEndereco.uf = '';
	}

	addNewAddress() {
		this.fieldsEndereco = new DataFieldsEndereco();
		this.showCadastro = true;
		//by Ryuge 10/01/2019
		this.exibeButaoNext = false;
		this.isFocused = false;
		this.clearFields();

	}

}


export class DataFieldsEndereco {
	cep: string;
	endereco: string;
	numero: string;
	complemento: string;
	bairro: string;
	cidade: string;
	uf: string;
}
