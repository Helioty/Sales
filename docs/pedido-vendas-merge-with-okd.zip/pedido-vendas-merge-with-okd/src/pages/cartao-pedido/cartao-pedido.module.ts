import { NgModule } from "@angular/core";
import { IonicPageModule } from "ionic-angular";
import { CartaoPedido } from './cartao-pedido';

import { PipesModule } from './../../pipes/pipes.module';
import { DirectivesModule } from './../../directives/directives.module';
import { IonicSwipeAllModule } from 'ionic-swipe-all';
import { LongPressModule } from 'ionic-long-press';

// Import library
import { HideKeyboardModule } from 'hide-keyboard';

@NgModule({
	declarations: [CartaoPedido],
	imports: [
	  IonicPageModule.forChild(CartaoPedido),
	  PipesModule,DirectivesModule,
	  IonicSwipeAllModule,LongPressModule,
	  HideKeyboardModule
	],	
})
export class CartaoPedidoModule {

}
