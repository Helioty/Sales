import { Component, ViewChild } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { AlertController, IonicPage, Keyboard, NavController, NavParams, Platform, ViewController } from 'ionic-angular';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoTable } from './../../class/class.pedido';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

//class
@IonicPage()
@Component({
	selector: 'cartao-pedido',
	templateUrl: 'cartao-pedido.html'
})
export class CartaoPedido {

	@ViewChild('input') scanner: any;

	subscription: Subscription;
	public show: boolean = false;
	public showSkeleton: boolean = false;
	public selectedIndex: number;
	private task;
	public titulo;
	public question;
	public codScanner: string = '';
	public codCardPedido: string;
	public retornar: string = '';
	public mode;
	public item: any;
	public isBrowser: boolean = false;
	public showKeyb: boolean = false;
	public finalizar;
	callback: any;

	constructor(
		public platform: Platform,
		public commonServices: CommonServices,
		private httpUtilProvider: HttpUtilProvider,
		public navCtrl: NavController,
		public Keyb: Keyboard,
		public navParams: NavParams,
		private alertCtrl: AlertController,
		private barcodeScanner: BarcodeScanner,
		public viewCtrl: ViewController,
		public http: Http,
		private androidFullScreen: AndroidFullScreen
	) {

		// by ryuge 27/09/2018	
		platform.registerBackButtonAction(() => {
			this.retornarPagina(true)
		}, 1);


		if (this.platform.is('ios') || this.platform.is('android') || this.platform.is('cordova')) {
			this.isBrowser = false;
		} else {
			this.isBrowser = true;
		}

		this.finalizar = this.navParams.get('finalizar');
		this.question = 'Não é o seu cartão?'
		this.titulo = 'Scaneie código de barra do cartão pedido'

		this.mode = this.navParams.get('mode');
		this.retornar = this.navParams.get('back');
		this.callback = this.navParams.get("callback");

		if (this.retornar == 'ProdutoDetalhe') {
			this.item = this.navParams.data.item;
		}

		window.addEventListener("contextmenu", (e) => { e.preventDefault(); });
	}

	goToFullScreen() {
		this.androidFullScreen.isImmersiveModeSupported()
			.then(() => this.androidFullScreen.immersiveMode())
			.catch((error: any) => console.log(error));
	}

	ngOnInit() {
		this.subscription = Observable.fromEvent(document, 'keypress').subscribe((e: KeyboardEvent) => {

			if (e.keyCode != 13) {
				if (e.returnValue) {
					this.codScanner += e.key;
				}
			} else {
				this.scanner.setFocus();
			}

		})
	}


	// by Ryuge 20/11/2019
	// Padido Cabeçalho
	async getPedidoHeader() {
		// cabeçalho do pedido
		await this.httpUtilProvider
		  .getPedido(this.commonServices.numPedido)
		  .then(result => {
			this.commonServices.pedidoHeader = result;
		  });
	  }

	ionViewWillEnter() {
		
		this. getPedidoHeader(); // by Ryuge 20/11/2019

		// by ryuge 27/09/2018	
		this.platform.registerBackButtonAction(() => {
			this.retornarPagina(true)
		}, 1);

		// if(this.commonServices.codigoCartaoPedido != '' || this.commonServices.codigoCartaoPedido != '0'){
		if (this.commonServices.codigoCartaoPedido != 0) {
			this.show = true;
			this.codCardPedido = this.commonServices.codigoCartaoPedido;
			// this.codCardPedido = 'Width: ' + this.platform.width()+ ' Height: ' + this.platform.height();	 
		} else {
			this.codCardPedido = '';
			this.show = false;
		}

		if (this.platform.is('ios') || this.platform.is('android')) {
			this.focusOn();
		}
	}

	focusOn() {
		this.task = setInterval(() => {
			this.scanner.value = '';
			this.scanner.setFocus();
		}, 1000);
	}


	focusOff() {
		setTimeout(() => {
			clearInterval(this.task);
		}, 500);
	}

	validField(e) {
		let texto: string = e.target.value;
		this.show = texto.length > 0;
	}

	async atualizaPedido() {

		try {

			let aResult = [];

			let table: PedidoTable = new PedidoTable();
			table.name = "cartao_pedido";
			table.value = this.commonServices.codigoCartaoPedido;
			aResult.push(table);

			let result: any = await this.httpUtilProvider.post(ENV.WS_VENDAS+API_URL+ 'PedidoVenda/update/'
				+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult)

		} catch (error) {
			this.show = false;
			this.commonServices.cardSelected = false;
			this.commonServices.codigoCartaoPedido = 0;
		}
	}

	async LiberaCartao() {

		try {

			let aResult = [];

			let table: PedidoTable = new PedidoTable();
			table.name = "cartao_pedido";
			table.value = 'P0';
			aResult.push(table);

			let result: any = await this.httpUtilProvider.post(ENV.WS_VENDAS+API_URL+ 'PedidoVenda/update/'
				+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult);

			console.log(result);

		} catch (error) {
			this.show = false;
			this.commonServices.cardSelected = false;
			this.commonServices.codigoCartaoPedido = 0;
		}
	}


	clearCard() {
		this.codCardPedido = '';
		this.show = false;
		this.commonServices.cardSelected = false;
		this.commonServices.codigoCartaoPedido = '0';
		this.LiberaCartao();
	}

	async getClienteCartaoPedido(NumCartao) {
		try {

			let result: any = this.httpUtilProvider.getNoAlert( ENV.WS_VENDAS+
				API_URL+ 'PedidoVenda/' + localStorage.getItem('empresa') + '/' + NumCartao);

			console.log('getClienteCartaoPedido');
			console.log(result);

			this.commonServices.dadosCliente = result;

		} catch (error) {
			this.commonServices.showToast(error.json().detail);
		}
	}

	setCardPedido(e: any) {

		try {
			this.showSkeleton = true;
			this.commonServices.cardSelected = false;
			this.commonServices.codigoCartaoPedido = e.target.value;
			this.codCardPedido = this.commonServices.codigoCartaoPedido;
	
			let aResult = [];
			let table: PedidoTable = new PedidoTable();
			table.name = "cartao_pedido";
			table.value = this.codCardPedido.toUpperCase();
			aResult.push(table);
	
			let headers = new Headers();
			headers.append('x-auth-token', localStorage.getItem('token'));
			let options = new RequestOptions({ headers: headers });
	
			return new Promise(resolve => {
				this.http.post( ENV.WS_VENDAS+API_URL+'PedidoVenda/update/'
					+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult, options).subscribe(data => {
						resolve(data);
						this.commonServices.dadosCliente = data.json();
						this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '';
	
						this.show = true;
						this.showSkeleton = false;
	
						console.log(this.commonServices.dadosCliente);
	
						if (this.commonServices.dadosCliente.cgccpf_cliente != null) {
	
							this.commonServices.clientSelected = true;
							this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
							this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;
	
							// comentado por Ryuge 16/10/2018 
							// this.navCtrl.push("Cliente", { back: true });
	
						} else {
							this.commonServices.clientSelected = false;
							this.commonServices.docCliente = '';
							this.commonServices.nomeCliente = '';
						}
	
	
					}, err => {
						console.log('ERRO CARTAO PEDIDO');
						console.log(err);
						this.clearCard();
						this.commonServices.showAlert2(err.json().title, err.json().detail);
					});
			});
	
			
		} catch (error) {
			// by Ryuge 19/11/2019
			this.commonServices.showAlert2('Atenção!', error);
		}

	}

	setCardPedidoKeyboard(e: any) {

		let valor =  'P'+e;

		this.showSkeleton = true;
		this.commonServices.cardSelected = false;
		this.commonServices.codigoCartaoPedido = valor;
		this.codCardPedido = this.commonServices.codigoCartaoPedido;

		let aResult = [];
		let table: PedidoTable = new PedidoTable();
		table.name = "cartao_pedido";
		table.value = this.codCardPedido.toUpperCase();
		aResult.push(table);

		let headers = new Headers();
		headers.append('x-auth-token', localStorage.getItem('token'));
		let options = new RequestOptions({ headers: headers });

		return new Promise(resolve => {
			this.http.post(ENV.WS_VENDAS+API_URL+ 'PedidoVenda/update/'
				+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult, options).subscribe(data => {
					resolve(data);
					this.commonServices.dadosCliente = data.json();
					this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '';

					this.show = true;
					this.showSkeleton = false;

					console.log(this.commonServices.dadosCliente);

					if (this.commonServices.dadosCliente.cgccpf_cliente != null) {

						this.commonServices.clientSelected = true;
						this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
						this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;

						// comentado por Ryuge 16/10/2018 
						// this.navCtrl.push("Cliente", { back: true });

					} else {
						this.commonServices.clientSelected = false;
						this.commonServices.docCliente = '';
						this.commonServices.nomeCliente = '';
					}

					this.focusOn();

				}, err => {
					console.log('ERRO CARTAO PEDIDO');
					console.log(err);
					this.focusOn();
					this.clearCard();
					this.commonServices.showAlert2(err.json().title, err.json().detail);
				});
		});

	}


	// setCardPedido2(e: any) {

	// 	this.showSkeleton = true;
	// 	this.commonServices.cardSelected = false;
	// 	this.commonServices.codigoCartaoPedido = e.target.value;
	// 	this.codCardPedido = this.commonServices.codigoCartaoPedido;

	// 	let aResult = [];
	// 	let table: PedidoTable = new PedidoTable();
	// 	table.name = "cartao_pedido";
	// 	table.value = this.codCardPedido.toUpperCase();
	// 	aResult.push(table);

	// 	this.httpUtilProvider.post(environment.WS_VENDAS + 'PedidoVenda/update/'
	// 		+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult).then(

	// 			data => {

	// 				this.commonServices.dadosCliente = data;
	// 				this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '';

	// 				this.show = true;
	// 				this.showSkeleton = false;

	// 				console.log(this.commonServices.dadosCliente);

	// 				if (this.commonServices.dadosCliente.cgccpf_cliente != null) {

	// 					this.commonServices.clientSelected = true;
	// 					this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
	// 					this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;

	// 					// this.navCtrl.push("Cliente", { back: true });

	// 				} else {
	// 					this.commonServices.clientSelected = false;
	// 					this.commonServices.docCliente = '';
	// 					this.commonServices.nomeCliente = '';
	// 				}

	// 			}, err => {
	// 				console.log('ERRO CARTAO PEDIDO');
	// 				console.log(err);

	// 				this.show = false;
	// 				this.commonServices.cardSelected = false;
	// 				this.commonServices.codigoCartaoPedido = '';

	// 				this.clearCard();

	// 			  }
	// 		);
	// }


	scanCode() {
		this.barcodeScanner.scan().then(barcodeData => {
			let codScanner = barcodeData.text;
			this.scanner = codScanner;
			this.commonServices.codigoCartaoPedido = this.scanner;
			this.codCardPedido = this.commonServices.codigoCartaoPedido;

			let aResult = [];
			let table: PedidoTable = new PedidoTable();
			table.name = "cartao_pedido";
			table.value = this.commonServices.codigoCartaoPedido;
			aResult.push(table);

			this.httpUtilProvider.post( ENV.WS_VENDAS+API_URL+ 'PedidoVenda/update/'
				+ localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult).then(

					data => {

						this.commonServices.dadosCliente = data;
						this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '';

						this.show = true;
						this.showSkeleton = false;

					}
				)
				.catch(error => {
					this.show = false;
					this.commonServices.cardSelected = false;
					this.commonServices.codigoCartaoPedido = '';

					this.clearCard();

				})

		}, (err) => {
			this.clearCard();
			console.log('Error: ', err);
		});
	}


	getIndexPedido(idPedido, itemSacola: any) {
		let idx;
		for (var i in itemSacola) {

			if (idPedido == itemSacola[i].numpedido) {
				idx = i;
				break;
			}
		}

		return idx;
	}


	// openPedidoSacola() {

	// 	let itPedido;
	// 	let idxPedido;
	// 	if (this.commonServices.sistuacaoPedido == 'A') {
	// 		itPedido = this.commonServices.itemPedidoAberto.content;
	// 		idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
	// 	} else {
	// 		itPedido = this.commonServices.itemPedidoFinalizado.content;
	// 		idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
	// 	}


	// 	if (itPedido != {}) {
	// 		this.navCtrl.push("PedidoSacola", {
	// 			item: itPedido[idxPedido]
	// 		});
	// 	}

	// }


	retornarPagina(closeButton?) {

		console.log(this.retornar);
		console.log("this.finalizar");
		console.log(this.finalizar);

		let noCard = false;
		if (this.retornar == 'PedidoRapido') {
			if (this.finalizar) {
				if (closeButton) {
					if (!this.commonServices.cardSelected) {
						noCard = true;
					}
				}
				// comentado por Ryuge 01/12/2018
				// this.callback(this.finalizar, noCard).then(() => {
				// 	this.navCtrl.pop();
				// });

				// by Ryuge 26/12/2018
				if (this.commonServices.tipoRetirada == "ENTREGA") {
					if (
						((this.commonServices.docCliente == "" &&
							this.commonServices.nomeCliente == "") ||
							this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
					) {
						this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader });
					} else {
						this.navCtrl.push("EntregaFrete", {
							item: this.commonServices.ItensPedidoAdd
						});
					}

				} else {
					// by Ryuge 20/11/2019
					this.navCtrl.push("FormasPagamento", {
						item: this.commonServices.ItensPedidoAdd,mode: 2
					});
				}

			} else {
				this.navCtrl.pop();
			}
		}

		// by Ryuge 16/11/2018	
		if (this.retornar == 'PedidoFinalizacao') {
			this.navCtrl.pop();
			// this.navCtrl.push("PedidoFinalizacao");
		}

		if (this.retornar == 'ProdutoLista') {
			this.navCtrl.push("ProdutoLista");
		}

		if (this.retornar == 'ProdutoDetalhe') {
			this.navCtrl.push("ProdutoDetalhe", { item: this.item, mode: 0 });
		}

		if (this.retornar == 'PedidoSacola') {
			if (this.finalizar) {
				if (closeButton) {
					if (!this.commonServices.cardSelected) {
						noCard = true;
					}
				}
				// this.navCtrl.push("PedidoSacola", { finalizar: this.finalizar, noCard: noCard })

					// by Ryuge 21/11/2019
					if (this.commonServices.tipoRetirada == "ENTREGA") {
						if (
							((this.commonServices.docCliente == "" &&
								this.commonServices.nomeCliente == "") ||
								this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
						) {
							this.navCtrl.push("Cliente", { back: "PedidoRetirada", pedido: this.commonServices.pedidoHeader });
						} else {
							this.navCtrl.push("EntregaFrete", {
								item: this.commonServices.ItensPedidoAdd
							});
						}

					} else {
						// by Ryuge 20/11/2019
						this.navCtrl.push("FormasPagamento", {
							item: this.commonServices.ItensPedidoAdd,mode: 2
						});
					}

			} else {
				this.navCtrl.push("PedidoSacola")
			}
		}

		// by Ryuge 26/12/2018
		if (this.retornar == 'Cliente') {
			// console.log(this.commonServices.docCliente);
			// console.log(this.commonServices.nomeCliente);
			// this.navCtrl.pop();			
			if (
				((this.commonServices.docCliente == "" &&
					this.commonServices.nomeCliente == "") ||
					this.commonServices.nomeCliente == "Não Identificado") && this.commonServices.pedidoHeader.informarCliente == "S"
			) {
				this.navCtrl.push("Cliente", { back: "CartaoPedido", finalizar: true }, { animate: false });
			} else {
				// this.navCtrl.pop();	
				//by Lucas 03/01/2019		
				
				if (this.finalizar) {
					// by Ryuge 26/12/2018
					if (this.commonServices.tipoRetirada == "ENTREGA") {
						this.navCtrl.push("EntregaFrete", {
							item: this.commonServices.ItensPedidoAdd
						});

					} else {
						this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.pedidoHeader });
					}
				} else {
					// by Ryuge 20/11/2019
					if(this.mode == 0){
						// this.navCtrl.pop();
						console.log(this.commonServices.pedidoHeader);
						this.navCtrl.push("PedidoFinalizacao", {pedido: this.commonServices.pedidoHeader })
					}else{
						this.navCtrl.push("ProdutoLista");
					}


				}
			}
		}

	}

	HideKeyboard() {
		this.Keyb.close();
	}


	// by Ryuge 17/09/2019
	inputCard() {
		this.focusOff();
		let prompt = this.alertCtrl.create({
			title: "Cartão Pedido",
			// message: "Digite o número do cartão.",

			inputs: [
				{
					id: "idinput",
					name: "codigo",
					placeholder: "Digite o número do cartão",
					type: 'number'
				}
			],
			buttons: [
				{
					text: "Voltar",
					handler: data => {
						this.focusOn();
						console.log("Cancelado");
					}
				},
				{
					text: "Ok",
					handler: data => {
						console.log(data.codigo);
						this.commonServices.codigoCartaoPedido = data.codigo;
						this.setCardPedidoKeyboard(this.commonServices.codigoCartaoPedido);
					}
				}
			],
			cssClass: "alertCustomCss"
		});
		prompt
			.present()
			.then(() => {
				document.getElementById("idinput").focus();
			})
			.catch();
	}
}

