
import { PipesModule } from './../../pipes/pipes.module';
import { IonicImageViewerModule } from 'ionic-img-viewer';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { TamanhoModal } from './tamanho-modal';
 
@NgModule({
  declarations: [
    TamanhoModal,
  ],
  imports: [
    IonicPageModule.forChild(TamanhoModal),
    PipesModule,IonicImageViewerModule,
  ],
  exports: [
    TamanhoModal
  ]
})
export class  TamanhoModalModule {}