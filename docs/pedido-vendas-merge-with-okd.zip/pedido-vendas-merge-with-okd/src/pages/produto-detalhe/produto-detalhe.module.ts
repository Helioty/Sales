import { NgModule } from '@angular/core';
import { HideKeyboardModule } from 'hide-keyboard';
import { IonicPageModule } from 'ionic-angular';
import { IonicImageViewerModule } from 'ionic-img-viewer';

import { ParcelasModule } from '../parcelas/parcelas.module';
import { PipesModule } from './../../pipes/pipes.module';
import { PedidoListaModule } from './../pedido-lista/pedido-lista.module';
import { ProdutoListaModule } from './../produto-lista/produto-lista.module';
import { ProdutoDetalhe } from './produto-detalhe';

// Import library


@NgModule({
  declarations: [
    ProdutoDetalhe,
  ],
  imports: [
    IonicPageModule.forChild(ProdutoDetalhe),
    PipesModule,IonicImageViewerModule,PedidoListaModule,ProdutoListaModule,
    ParcelasModule,HideKeyboardModule
  ],
  exports: [
    ProdutoDetalhe
  ]
})
export class  ProdutoDetalheModule {}
