import { Component, HostListener, ViewChild } from '@angular/core';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { Content, IonicPage, Keyboard, MenuController, ModalController, NavController, NavParams, Platform, Slides } from 'ionic-angular';
import 'rxjs/add/observable/fromEvent';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoCab, PedidoItens } from './../../class/class.Pedido';
import { PedidoTable } from './../../class/class.pedido';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';
import { TamanhoModal } from './tamanho-modal';

// class

// import { Parcelas } from '../../pages/parcelas/parcelas';
// import { Information } from '../../pages/informationDoProducto/informationDoProducto';
// import { compre_Junto_Page } from '../../pages/compre_Junto/compre_Junto';
// import { Similar_Page } from '../../pages/similarPage/similarPage';
//class

@IonicPage()
@Component({
  selector: 'produto-detalhe',
  templateUrl: 'produto-detalhe.html'
})


export class ProdutoDetalhe {

  // by Helio
  @ViewChild(Content) content: Content;

  @ViewChild("CEP") CEP;


  host: {
    "[onSwipeUp]": "SwipeUp"
  }

  item: any;
  itemFamilia: any;
  condicao: any;
  pedido: any;

  public headerPedido;
  // public dados;
  public familia;
  public images: any;
  public imagesAll: any;
  public PedidoCab: PedidoCab;
  public pedidoItens: PedidoItens;
  public pedidoNovo: PedidoCab;
  public existBasket: boolean = false;
  public qtdItem;
  public exibeSlidePages: boolean = false;
  public existEstoque: boolean = false;
  public exibeFamilia: boolean = true;
  public ionicColor;
  public itemSelecionado;
  private mode;
  public exibeBotao: boolean = false;
  public existClient: boolean = false;
  public cardClient: boolean = false;
  public items: any = [];
  public inFocus: boolean = true;
  subscription: Subscription;
  private idScanner;
  private taskScanner;

  public estqDeposito;

  //MODO DE VIZUALIZAÇÃO
  public modoConsulta;

  @ViewChild('scanner') scanned: any;



  @ViewChild('slideFamilia') slideFamilia: Slides;
  public familiaSelecionada: any;

  // by Helio
  public showMaisInfo: boolean = false;

  // be Helio 04/03/2020
  public consultaFreteOpcs: any;
  public spinnerShow: boolean = false;
  public inFoco: boolean = false;
  public qtdConsulta: number = 1;


  constructor(
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    // private _http: Http,
    private httpUtilProvider: HttpUtilProvider,
    private menu: MenuController,
    public modalCtrl: ModalController,
    private platform: Platform,
    public Keyb: Keyboard,
    // private el: ElementRef,
    private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.existClient = this.commonServices.clientSelected;
    this.exibeBotao = this.commonServices.exibeBotaoComprar;
    this.cardClient = this.commonServices.cardSelected;

    this.modoConsulta = this.navParams.get('modoConsulta');

    this.item = this.navParams.data.item;
    this.mode = this.navParams.get('mode');

    console.log("ITEM");
    console.log(this.item);


    if (!localStorage.getItem("token")) {
      navCtrl.setRoot("LoginPage");
    }

    window.addEventListener("contextmenu", (e) => { e.preventDefault(); });


  }


  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ngOnInit() {

    this.subscription = Observable.fromEvent(document, 'keypress').subscribe((e: KeyboardEvent) => {

      if (e.keyCode != 13) {
        this.idScanner += e.key;
      } else {
        this.inFocus = true;
        if (this.platform.is('ios') || this.platform.is('android')) {
          this.focusOn();
        }
      }

    })
  }









  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {

    if (event.keyCode != 13) {
      this.idScanner += event.key;
    } else {
      this.inFocus = true;
      if (this.platform.is('ios') || this.platform.is('android')) {
        this.focusOn();
      }
    }
  }

  closeKeyboard() {
    setTimeout(() => {
      clearInterval(this.taskScanner);
      this.Keyb.close();
    }, 500);
  }

  focusOn() {
    this.taskScanner = setInterval(() => {
      this.scanned.value = '';
      this.scanned.setFocus();
    }, 1000);
  }


  async atualizaPedido() {

    try {

      let aResult = [];

      let table: PedidoTable = new PedidoTable();
      table.name = "cartao_pedido";
      table.value = this.commonServices.codigoCartaoPedido;
      aResult.push(table);

      await this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/update/'
        + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult)

    } catch (error) {
      this.commonServices.cardSelected = false;
      this.commonServices.codigoCartaoPedido = '';
    }
  }

  //Alterado por Nicollas Bastos em 25/09/2018
  setCardPedido(codCard: any) {

    this.commonServices.codigoCartaoPedido = codCard;

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = this.commonServices.codigoCartaoPedido;
    aResult.push(table);

    this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/update/'
      + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido, aResult).then(

        data => {

          this.commonServices.dadosCliente = data;
          this.commonServices.cardSelected = this.commonServices.codigoCartaoPedido != '';

          if (this.commonServices.dadosCliente.cgccpf_cliente != null && this.commonServices.dadosCliente.cgccpf_cliente.trim().length > 0) {

            this.commonServices.clientSelected = true;
            this.existClient = this.commonServices.clientSelected;
            this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
            this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;

          } else {
            this.commonServices.clientSelected = false;
            this.commonServices.docCliente = '';
            this.commonServices.nomeCliente = '';
          }


          this.atualizaPedido();
          this.commonServices.cardSelected = true;
          this.commonServices.noCard = false;
          this.cardClient = this.commonServices.cardSelected;

        }
      )
      .catch(error => {
        this.cardClient = false;
        this.commonServices.cardSelected = false;
        this.commonServices.codigoCartaoPedido = '';

      })

  }


  async getCard(event: any) {

    if (event.target && event.target.value.length >= 2) {

      let codigo: string = event.target.value;

      if (codigo.substring(0, 1) == 'P') {
        this.setCardPedido(codigo);
      }
    }
  }

  // Controla para qual tela retornar
  retornarPagina() {
    // this.navCtrl.push("ProdutoLista");
    // this.navCtrl.pop();
    console.log('RETORNA PRODUTO LISTA');
    console.log(this.mode);

    // by Ryuge 01/11/2018 - Verifica se já existe item na cesta
    if (this.commonServices.qtdBasketItens > 0) {
      this.mode = 2;
    }

    switch (this.mode) {
      case 1:
        this.navCtrl.pop();
        break;
      case 2:
        this.navCtrl.pop();
        break;
      default:
        // this.navCtrl.pop();
        let status: boolean = true;
        this.navCtrl.setRoot("ProdutoLista", { refresh: status });
        break;
    }
  }

  // by Ryuge 02/10/2019  
  async getEstoqueDeposito() {
    await this.httpUtilProvider
      .getEstoquePedido(
        this.item.codigodigitoembalagem,
        this.commonServices.numPedido
      ).then(result => {
        this.estqDeposito = result;
        console.log(this.estqDeposito);
      }, (error) => {
        this.commonServices.showToast(error.json().detail);
      }
      );
  }

  async getProdutoPorDescricao(codProduto) {

    try {

      this.itemFamilia = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'list/'
        + localStorage.getItem('empresa')
        + '?filter=' + codProduto)

      this.item = this.itemFamilia.content[0];

      // this.getFamilia(codProduto,this.item.cod_produto);
      // this.getListImage(this.item.codigo);

      Promise.all([this.getFamilia(codProduto, this.item.cod_produto), this.getListImage(this.item.codigo)]);

      // console.log('item');
      // console.log(this.item);
      // this.slideFamilia.slideTo(y)
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }

  async getCaracteristica(codProduto: string) {

    try {

      // this.dados = await this.httpUtilProvider.get(environment.WS_PRODUTO + 'caracteristicas/'
      //   + codProduto);
      // this.dados = this.dados.content;


      // this.getFamilia(codProduto,this.item.cod_produto);
      // this.getListImage(this.item.codigo);

      // by Ryuge 16/09/2019 - Solicitado por Arthur, para exibir a imagem menor
      await this.getFamilia(codProduto, this.item.cod_produto);
      await this.getListImage(this.item.codigo);

      // by Ryuge 02/10/2019
      await this.getEstoqueDeposito();

      // by Ryuge 16/09/2019 - comentado: Solicitado por Arthur, para exibir a imagem menor
      // Promise.all([this.getFamilia(codProduto, this.item.cod_produto), this.getListImage(this.item.codigo)]);


    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  async getFamilia(codProdComEmbalagem: string, codProduto: string) {


    try {
      this.familia = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'familia/'
        + localStorage.getItem('empresa') + '/' + codProdComEmbalagem);

      console.log('this.familia');
      console.log(this.familia);

      for (var i in this.familia) {

        for (var x in this.familia[i].items) {
          this.familia[i].qtdItems = x + 1;
          // console.log(codProduto +' - '+ this.familia[i].items[x].id_produto);

          if (this.familia[i].items[x].selected == 1 && this.familia[i].items[x].id_produto == codProdComEmbalagem) {
            this.familia[i].valor = this.familia[i].items[x].valor_atributo;
            console.log("Valor da familia")
            console.log(this.familia[i].valor);
            this.familiaSelecionada = this.familia[i].items[x].valor_atributo;
            // this.slideFamilia.slideTo(parseInt(i));
          } else {
            this.familia[i].valor = '';
          }

        }

      }

      // console.log(this.familia);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  showFamilia(codProdEmb, codProd) {
    this.exibeFamilia = false;
    this.getFamilia(codProdEmb, codProd);
  }

  closebuttom() {
    this.exibeFamilia = true;
  }

  toggleSection(x: any, y: any) {
    // console.log(this.familia[x].items[y].id_produto);
    // console.log(this.slideFamilia)
    // this.familia[x].valor = this.familia[x].items[y].valor_atributo;
    // console.log("Selecionado antigo")
    // console.log(this.familia[x].items[y])
    // console.log("Selecionado Novo")
    // console.log(this.familiaSelecionada)
    // this.getProdutoPorDescricao2(this.familia[x].items[y].id_produto, y);

    // console.log("Familia anterior")
    // console.log(this.slideFamilia.getPreviousIndex())
    // console.log("Familia Nova")
    // console.log(this.slideFamilia.getActiveIndex())

    console.log("Index AQUI")
    console.log(y)

    this.getProdutoPorDescricao2(this.familia[x].items[y].id_produto, y)
    // this.familia[x].valor = this.familia[x].items[y].valor_atributo;
  }

  async getProdutoPorDescricao2(codProduto: any, y: any) {
    try {
      this.itemFamilia = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'list/'
        + localStorage.getItem('empresa')
        + '?filter=' + codProduto)

      this.item = this.itemFamilia.content[0];

      Promise.all([this.getFamilia2(codProduto, this.item.cod_produto, y), this.getListImage(this.item.codigo)]);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  async getFamilia2(codProdComEmbalagem: string, codProduto: string, y: any) {
    try {
      // this.familia = await this.httpUtilProvider.get(API_URL + ENV.WS_PRODUTO + 'familia/'
      //   + localStorage.getItem('empresa') + '/' + codProdComEmbalagem);

      // console.log('this.familia');
      // console.log(this.familia);

      for (var i in this.familia) {
        for (var x in this.familia[i].items) {
          this.familia[i].qtdItems = x + 1;
          // console.log(codProduto +' - '+ this.familia[i].items[x].id_produto);

          if (this.familia[i].items[x].selected == 1 && this.familia[i].items[x].id_produto == codProdComEmbalagem) {
            this.familia[i].valor = this.familia[i].items[x].valor_atributo;
            console.log("Valor da familia2")
            console.log(this.familia[i].valor);
            this.familiaSelecionada = this.familia[i].items[x].valor_atributo;
          } else {
            console.log("Valor da familia2")
            console.log(this.familia[i].valor);
            this.familia[i].valor = '';
          }
        }
      }

      console.log(y);
      setTimeout(() => {
        if (y > 0) {
          this.slideFamilia.slideTo(y + 1)
        } else {
          this.slideFamilia.slideTo(y)
        }
      }, 2500);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }


  // by Ryuge 18/09/2018 
  async getListImage(cod: string) {

    try {

      this.images = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'listImages/' + cod + '/1');
      this.exibeSlidePages = (this.images.length == 1);

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }

  // by Ryuge 18/09/2018 
  async getAllListImage(cod: string) {

    try {
      this.imagesAll = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'listImages/' + cod);
      this.navCtrl.push("ProdutoImagens", { item: this.items, images: this.imagesAll })
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }



  // postPedidoNovo() {
  //   return new Promise((resolve, reject) => {
  //     let headers = new Headers();
  //     headers.append('X-Auth-Token', localStorage.getItem('token'));

  //     this._http.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/' + localStorage.getItem('empresa') + '/criar', {}, { headers: headers })
  //       .subscribe(res => {
  //         // this.pedido = res.json();
  //         // this.commonServices.numPedido = this.pedido.id;

  //         this.commonServices.pedidoHeader = res.json();
  //         this.commonServices.numPedido = this.commonServices.pedidoHeader.id;
  //         // console.log(this.commonServices.numPedido)

  //       }, (err) => {
  //         reject(err);
  //       });
  //   });
  // }


  itemTapped(event, item) {

    console.log(item)
    try {
      // by Ryuge 02/10/2019
      this.navCtrl.push("PedidoAdicionarSacola", {
        item: item, headerPedido: this.commonServices.pedidoHeader, type: 'N', mode: 2, deposito: this.estqDeposito, tipoSele: false
      })
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  };

  async getCondicaoPagamento(idProduto) {

    try {
      this.condicao = await this.httpUtilProvider.get(ENV.WS_VENDAS + API_URL +
        'condicaoPagto/list/' + localStorage.getItem('empresa') + '?produto=' + idProduto);
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  listaImagens(event, item) {
    this.navCtrl.push("ProdutoImagens", {
      item: item
    });
  };

  ionViewWillEnter() {

    this.goToFullScreen();

    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);

    this.getInfomationProduct(this.item.codigodigitoembalagem)

  }

  ionViewDidEnter() {

    try {

      // this.commonServices.showLoader();

      this.menu.swipeEnable(false);
      this.headerPedido = this.navParams.get('headerPedido');
      this.getCaracteristica(this.item.codigodigitoembalagem);
      // this.getCondicaoPagamento(this.item.cod_produto);
      // this.commonServices.loading.dismiss();

      this.existEstoque = this.item.estoque > 0;
      if (this.commonServices.tipoRetirada == "ENTREGA") {
        this.existEstoque = true;
      }

      // let valor = this.item.formaParcelamento;

      this.existBasket = this.commonServices.qtdBasketItens > 0;
      this.qtdItem = this.commonServices.qtdBasketItens;


    } catch (error) {
      this.commonServices.loading.dismiss();
      this.commonServices.showToast(error.json().detail);
    }
  }


  //   information(){
  //     this.navCtrl.push(Information)
  //   }
  //   comparePage(){
  //     this.navCtrl.push(compre_Junto_Page)
  //   }
  //   similarPage(){
  //     this.navCtrl.push(Similar_Page)
  //   }

  openParcelas(item) {
    this.navCtrl.push("Parcelas", { item: item });
  }


  searchProduct() {
    this.commonServices.exibeBotaoComprar = true;
    this.navCtrl.push("ProdutoLista", { mode: 3 });
  }


  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {

      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }

  finalizarPedido() {


    // let itPedido;
    // if(this.commonServices.sistuacaoPedido == 'A'){
    //   itPedido = this.commonServices.itemPedidoAberto.content;
    // }else{
    //   itPedido = this.commonServices.itemPedidoFinalizado.content;
    // }

    // this.commonServices.numPedido = itPedido[0].numpedido;

    let itPedido;
    let idxPedido;

    if (this.commonServices.sistuacaoPedido == 'A') {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    if (itPedido != {}) {
      this.navCtrl.push("PedidoSacola", {
        item: itPedido[idxPedido], mode: 1
      });
    };

  };

  showCardClient() {
    this.navCtrl.push("CartaoPedido", { back: 'ProdutoDetalhe', item: this.item, mode: this.mode });
  }

  showclient() {
    this.navCtrl.push("Cliente", { back: "PedidoSacola", finalizar: false });
  }

  presentSizeModal() {
    let sizeModal = this.modalCtrl.create(TamanhoModal, { cssClass: "test" });
    sizeModal.present();
  }

  informacaoProduto(item) {
    this.navCtrl.push("ProdutoInformacao", {
      item: item
    });
  };

  getColor(color) {
    this.ionicColor = color;
    return true;
  }

  exibeItemSelecionado(x, y) {
    this.itemSelecionado = this.familia[x].items[y].valor_atributo;
  }


  showDisplay(e: any) {
    var x = document.getElementById("DivWall");
    var y = document.getElementById("DivFilter");

    // console.log(e.target.tagName);

    if (e.target.tagName == 'DIV') {

      if (x.style.display === "none") {
        x.style.display = "block";
      } else {
        x.style.display = "none";
      }

      if (y.style.display === "none") {
        y.style.display = "block";
      } else {
        y.style.display = "none";
      }

      this.exibeFamilia = !this.exibeFamilia;
    }
  }

  // by Helio
  async getInfomationProduct(codProduto) {

    try {
      let dados: any = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'detalhe/' + codProduto);
      if (dados.items.length > 0) {
        console.log("TRU DA TRU")
        console.log(dados)
        this.showMaisInfo = true;
      }

    } catch (error) {
      this.showMaisInfo = false;
    }

  }





  // by Helio 04/03/2020
  async getOpcoesTMS(cep: string, qtd: string) {
    if (cep.length > 5) {
      this.spinnerShow = true;
      const link = ENV.WS_TMS + API_URL +
        "tms/opcoesfrete/" + localStorage.getItem("empresa") +
        "/" + this.item.codigodigitoembalagem +
        "?qtd=" + qtd.toString() +
        "&cep=" + cep +
        "&precolocal=N" +
        "&pedido=" + this.commonServices.numPedido;;

      console.log("LINK");
      console.log(link);

      try {
        await this.httpUtilProvider.getTMS(link).then((result: any) => {
          this.consultaFreteOpcs = result;
          this.spinnerShow = false;
          setTimeout(() => {
            this.CEP.setBlur();
          }, 150);
        });
        console.log("opcoes entrega");
        console.log(this.consultaFreteOpcs);

      }
      catch (error) {
        this.spinnerShow = false;
        setTimeout(() => {
          this.CEP.setBlur();
        }, 150);
        if (error.detail) {
          this.commonServices.showAlert3('Atenção', error.detail);
        }
        else {
          this.commonServices.showAlert3(error.error, error.message);
        }
      }
    }
  }

  // by Helio
  addQtd() {
    if (this.item.qtdMinima != 0) {
      this.qtdConsulta++;
      this.qtdConsulta = Math.ceil(this.qtdConsulta / this.item.qtdMinima) * this.item.qtdMinima;
    }
    else {
      this.qtdConsulta++;
    }
  }
  rmQtd() {
    if (this.item.qtdMinima != 0) {
      this.qtdConsulta = this.qtdConsulta - this.item.qtdMinima;
    }
    else {
      if (this.qtdConsulta > 1) {
        this.qtdConsulta--;
      }
    }
  }

  // by Helio 07/03/2020
  scrollNow(className: string) {
    setTimeout(() => {
      let yOffset: any = document.getElementsByClassName(className);
      console.log(yOffset)
      this.content.scrollTo(0, yOffset[yOffset.length - 1].offsetTop, 500);
    }, 100);
  }

  // by Helio 09/03/2020
  setFocus(id: string) {
    switch (id) {
      case 'CEP':
        setTimeout(() => {
          this.CEP.setFocus();
        }, 150);
        break;

      default:
        break;
    }
  }



}
