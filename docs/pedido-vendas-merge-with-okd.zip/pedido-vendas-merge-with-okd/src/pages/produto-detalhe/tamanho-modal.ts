import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, ModalController, NavController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'tamanho-modal',
  templateUrl: 'tamanho-modal.html',

})

export class TamanhoModal {
  categoryOption = [
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},

  ]
  categoryOptionSecond = [
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},
    {id:"1",title1:"43",title2:"R$ 1.899,00",title3:"24 unid",status:false},

  ]
  constructor(
    public navCtrl: NavController , 
    public translateService: TranslateService , 
    public modalCtrl: ModalController) {
  }

  closeSizeModal(){
    this.navCtrl.pop();
  }

  selectCategory(index){
    if(!this.categoryOption[index].status){
      for (var v in this.categoryOption)
        {
          this.categoryOption[v].status = false;
        }
    }
     this.categoryOption[index].status = !this.categoryOption[index].status;


  }
  selectCategorySecond(index){
    if(!this.categoryOptionSecond[index].status){
      for (var v in this.categoryOptionSecond)
        {
          this.categoryOptionSecond[v].status = false;
        }
    }
     this.categoryOptionSecond[index].status = !this.categoryOptionSecond[index].status;


  }


  
}
