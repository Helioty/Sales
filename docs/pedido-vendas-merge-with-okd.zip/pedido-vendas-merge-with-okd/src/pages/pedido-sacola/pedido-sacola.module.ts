import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PedidoSacola } from './pedido-sacola';

import { TranslateModule } from '@ngx-translate/core';
import { HideKeyboardModule } from 'hide-keyboard';
import { LongPressModule } from 'ionic-long-press';
import { IonicSwipeAllModule } from 'ionic-swipe-all';

import { DirectivesModule } from '../../directives/directives.module';
import { PipesModule } from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    PedidoSacola,
  ],
  imports: [
    IonicPageModule.forChild(PedidoSacola),
    PipesModule, DirectivesModule, TranslateModule,
    IonicSwipeAllModule, LongPressModule,
    HideKeyboardModule
  ],
})
export class PedidoSacolaModule {}
