import { Component, HostListener, ViewChild } from '@angular/core';
// import { Http } from '@angular/http';
import { ENV } from '@app/env';
import { AndroidFullScreen } from '@ionic-native/android-full-screen';
import { AlertController, Content, IonicPage, Keyboard, MenuController, NavController, NavParams, Platform } from 'ionic-angular';
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";
import { PedidoTable } from "../../class/class.pedido";
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "../../providers/http-util/http-util";
import { CommonServices } from "../../services/common-services";


/**
 * Generated class for the PedidoSacola page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-pedido-sacola',
  templateUrl: 'pedido-sacola.html',
})
export class PedidoSacola {
  public showInfo: boolean = false;
  public totalPages: number = 0;

  items: any;
  itdeleted: any;
  pedidoCab: any;
  itemsacola: any;

  public selectedItem: any;
  isUpdatedTipoRetirada: boolean = false;

  existeFrete: boolean = false;
  existClient: boolean = false;
  cardClient: boolean = false;
  isEnabled: boolean = true;

  modePageReturn: any = 0;

  public isBack: boolean = false;
  public exibeTotal: boolean = false;


  public totalPedido: any;
  public descontoBrinde: any;
  public existeDescontoBrinde: boolean = false;
  public tipoEntrega: any;
  public valorFrete = 0;
  public valorTotalItem = 0;
  public pesoTotal: any;


  public skeletonLoading: boolean = false;
  clienteSelected: boolean = false;
  private execute: boolean = true;


  public finalizar: boolean = false;
  public noCard: boolean;


  public inFocus: boolean = true;
  private idScanner;
  private taskScanner;
  subscription: Subscription;

  @ViewChild("scanner") scanned: any;
  @ViewChild(Content) content: Content;   // by ryuge 19/10/2018	


  // by Helio 11/12/2019
  public existeProdutoParaEntrega: boolean = false;
  public existeProdutoParaRetirada: boolean = false;
  public existeProdutoParaRetiradaDeposito: boolean = false;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private platform: Platform,
    private menu: MenuController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    private alertCtrl: AlertController,
    public Keyb: Keyboard,
    // public ngZone: NgZone,
    private androidFullScreen: AndroidFullScreen,
    // public http: Http
  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);


    this.selectedItem = this.navParams.get("item");
    this.tipoEntrega = this.commonServices.tipoRetirada;
    this.modePageReturn = this.navParams.get("mode");
    this.isBack = this.navParams.get("finalizar");


    // COMENTADO - Não está sendo informadoo valor do frete
    this.existeFrete = false;
    if (this.commonServices.tipoRetirada == "ENTREGA") {
      this.existeFrete = true;
      this.valorFrete = this.commonServices.valorFrete;

      // if(this.selectedItem != undefined){
      //   this.valorFrete = this.selectedItem.frete.valor;
      // }
    }

    this.noCard = this.navParams.get("noCard");

    if (this.finalizar) {
      this.selectedItem = this.commonServices.ItensPedidoAdd;
      this.finalizarPedido();
    }

    console.log('DADOS DO CLIENTE');
    console.log(this.commonServices.dadosCliente);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PedidoSacola');
    console.log('DADOS DO CLIENTE');
    console.log(this.commonServices.docCliente);
    console.log(this.commonServices.dadosCliente);

    this.selectedItem = this.navParams.get("item");
    console.log('ionViewDidEnter');
    console.log(this.selectedItem);
    this.refreshItem();
  }

  //Alterado por Nicollas Bastos em 25-09-2018
  ionViewDidEnter() {
    this.goToFullScreen();
    this.menu.swipeEnable(false);
    // this.selectedItem = this.navParams.get("item");
    // console.log('ionViewDidEnter');
    // console.log(this.selectedItem);
    // this.refreshItem();
  }

  ionViewWillEnter() {
    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      this.retornarPagina();
    }, 1);
    this.existClient = this.commonServices.clientSelected;
    this.cardClient = this.commonServices.cardSelected;
    if (this.platform.is("ios") || this.platform.is("android")) {
      this.focusOn();
    }

    // by Helio 05/03/2020
    // setTimeout(() => {
    //   this.httpUtilProvider.getNoAlert(ENV.WS_CRM + API_URL + "cliente/" + this.commonServices.docCliente).then((resu) => {
    //     this.commonServices.dadosCliente = resu;
    //     console.log("DADOS DO CLIENTEEEEEEEE");
    //     console.log(this.commonServices.dadosCliente)
    //   });
    // }, 100);
  }



  goToFullScreen() {
    this.androidFullScreen.isImmersiveModeSupported()
      .then(() => this.androidFullScreen.immersiveMode())
      .catch((error: any) => console.log(error));
  }

  ngOnInit() {
    this.subscription = Observable.fromEvent(document, "keypress").subscribe(
      (e: KeyboardEvent) => {
        if (e.keyCode != 13) {
          this.idScanner += e.key;
        } else {
          this.inFocus = true;
          if (this.platform.is("ios") || this.platform.is("android")) {
            this.focusOn();
          }
        }
      }
    );
  }

  @HostListener("window:keyup", ["$event"])
  keyEvent(event: KeyboardEvent) {
    if (event.keyCode != 13) {
      this.idScanner += event.key;
    } else {
      this.inFocus = true;
      if (this.platform.is("ios") || this.platform.is("android")) {
        this.focusOn();
      }
    }
  }

  focusOn() {
    this.taskScanner = setInterval(() => {
      this.scanned.value = "";
      this.scanned.setFocus();
    }, 1000);
  }
  closeKeyboard() {
    setTimeout(() => {
      clearInterval(this.taskScanner);
      this.Keyb.close();
    }, 500);
  }



  // by Ryuge 18/12/2018
  async atualizaPedido() {
    try {
      // this.ngZone.run(() => {
      this.skeletonLoading = true;
      // });
      this.commonServices.showLoader(); // by Helio 04/03/2020

      let aResult = [];
      let table: PedidoTable = new PedidoTable();
      table.name = "entrega";
      table.value = this.commonServices.tipoRetirada;
      aResult.push(table);

      let result: any = await this.httpUtilProvider.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      ).then(() => {
        // by Helio 04/03/2020
        this.commonServices.loading.dismiss();
        if (this.existClient) {
          this.navCtrl.push("NovaEntrega", { item: this.commonServices.ItensPedidoAdd, modulo: 5 });
        } else {
          this.navCtrl.push("Cliente", { back: "PedidoSacola", pedido: this.commonServices.pedidoHeader, finalizar: false, pedidoEntrega: true });
        }
      }, error => {
        // by Helio 04/03/2020
        this.commonServices.loading.dismiss();
      });

      console.log('atualizaPedido');
      console.log(result);
      // this.commonServices.pedidoHeader = result;
      this.commonServices.ItensPedidoAdd = result;
      // if (this.commonServices.tipoRetirada == "ENTREGA") {
      //   if (
      //     (this.commonServices.docCliente == "" &&
      //       this.commonServices.nomeCliente == "") ||
      //     this.commonServices.nomeCliente == "Não Identificado"
      //   ) {
      //     this.navCtrl.push("Cliente", { back: "PedidoSacola", finalizar: false }, { animate: false });
      //   } else {
      //     this.navCtrl.push("EntregaFrete", {
      //       item: this.commonServices.pedidoHeader, modulo: 2
      //     });
      //   }
      // }    
    } catch (error) {
      // this.ngZone.run(() => {
      this.skeletonLoading = false;
      // });
      console.log(error);
    }
    // this.ngZone.run(() => {
    this.skeletonLoading = false;
    // });
  }


  //Alterado por Nicollas Bastos em 25/09/2018
  setCardPedido(codCard: any) {
    this.commonServices.codigoCartaoPedido = codCard;

    let aResult = [];
    let table: PedidoTable = new PedidoTable();
    table.name = "cartao_pedido";
    table.value = this.commonServices.codigoCartaoPedido;
    aResult.push(table);

    this.httpUtilProvider
      .post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/update/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido,
        aResult
      )
      .then(data => {
        this.commonServices.dadosCliente = data;
        this.commonServices.cardSelected =
          this.commonServices.codigoCartaoPedido != "";

        if (this.commonServices.dadosCliente.cgccpf_cliente != null && this.commonServices.dadosCliente.cgccpf_cliente.trim().length > 0) {
          this.commonServices.clientSelected = true;
          this.existClient = this.commonServices.clientSelected;
          this.commonServices.docCliente = this.commonServices.dadosCliente.cgccpf_cliente;
          this.commonServices.nomeCliente = this.commonServices.dadosCliente.nome_cliente;
        } else {
          this.commonServices.clientSelected = false;
          this.commonServices.docCliente = "";
          this.commonServices.nomeCliente = "";
        }

        // this.atualizaPedido();
        this.commonServices.cardSelected = true;
        this.cardClient = this.commonServices.cardSelected;
      })
      .catch(error => {
        this.cardClient = false;
        this.commonServices.cardSelected = false;
        this.commonServices.codigoCartaoPedido = "";
      });
  }


  async getCard(event: any) {
    if (event.target && event.target.value.length >= 2) {
      let codigo: string = event.target.value;

      if (codigo.substring(0, 1) == "P") {
        this.setCardPedido(codigo);
      }
    }
  }


  //chama o cliente
  showclient() {
    this.navCtrl.push("Cliente", { back: "PedidoSacola", finalizar: false });
  }


  async refreshItem() {
    // this.commonServices.showLoader();
    try {
      // cabeçalho do pedido
      this.httpUtilProvider
        .getPedido(this.commonServices.numPedido)
        .then(result => {
          console.log("TOTAL PEDIDO");
          console.log(result);
          this.commonServices.ItensPedidoAdd = result;
          console.log(this.commonServices.ItensPedidoAdd)
          this.descontoBrinde = result.descontoBrinde;
          if (result.descontoBrinde > 0) {
            this.existeDescontoBrinde = true;
          } else {
            this.existeDescontoBrinde = false;
          }
          this.valorTotalItem = result.totpedido - result.frete.valor + result.descontoBrinde;
          this.totalPedido = result.totpedido;
          this.pesoTotal = result.pesoTotal;
          this.exibeTotal = result.totpedido > 0;

          // atualiza cesta de compras
          this.commonServices.qtdBasketItens = result.totalElements;

          // by Helio 11/02/2020
          if (result.cgccpf_cliente && result.cgccpf_cliente != null) {
            // console.log("cliente nao null");
            this.httpUtilProvider.getNoAlert(ENV.WS_CRM + API_URL + "cliente/" + result.cgccpf_cliente).then((resu) => {
              this.commonServices.dadosCliente = resu;
            });
          }
        });

      this.items = await this.httpUtilProvider.get(
        ENV.WS_VENDAS + API_URL +
        "PedidoVendaItem/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido +
        "/itens"
      );
      this.totalPages = this.items.numberOfElements;
      this.items = this.items.content;
      console.log("ANTES DE INICIAR O FOR")
      for (let i = 0; i < this.items.length; i++) {
        console.log("INICIOU O FOR")
        if (this.items[i].retiradas[0].tipoRetirada == 9997) {
          console.log("tem entrega no item " + i + "?")
          this.existeProdutoParaEntrega = true
        }
        else if (this.items[i].retiradas[0].tipoRetirada != 9997) {
          console.log("tem retirada no item " + i + "?")
          this.existeProdutoParaRetirada = true
        }
      }
      console.log("REFRESH ITEMS");
      console.log(this.items);
      // by Ryuge 08/01/2019
      this.isEnabled = this.totalPages > 0;

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }


  async deleteItemPedido(codProduto: any) {
    try {
      this.itdeleted = await this.httpUtilProvider.post(
        ENV.WS_VENDAS + API_URL +
        "PedidoVendaItem/" +
        localStorage.getItem("empresa") +
        "/" +
        this.commonServices.numPedido +
        "/" +
        codProduto,
        {}
      );

      this.refreshItem();
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }

  showCardClient() {
    this.navCtrl.push("CartaoPedido", { back: "PedidoSacola" });
  }

  presentConfirm(item: any) {
    let alert = this.alertCtrl.create({
      title: "Remover produto",
      message:
        "Tem certeza que deseja remover o produto " +
        item.descricao +
        " do pedido?",
      buttons: [
        {
          text: "Cancelar",
          role: "cancel",
          handler: () => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Remover",
          handler: () => {
            this.deleteItemPedido(item.idProduto);
            this.removeItemList(item);
            // console.log('confirmed clicked');
          }
        }
      ]
    });
    alert.present();
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }


  editTipoEntrega() {
    let alert = this.alertCtrl.create();
    if (this.tipoEntrega == "ENTREGA") {
      alert.setTitle("Ação não permitida!");
      alert.setMessage("Finalize o pedido antes de fazer a manutenção novamente.");
      alert.addButton("OK");
    }
    else {
      alert.setTitle("Alterar tipo de retirada");
      alert.addInput({
        type: "radio",
        label: "Imediata ",
        value: "0",
        checked: this.tipoEntrega == "IMEDIATA" ? true : false
      });
      alert.addInput({
        type: "radio",
        label: "Posterior",
        value: "1",
        checked: this.tipoEntrega == "POSTERIOR" ? true : false
      });
      alert.addInput({
        type: "radio",
        label: "Entrega",
        value: "2",
        checked: this.tipoEntrega == "ENTREGA" ? true : false
      });
      alert.addButton({
        text: "Cancelar",
        handler: (data: any) => {
          this.isUpdatedTipoRetirada = false; // by Ryuge 08/01/2019 
        }
      });
      alert.addButton({
        text: "Alterar",
        handler: (data: any) => {
          this.isUpdatedTipoRetirada = true; // by Ryuge 08/01/2019 - Alterado o tipo de retirada
          this.openProductListingPage(data);
        }
      });
    }
    alert.present();
  }


  openProductListingPage(retirada: any) {
    if (retirada != this.commonServices.codigoTipoRetirada) {
      let aResult = [];
      let table: PedidoTable = new PedidoTable();
      table.name = "entrega";
      table.value = this.commonServices.opcaoRetirada[retirada];
      aResult.push(table);

      // comentado por Ryuge 26/12/2018
      // this.httpUtilProvider.atualizaPedido(
      //   this.commonServices.numPedido,
      //   aResult
      // );

      this.commonServices.codigoTipoRetirada = retirada;
      this.commonServices.tipoRetirada = this.commonServices.opcaoRetirada[
        retirada
      ];
      this.tipoEntrega = this.commonServices.opcaoRetirada[retirada];

      if (this.commonServices.tipoRetirada == "ENTREGA") {
        this.existeFrete = true;
        this.valorFrete = this.commonServices.valorFrete;
        // 
      } else {
        this.existeFrete = false;
      }
      // atualiza objeto pedidoAtualizado
      this.commonServices.pedidoAtualizado.entrega = this.commonServices.tipoRetirada;
      this.commonServices.exibeBotaoComprar = true;

      // by Ryuge 26/12/2018
      this.atualizaPedido();
    }
  }


  //adicionar produtos
  addProduto() {
    this.commonServices.exibeBotaoComprar = true;
    this.navCtrl.push("ProdutoLista", { mode: 3 });
  }

  //chama o pedido adiciona sacola
  async getItemPedido(cod: string) {
    try {
      // cabeçalho do pedido
      this.httpUtilProvider
        .getPedido(this.commonServices.numPedido)
        .then(result => {
          this.pedidoCab = result;
        });
      this.itemsacola = await this.httpUtilProvider.get(
        ENV.WS_PRODUTO + API_URL +
        "list/" +
        localStorage.getItem("empresa") +
        "?filter=" +
        cod
      );
      this.itemsacola = this.itemsacola.content;
      // console.log(this.itemsacola[0]);

      this.execute = true;

      this.navCtrl.push("PedidoAdicionarSacola", {
        item: this.itemsacola[0],
        headerPedido: this.pedidoCab,
        type: "M",
        mode: 2
      });
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }
  //editar item da sacola
  editItem(item: any) {
    if (this.execute) {
      try {
        this.execute = false;
        this.getItemPedido(item.idProduto);
      } catch (error) {
        this.commonServices.showToast(error.json().detail);
      }
    }
  }

  removeItemList(item: any) {

    for (let i = 0; i < this.items.length; i++) {
      if (this.items[i] == item) {
        this.items.splice(i, 1);
      }
    }

    // by Ryuge 08/01/2019
    this.isEnabled = this.items.length > 0;

    if (this.items.length == 0) {
      this.navCtrl.push("ProdutoLista");
    }

    // if (this.items.length == 0) {
    //   this.navCtrl.pop();
    //   this.navCtrl.setRoot("PedidoLista");
    // this.navCtrl.push("PedidoLista") ;
    // }
  }




  //Alterado por Nicollas Bastos em 25-09-2018
  // Controla para qual tela retornar
  retornarPagina() {
    switch (this.modePageReturn) {
      case 1:
        this.navCtrl.pop();
        break;
      case 2:
        this.ExitConfirm();
        break;
      case 4:
        // by Ryuge 29/11/2018
        if (!this.isUpdatedTipoRetirada) {
          this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.ItensPedidoAdd, modulo: 1 })
        } else {
          this.finalizarPedido();
        }
        break;

      default:
        this.navCtrl.push("ProdutoLista");
        break;
    }
  }

  ExitConfirm() {
    // comentado por Ryuge 02/10/2018 - Correçã para evitar apagar pedido com item na cesta
    let mensagem = this.commonServices.qtdBasketItens == 0
      ? "Pedidos sem itens serão removidos permanentemente!"
      : "";
    let alert = this.alertCtrl.create({
      title: "Deseja realmente sair do pedido?",
      message: mensagem,
      buttons: [
        {
          text: "Não",
          role: "cancel",
          handler: () => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Sim",
          handler: () => {
            if (this.commonServices.qtdBasketItens == 0) {
              this.RemoveOrder(this.commonServices.numPedido);
            } else {
              this.navCtrl.pop();
            }
          }
        }
      ]
    });
    alert.present();
  }

  async RemoveOrder(PedidoId: any) {
    try {
      await this.httpUtilProvider.delete(
        ENV.WS_VENDAS + API_URL +
        "PedidoVenda/" +
        localStorage.getItem("empresa") +
        "/" +
        PedidoId
      );
      this.navCtrl.pop();
    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }
  }










  //finalização do pedido
  async finalizarPedido() {

    // by Ryuge 08/10/2019
    if (
      this.commonServices.ItensPedidoAdd != undefined ||
      this.selectedItem == undefined
    ) {
      // by Ryuge 08/10/2019
      this.selectedItem = this.commonServices.ItensPedidoAdd;
      console.log("finalizarPedido");
      console.log(this.selectedItem);
    }

    // console.log("FINALIZAÇÃO")
    // console.log(this.modePageReturn);
    // by Ryuge 29/11/2018
    if (this.modePageReturn == 4) {
      // by Lucas 09/01/2019
      if (this.commonServices.ItensPedidoAdd.tipodoc != this.commonServices.pedidoHeader.tipodoc) {
        // by Ryuge 09/01/2019
        if (this.commonServices.tipoRetirada == "ENTREGA") {
          let tms = localStorage.getItem("tms");
          console.log('FINALIZAÇÃO');
          console.log(tms);
          if (tms == 'true') {
            let enderecos = this.commonServices.dadosCliente.enderecos;
            let sequen = this.commonServices.pedidoAtualizado.seq_endereco_entrega;
            let enderecoSelecionado = await this.getSequencial(sequen, enderecos)
            console.log('enderecoSelecionado');
            console.log(enderecoSelecionado);
            if (enderecoSelecionado.id.sequencialId == undefined) {
              this.navCtrl.push("NovaEntrega", {
                item: this.selectedItem, modulo: 2
              });
            } else {
              this.navCtrl.push("EntregaTransportadoraPage", { endereco: enderecoSelecionado })
            }

          } else {
            this.navCtrl.push("EntregaFrete", {
              item: this.selectedItem, modulo: 2
            });
          }
        } else {
          this.navCtrl.push("FormasPagamento", {
            item: this.selectedItem
          });
        }
      } else {
        // by Ryuge 09/01/2019
        if (
          this.selectedItem.informarCliente == "S" ||
          this.commonServices.tipoRetirada == "ENTREGA"
        ) {
          if (
            ((this.commonServices.docCliente == "" &&
              this.commonServices.nomeCliente == "") ||
              this.commonServices.nomeCliente == "Não Identificado")
          ) {
            this.navCtrl.push("Cliente", { back: "PedidoSacola", finalizar: true }, { animate: false });
          } else {
            // by Ryuge 08/01/2019 - Alterado o tipo de retirada
            if (this.isUpdatedTipoRetirada) {
              if (this.commonServices.tipoRetirada == "ENTREGA") {
                // this.navCtrl.push("EntregaFrete", {
                //   item: this.selectedItem, modulo: 2
                // });
                let tms = localStorage.getItem("tms");
                console.log('FINALIZAÇÃO');
                console.log(tms);
                if (tms == 'true') {

                  let enderecos = this.commonServices.dadosCliente.enderecos;
                  let sequen = this.commonServices.pedidoAtualizado.seq_endereco_entrega;
                  let enderecoSelecionado = await this.getSequencial(sequen, enderecos)
                  console.log('enderecoSelecionado');
                  console.log(enderecoSelecionado);
                  if (enderecoSelecionado.id.sequencialId == undefined) {
                    this.navCtrl.push("NovaEntrega", {
                      item: this.selectedItem, modulo: 2
                    });
                  } else {
                    this.navCtrl.push("EntregaTransportadoraPage", { endereco: enderecoSelecionado })
                  }
                } else {
                  this.navCtrl.push("EntregaFrete", {
                    item: this.selectedItem, modulo: 2
                  });
                }
              } else {
                if (this.commonServices.ItensPedidoAdd.tipodoc != this.commonServices.pedidoHeader.tipodoc) {
                  this.navCtrl.push("FormasPagamento", {
                    item: this.selectedItem
                  });
                } else {
                  this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.ItensPedidoAdd, modulo: 1 });
                }
              }
            } else {
              this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.ItensPedidoAdd, modulo: 1 });
            }
          }
        } else {
          this.navCtrl.push("PedidoFinalizacao", { pedido: this.commonServices.ItensPedidoAdd, modulo: 1 });
        }
      }
    } else {
      // if (
      //   this.commonServices.ItensPedidoAdd != undefined ||
      //   this.selectedItem == undefined
      // ) {
      //   // by Ryuge 08/10/2019
      //   this.selectedItem = this.commonServices.ItensPedidoAdd;
      //   console.log("finalizarPedido");
      //   console.log(this.selectedItem);
      // }

      if (
        this.selectedItem.informarCliente == "S" ||
        this.commonServices.tipoRetirada == "ENTREGA"
      ) {
        if (
          ((this.commonServices.docCliente == "" &&
            this.commonServices.nomeCliente == "") ||
            this.commonServices.nomeCliente == "Não Identificado")
        ) {
          this.navCtrl.push("Cliente", { back: "PedidoSacola", finalizar: true }, { animate: false });
        } else {
          if (this.commonServices.tipoRetirada == "ENTREGA") {
            // this.navCtrl.push("EntregaFrete", {
            //   item: this.selectedItem, modulo: 2
            // });
            let tms = localStorage.getItem("tms");
            console.log('FINALIZAÇÃO');
            console.log(tms);
            if (tms == 'true') {
              let enderecos = this.commonServices.dadosCliente.enderecos;
              let sequen = this.commonServices.pedidoAtualizado.seq_endereco_entrega;
              let enderecoSelecionado = await this.getSequencial(sequen, enderecos)
              console.log('enderecoSelecionado');
              console.log(enderecos);
              console.log(enderecoSelecionado);
              if (enderecoSelecionado.id.sequencialId == undefined) {
                this.navCtrl.push("NovaEntrega", {
                  item: this.selectedItem, modulo: 2
                });
              } else {
                this.navCtrl.push("EntregaTransportadoraPage", { endereco: enderecoSelecionado })
              }

            } else {
              this.navCtrl.push("EntregaFrete", {
                item: this.selectedItem, modulo: 2
              });

            }
          } else {
            this.navCtrl.push("FormasPagamento", {
              item: this.selectedItem
            });
          }
        }
      } else {
        if (!this.commonServices.cardSelected && !this.noCard) {
          this.navCtrl.push("CartaoPedido", {
            back: "PedidoSacola",
            finalizar: true
          });
        } else {
          this.navCtrl.push("FormasPagamento", {
            item: this.selectedItem
          });
        }
      }
    }
  }

  getSequencial(seq: any, endes: any) {
    for (let i = 0; i < endes.length; i++) {
      if (endes[i].id.sequencialId == seq) {
        return endes[i]
      }
    }
  }



  // by Helio
  //sobre as informações do pedido no footer
  closeInfo() {
    if (this.showInfo == true) {
      this.showInfos()
    }
  }
  showInfos() {
    this.showInfo = !this.showInfo;
  }

  // by ryuge 19/10/2018	
  scrollTo(y: number) {
    // set the scrollLeft to 0px, and scrollTop to 500px
    // the scroll duration should take 200ms
    this.content.scrollTo(0, y, 200);
    this.content.resize();
  }

  // by Helio
  scrollToById(id: any) {
    let elemento = document.getElementById(id)
    let cordenadas = elemento.getBoundingClientRect()
    // console.log("AQUI--------------------")
    // console.log(cordenadas)
    this.scrollTo(cordenadas.height)
  }
}
