import { Component, ViewChild } from "@angular/core";
import { ENV } from '@app/env';
import {
  AlertController,
  App, Content, IonicPage,
  Keyboard,
  MenuController,
  NavController,
  NavParams,
  Platform,
  ViewController
} from "ionic-angular";
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
import { PedidoTable } from "./../../class/class.pedido";
// import * as environment from "./../../environments/environment";
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

//class
// import { Cart_Listing } from '../../pages/cart/cart';
// import { Print_Modal } from '../../pages/cart/ordersummaryPrint';

@IonicPage()
@Component({
  selector: "pedido-resumo",
  templateUrl: "pedido-resumo.html"
})
export class PedidoResumo {
  numeroPedido;
  pedidoCab: any;
  pedidoItem;
  item: any;
  dados: any;

  endereco;
  condicao;
  retirada;
  pagamento;
  qtdItens;
  icmsRetido;
  frete;
  total;
  totalPedido;
  descontoBrinde;
  pesoPedido;
  qtdParcela;
  parcela;
  entrada;

  existeDescontoBrinde: boolean = false;
  existeFrete: boolean = false;
  existeEntrada: boolean = false;
  exibeImagem: boolean = false;
  disabled: boolean = false;

  @ViewChild("input")
  search: any;
  @ViewChild(Content)
  content: Content;

  constructor(
    public navCtrl: NavController,
    public commonServices: CommonServices,
    private httpUtilProvider: HttpUtilProvider,
    public navParams: NavParams,
    private menu: MenuController,
    public viewCtrl: ViewController,
    public appCtrl: App,
    private alertCtrl: AlertController,
    public keyboard: Keyboard,
    public platform: Platform,
    // private androidFullScreen: AndroidFullScreen
  ) {

    // by ryuge 27/09/2018
    platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    },1);

    // caso forma de pagamento parcelado
    this.numeroPedido =
      this.commonServices.numPedido + "-" + this.commonServices.digitoPedido;
    this.condicao = navParams.get("condicao");
    this.item = navParams.data.pedido;

    this.dados = navParams.get("dados");

    // caso pagamento a vista
    if (this.condicao) {
      if (this.condicao.tipoDoc == "CC") {
        this.pagamento = this.condicao.descricao;
        this.entrada = this.condicao.valorEntrada;
        this.parcela = this.condicao.valorParcelas;
        this.qtdParcela = this.condicao.qtdParcelas;
        this.existeEntrada = true;
      } else {
        this.pagamento = this.condicao.descricao;
        this.existeEntrada = false;
      }
    }
  }

  // @HostListener('window:keypress', ['$event'])
  // keyEvent(event: KeyboardEvent) {
  //   if(event.keyCode!=13){
  //     this.commonServices.codScanner += event.key;
  //   }
  //   else{
  //     this.commonServices.presentPrompt(this.commonServices.codScanner)
  //   }
  // }

  ionViewWillEnter() {

    // by ryuge 27/09/2018
    this.platform.registerBackButtonAction(() => {
      console.log("backPressed 1");
    },1);

    this.disabled = false;
    this.commonServices.showLoader();

    // cabeçalho do pedido
    this.httpUtilProvider
      .getPedido(this.commonServices.numPedido)
      .then(result => {
        this.pedidoCab = result;

        console.log("pedidoCab");
        console.log(this.pedidoCab);

        this.retirada = this.commonServices.tipoRetirada;
        // this.pagamento = this.pedidoCab.descricao_condpag;
        this.icmsRetido = this.pedidoCab.icmsRetido;
        this.qtdItens = this.pedidoCab.numitens;
        this.frete = this.pedidoCab.frete.valor;
        this.endereco = this.pedidoCab.frete.endereco;
        this.total =
          this.pedidoCab.totpedido -
          this.pedidoCab.frete.valor +
          this.pedidoCab.descontoBrinde;
        this.totalPedido = this.pedidoCab.valorTotalPedido;
        if (this.pedidoCab.descontoBrinde > 0) {
          this.descontoBrinde = this.pedidoCab.descontoBrinde;
          this.existeDescontoBrinde = true;
        }
        this.pesoPedido = this.pedidoCab.pesoTotal;
      });

    // item do pedido
    this.httpUtilProvider
      .getItensPedido(this.commonServices.numPedido)
      .then(result => {
        console.log(result);
        this.pedidoItem = result.content;
      });

    this.existeFrete = false;
    if (this.commonServices.tipoRetirada == "ENTREGA") {
      this.existeFrete = true;
      this.frete = this.commonServices.valorFrete;
    }
    this.content.resize();
    this.commonServices.loading.dismiss();
  }

  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }

    return idx;
  }

  openPedidoSacola() {
    let itPedido;
    let idxPedido;
    if (this.commonServices.sistuacaoPedido == "A") {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    if (itPedido != {}) {
      let listaViews = this.navCtrl.getViews();
      let index: number = null;
      for (let view of listaViews) {
        if (view.id == "PedidoSacola") {
          index = view.index;
        }
      }
      if (index) {
        // this.commonServices.pedidoRetorno = itPedido[idxPedido];
        this.navCtrl.popTo(listaViews[index]);
      } else {
        this.viewCtrl.dismiss({}, null, { animate: false, duration: 0 });
        this.appCtrl.getRootNavs()[0].push("PedidoSacola", {
          item: itPedido[idxPedido],
          mode: 1
        });
      }
    }
  }

  presentPrintModal() {
    let selectedItem: any;
    selectedItem = this.commonServices.ItensPedidoAdd;

    console.log("presentPrintModal");
    console.log(selectedItem);

    if (
      selectedItem.informarCliente == "S" ||
      this.commonServices.tipoRetirada == "ENTREGA"
    ) {
      if (
        (this.commonServices.docCliente == "" &&
          this.commonServices.nomeCliente == "") ||
        this.commonServices.nomeCliente == "Não Identificado"
      ) {
        this.navCtrl.push("Cliente", { back: "PedidoSacola" });
      } else {
        if (!this.commonServices.cardSelected) {
          this.navCtrl.push("CartaoPedido", { back: "PedidoSacola" });
        } else {
          if (this.commonServices.tipoRetirada == "ENTREGA") {
            this.navCtrl.push("EntregaFrete", {
              total: this.totalPedido,
              item: selectedItem
            });
          } else {
            this.finalizaPedido();
          }
        }
      }
    } else {
      if (!this.commonServices.cardSelected) {
        this.navCtrl.push("CartaoPedido", { back: "PedidoSacola" });
      } else {
        this.finalizaPedido();
      }
    }
  }

  ionViewDidLeave() {
    this.menu.swipeEnable(true);
  }

  ionViewDidEnter() {
    this.menu.swipeEnable(false);
    console.log(this.navCtrl.getViews());
  }

  presentAlert(msg) {
    let alert = this.alertCtrl.create({
      title:
        "Pedido: " +
        this.commonServices.numPedido +
        "-" +
        this.commonServices.digitoPedido,
      subTitle: msg,
      buttons: [
        {
          text: "Ok",
          handler: data => {
            let ststusPedido: boolean = true;
            this.navCtrl.setRoot("PedidoLista", { refresh: ststusPedido });
            this.navCtrl.popToRoot(); // by Ryuge 21/11/2019
          }
        }
      ]
    });
    alert.present();
  }

  async finalizaPedido() {
    try {
      let aResult = [];

      if (
        this.commonServices.pedidoAtualizado.entrega != "" &&
        this.commonServices.pedidoAtualizado.entrega != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "entrega";
        table.value = this.commonServices.tipoRetirada;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.tipo_pagamento != "" &&
        this.commonServices.pedidoAtualizado.tipo_pagamento != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "tipo_pagamento";
        table.value = this.commonServices.pedidoAtualizado.tipo_pagamento;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.condicao_pagto != "" &&
        this.commonServices.pedidoAtualizado.condicao_pagto != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "condicao_pagto";
        table.value = this.commonServices.pedidoAtualizado.condicao_pagto;
        aResult.push(table);
      }

      if (
        this.commonServices.pedidoAtualizado.valor_entrada > 0 &&
        this.commonServices.pedidoAtualizado.valor_entrada != undefined
      ) {
        let table: PedidoTable = new PedidoTable();
        table.name = "valorentrada";
        table.value = this.commonServices.pedidoAtualizado.valor_entrada.toString();
        aResult.push(table);
      }

      // let table: PedidoTable = new PedidoTable();
      // table.name = "cartao_pedido";
      // table.value = this.commonServices.codigoCartaoPedido;
      // aResult.push(table);

      console.log("finalizaPedido");
      console.log(aResult);

      await this.httpUtilProvider.atualizaPedido(
        this.commonServices.numPedido,
        aResult
      );

      let status: any = await this.httpUtilProvider.post(
        ENV.WS_VENDAS+API_URL+
          "PedidoVenda/finalize/" +
          localStorage.getItem("empresa") +
          "/" +
          this.commonServices.numPedido,
        {}
      );

      // this.commonServices.showToast(status);
      this.presentAlert(status.msg);
    } catch (error) {
      this.openPedidoSacola();
      // this.commonServices.showToast(status);
    }
  }
}
