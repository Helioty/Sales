import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { PedidoResumo } from './pedido-resumo';
import { PipesModule } from './../../pipes/pipes.module';

import { TranslateModule } from '@ngx-translate/core'; 
// import { EnderecoEntregaModule } from '../endereco-Entrega/endereco-Entrega.module';


@NgModule({
  declarations: [
    PedidoResumo,
  ],
  imports: [
    IonicPageModule.forChild(PedidoResumo),
    PipesModule,TranslateModule
    // ,EnderecoEntregaModule
  ],
  exports: [
    PedidoResumo
  ]
})
export class  PedidoResumoModule {}