import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EntregaTransportadoraPage } from './entrega-transportadora';

import { PipesModule } from './../../pipes/pipes.module';

@NgModule({
  declarations: [
    EntregaTransportadoraPage,
  ],
  imports: [
    IonicPageModule.forChild(EntregaTransportadoraPage),
    PipesModule,
  ],
})
export class EntregaTransportadoraPageModule {}
