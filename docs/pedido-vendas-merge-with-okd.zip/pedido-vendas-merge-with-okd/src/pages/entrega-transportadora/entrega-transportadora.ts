import { Component } from '@angular/core';
import { ENV } from '@app/env';
import { AlertController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { API_URL } from '../../config/app.config';
import { HttpUtilProvider } from "./../../providers/http-util/http-util";
import { CommonServices } from "./../../services/common-services";

/**
 * Generated class for the EntregaTransportadoraPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-entrega-transportadora',
  templateUrl: 'entrega-transportadora.html',
})
export class EntregaTransportadoraPage {

  public carregando: boolean = false;
  public naoEntregues: boolean = false;
  public zeroItensParaEntrega: boolean = false;

  public showProdutos: boolean = false;
  public selecionado: boolean = false;
  public retiraLoja: boolean = false;
  public outraPessoaBusca: boolean = false;
  public ultimoPacote: boolean = false;

  //informações para retirada em loja por outra pessoa
  public outraPessoaNomeRetirada: any;
  public outraPessoaCPFRetirada: any;
  public outraPessoaEmailRetirada: any;

  // by Ryuge 02/10/2019
  public modePageReturn: any = -1;



  //itens deletados em caso de não poderem ser entregues
  public produtosNaoEntregues: any = [];
  public itensDeletados: any = [];

  //dados para trazer a lista de itens
  public endereco: any;
  public link: any;

  //variaveis usadas para o tratamento das opções
  public gruposOpcoesItens: any;
  public grupos: any = [];
  public produtosDaEntrega: any = [];
  public opcoesPorGrupo: any;



  //variaveis usadas na gravação das escolhas
  public escolhido: any;
  public opcoesEscolhidas: any = [];

  public numeroDaEntrega: number;
  public numeroTotalDeEntregas;


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private alertCtrl: AlertController,
    private httpUtilProvider: HttpUtilProvider,
    private commonServices: CommonServices,
  ) {
    this.numeroDaEntrega = 1;

    this.endereco = navParams.get("endereco");

    console.log("endereco1")
    console.log(this.endereco)
    if (this.endereco.latitude && this.endereco.longitude) {
      this.link = ENV.WS_TMS + API_URL + "tms/" + localStorage.getItem("empresa") +
        "/" + this.commonServices.numPedido +
        "/opcoesfrete?cep=" + this.endereco.ds_cep +
        "&latitude=" + this.endereco.latitude +
        "&longitude=" + this.endereco.longitude;
    }
    else {
      this.link = ENV.WS_TMS + API_URL + "tms/" + localStorage.getItem("empresa") +
        "/" + this.commonServices.numPedido +
        "/opcoesfrete?cep=" + this.endereco.ds_cep +
        "&latitude=0" + "&longitude=0";
    }
    // this.link = ENV.WS_TMS + API_URL + "tms/" + localStorage.getItem("empresa") +
    //   "/" + this.commonServices.numPedido +
    //   "/opcoesfrete?cep=" + this.endereco.ds_cep +
    //   "&latitude=" + this.endereco.latitude +
    //   "&longitude=" + this.endereco.longitude;

    // this.link = "http://hmlfcimbservices.ferreiracosta.local:8585/WS-TMS/tms/2/19142864/opcoesfrete?cep=51021190&latitude=-8.1758849&longitude=-34.9183028"
    console.log(this.link);
    this.trazerLista();
  }

  async trazerLista() {
    console.log(this.link);
    console.log("endereco2");
    console.log(this.endereco);

    await this.httpUtilProvider.getTMS(this.link).then((result: any) => {
      this.gruposOpcoesItens = result;
      if (this.gruposOpcoesItens[0].items == null) {
        this.zeroItensParaEntrega = true;
        this.verificaItensNaoEntregues();
      } else {
        this.verificaItensNaoEntregues();
        this.getGrupo();
      }
    }).catch(error => {
      if (error.message) {
        console.log(this.gruposOpcoesItens)
        let alert = this.alertCtrl.create({
          enableBackdropDismiss: false,
          message: error.message,
          buttons: [{
            text: "OK",
            handler: () => {
              this.modePageReturn = 1;
              this.retornarPagina();
            }
          }]
        });
        alert.present();
      }
      else if (error.title) {
        let alert = this.alertCtrl.create({
          enableBackdropDismiss: false,
          title: error.title,
          message: error.detail,
          buttons: [{
            text: "OK",
            handler: () => {
              this.modePageReturn = 1;
              this.retornarPagina();
            }
          }]
        });
        alert.present();
      }
    });
    console.log(this.gruposOpcoesItens);

  }

  verificaItensNaoEntregues() {
    let itensNaoEntregues = [];
    itensNaoEntregues = this.gruposOpcoesItens[0].itemsNaoEntregue;
    console.log(itensNaoEntregues)
    if (itensNaoEntregues.length == 0 || itensNaoEntregues == undefined) {
      console.log("Todos os itens podem ser entregues!")
      this.carregando = true;
      this.naoEntregues = false;
    } else {
      console.log("Alguns itens não podem ser entregues!")
      this.produtosNaoEntregues = itensNaoEntregues;
      this.carregando = false;
      this.naoEntregues = true;
    }
  }

  confirmaRemoveContinua() {
    let alert = this.alertCtrl.create({
      title: "Remover produto",
      message: "Tem certeza que deseja remover os produtos do pedido?",
      buttons: [
        {
          text: "Cancelar",
          role: "cancel",
          handler: () => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Remover",
          handler: () => {
            console.log('confirmed clicked');
            this.carregando = true;
            this.naoEntregues = false;
            this.removeContinua();
          }
        }
      ]
    });
    alert.present();
  }
  async removeContinua() {
    for (let i = 0; i < this.produtosNaoEntregues.length; i++) {
      try {
        await this.httpUtilProvider.post(
          ENV.WS_VENDAS + API_URL +
          "PedidoVendaItem/" +
          localStorage.getItem("empresa") +
          "/" +
          this.produtosNaoEntregues[i].numPedido +
          "/" +
          this.produtosNaoEntregues[i].idProduto,
          {}
        );
        this.itensDeletados.push(this.produtosNaoEntregues[i])

        // this.refreshItem();
      } catch (error) {
        this.commonServices.showToast(error);
      }
    }
    console.log("itens deletados:")
    console.log(this.itensDeletados)
  }

  getGrupo() {
    for (let i = 0; i < this.gruposOpcoesItens.length; i++) {
      if (this.grupos.indexOf(this.gruposOpcoesItens[i].grupo) == -1)
        this.grupos.push(this.gruposOpcoesItens[i].grupo)
    }
    // for (let i = 0; i < this.produtosDaEntrega.length; i++) {
    //   if (this.produt)
    // }
    console.log("Grupos:")
    console.log(this.grupos)
    this.numeroDaEntrega = this.grupos[this.numeroDaEntrega - 1];
    console.log("Numero da entrega:")
    console.log(this.numeroDaEntrega)
    this.numeroTotalDeEntregas = this.grupos.length;
    this.getItensDoGrupo()
    this.getOpcoesPorGrupo();
    this.verificaNumeroPacote();
  }

  getItensDoGrupo() {
    for (let i = 0; i < this.gruposOpcoesItens.length; i++) {
      if (this.gruposOpcoesItens[i].grupo == this.numeroDaEntrega) {
        this.produtosDaEntrega = this.gruposOpcoesItens[i].items
      }
    }
    // if (this.gruposOpcoesItens[this.numeroDaEntrega-1].grupo == this.numeroDaEntrega) {
    //   this.produtosDaEntrega = this.gruposOpcoesItens[this.numeroDaEntrega-1].items
    // } 
    console.log(this.produtosDaEntrega)
  }

  getOpcoesPorGrupo() {
    if (this.gruposOpcoesItens[this.numeroDaEntrega - 1].grupo == this.numeroDaEntrega) {
      this.opcoesPorGrupo = this.gruposOpcoesItens[this.numeroDaEntrega - 1].opcoes
    }
    console.log(this.opcoesPorGrupo)
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EntregaTransportadoraPage');
  }



  seleciona(i) {
    if (this.opcoesEscolhidas.length == this.numeroDaEntrega) {
      this.opcoesEscolhidas.pop()
    }

    console.log(i)
    console.log("numero entrega: " + this.numeroDaEntrega)
    console.log("total de grupos: " + this.grupos.length)

    this.escolhido = i;
    console.log("escolhido: ")
    console.log(this.escolhido)

    if (i.retiraLoja == "N") {
      this.selecionado = true;
      this.retiraLoja = false;
      this.outraPessoaBusca = false;
    } else if (i.retiraLoja == "S") {
      this.selecionado = true;
      this.retiraLoja = true;
      this.outraPessoaBusca = false;
    }
    // this.selecionado = true;
    // console.log(this.selecionado);
    // this.outraPessoaBusca = false;
  }

  gravaEscolha(escolhido) {

    let json = {
      grupo: escolhido.grupo,
      tipoEntrega: escolhido.tipoEntrega
    }
    if (this.opcoesEscolhidas.length == this.numeroDaEntrega) {
      this.opcoesEscolhidas.pop()
    }
    console.log("Grava escolhas")
    console.log(json);

    this.opcoesEscolhidas.push(json)

  }
  salvarEscolhas() {
    this.gravaEscolha(this.escolhido)
    this.atualizaFrete(); // by Ryuge 26/09/2019
    this.salvar();
    // let alert = this.alertCtrl.create({
    //   // title: "Informe a quantidade desejada",
    //   subTitle: "Finalizar a seleção?",
    //   buttons: ['CANCELAR', {
    //     text: "SIM",
    //     handler: data => {
    //       this.salvar();
    //     }
    //   }]
    // });
    // alert.present();
  }


  async salvar() {
    console.log("Salvando...")
    await this.httpUtilProvider.post(ENV.WS_TMS + API_URL + "tms/" + localStorage.getItem("empresa") +
      "/" + this.commonServices.numPedido +
      "/gravaopcoesfrete?cep=" + this.endereco.ds_cep +
      "&latitude=" + this.endereco.latitude +
      "&longitude=" + this.endereco.longitude,
      this.opcoesEscolhidas).then(data => {
        console.log(this.opcoesEscolhidas);
        console.log("Salvou!");
        console.log(data);
        //by Lucas 04/10/2019
        let result: any = data;
        this.commonServices.valorFrete = result.frete.valor;
        this.navCtrl.push("FormasPagamento", { item: data, mode: 3 })
      });
  }

  // by Ryuge 26/09/2019
  async atualizaFrete() {
    await this.httpUtilProvider.post(ENV.WS_VENDAS + API_URL + 'PedidoVenda/'
      + localStorage.getItem('empresa') + '/' + this.commonServices.numPedido + '/entrega'
      + '?' + 'seqEnderecoEntrega=' + this.endereco.id.sequencialId
      + '&' + 'idTransportadora=' + 0, {}).then(result => {
        console.log('atualizaFrete');
        console.log(this.endereco.id.sequencialId);
        console.log(result);
      }
      );
  }

  //Navegação entre os pacotes da entrega
  voltarPacote() {
    this.numeroDaEntrega--;
    this.opcoesEscolhidas.pop()
    console.log("Apaga ultima escolha")
    console.log(this.opcoesEscolhidas)

    this.selecionado = false;
    this.getItensDoGrupo()
    this.getOpcoesPorGrupo();
    this.verificaNumeroPacote();
  }
  proximoPacote() {
    this.numeroDaEntrega++;
    this.gravaEscolha(this.escolhido)

    this.selecionado = false;
    this.getItensDoGrupo()
    this.getOpcoesPorGrupo();
    this.verificaNumeroPacote();
  }
  verificaNumeroPacote() {
    if (this.numeroDaEntrega == this.grupos.length) {
      this.ultimoPacote = true;
    } else {
      this.ultimoPacote = false;
    }
  }

  outraPessoa() {
    console.log(this.outraPessoaBusca)
  }


  showProduto() {
    this.showProdutos = !this.showProdutos;
  }

  outraPessoaNome() {
    let alert = this.alertCtrl.create({
      // title: "Informe a quantidade desejada",
      subTitle: "Nome do retirante:",
      inputs: [
        {
          id: "idinput",
          name: "nome",
          type: "string",
          placeholder: ""
        }
      ],
      buttons: ['CANCELAR', {
        text: "OK",
        handler: data => {
          this.outraPessoaNomeRetirada = data.nome;
          console.log(this.outraPessoaNomeRetirada)
        }
      }]
    });
    alert.present();
  }
  outraPessoaCPF() {
    let alert = this.alertCtrl.create({
      // title: "Informe a quantidade desejada",
      subTitle: "CPF do retirante",
      inputs: [
        {
          id: "idinput",
          name: "cpf",
          type: "number",
          placeholder: ""
        }
      ],
      buttons: ['CANCELAR', {
        text: "OK",
        handler: data => {
          this.outraPessoaCPFRetirada = data.cpf.toString();
          console.log(this.outraPessoaCPFRetirada)
        }
      }]
    });
    alert.present();
  }
  outraPessoaEmail() {
    let alert = this.alertCtrl.create({
      // title: "Informe a quantidade desejada",
      subTitle: "E-mail do retirante",
      inputs: [
        {
          id: "idinput",
          name: "email",
          type: "string",
          placeholder: ""
        }
      ],
      buttons: ['CANCELAR', {
        text: "OK",
        handler: data => {
          this.outraPessoaEmailRetirada = data.email;
          console.log(this.outraPessoaEmailRetirada)
        }
      }]
    });
    alert.present();
  }

  // by Ryuge 02/10/2019
  getIndexPedido(idPedido, itemSacola: any) {
    let idx;
    for (var i in itemSacola) {
      if (idPedido == itemSacola[i].numpedido) {
        idx = i;
        break;
      }
    }
    return idx;
  }

  // by Ryuge 02/10/2019
  retornaPedidoSacola() {
    let itPedido;
    let idxPedido;

    if (this.commonServices.sistuacaoPedido == "A") {
      itPedido = this.commonServices.itemPedidoAberto.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    } else {
      itPedido = this.commonServices.itemPedidoFinalizado.content;
      idxPedido = this.getIndexPedido(this.commonServices.numPedido, itPedido);
    }

    if (itPedido != {}) {
      this.navCtrl.push("PedidoSacola", { item: itPedido[idxPedido], mode: 5 });
    } else {
      this.navCtrl.push("PedidoSacola", { mode: 5 });
    }
  }

  // by Ryuge 02/10/2019
  retornarPagina() {

    switch (this.modePageReturn) {
      case 1:
        this.retornaPedidoSacola();
        break;
      default:
        this.navCtrl.pop();
        break;
    }
  }

}
