import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IonicImageViewerModule } from 'ionic-img-viewer';

import { ProdutoInformacao } from './produto-informacao';

 
@NgModule({
  declarations: [
    ProdutoInformacao,
  ],
  imports: [
    IonicPageModule.forChild(ProdutoInformacao),
    IonicImageViewerModule
  ],
  exports: [
    ProdutoInformacao
  ]
})
export class  ProdutoInformacaoModule {}