import { Component } from '@angular/core';
import { ENV } from '@app/env';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
// by Ryuge 27/02/2019
import { API_URL } from '../../config/app.config';
// import * as environment from './../../environments/environment';
import { HttpUtilProvider } from './../../providers/http-util/http-util';
import { CommonServices } from './../../services/common-services';

@IonicPage()
@Component({
  selector: 'produto-informacao',
  templateUrl: 'produto-informacao.html'
})
export class ProdutoInformacao {

  selected: any;

  public item: any;
  public dados;
  public detalhe: any[];
  public espec: any[];
  public display: any[];

  public exibe: boolean = false;
  public nome;
  public valor;
  public descricao0;
  public descricao1;
  public descricao2;

  public Show: boolean = true;
  public Hide: boolean = false;

  constructor(
    public commonServices: CommonServices,
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpUtilProvider: HttpUtilProvider,
    public translateService: TranslateService,
    public platform: Platform
  ) {

    // by ryuge 27/09/2018	
    platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);

    this.item = navParams.data.item;
    this.getInfomationProduct(this.item.codigodigitoembalagem)
  }

  retornarPagina() {
    this.navCtrl.pop();
  }

  ionViewWillEnter() {
    // by ryuge 27/09/2018	
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    }, 1);

  }

  showNext() {
    this.Show = !this.Show;
    this.Hide = !this.Hide;
  }

  async getInfomationProduct(codProduto) {

    try {
      this.dados = await this.httpUtilProvider.get(ENV.WS_PRODUTO + API_URL + 'detalhe/' + codProduto);

      this.detalhe = this.dados.items[0].items;
      this.espec = this.dados.items[1].items;
      this.display = this.dados.items[2].items;

      this.exibe = this.dados.nome != '';
      this.nome = this.dados.nome;
      this.valor = this.dados.valor;
      this.descricao0 = this.dados.items[0].descricaoGrupo;
      this.descricao1 = this.dados.items[1].descricaoGrupo;
      this.descricao2 = this.dados.items[2].descricaoGrupo;

      // console.log( this.detalhe);

    } catch (error) {
      this.commonServices.showToast(error.json().detail);
    }

  }
}
