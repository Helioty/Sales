export interface Environment {
  mode: string; 
  WS_AUTH: string;
  WS_PRODUTO: string;
  WS_CRM: string;
  WS_VENDAS: string;
  WS_PUBLIC: string;
  WS_COMMONS: string;
  WS_TMS: String;
}
