import { Environment  } from './environment.model';

// AREA DE TESTE
// export const API_URL = 'http://10.131.1.234:8585/';
// export const API_URL = 'http://hmlfcimbservices.ferreiracosta.local:8585/';

// let _URL = API_URL+'WS-Authentication/';

export const ENV: Environment = {

  mode: 'Development',
  WS_AUTH: 'https://login.',
  WS_PRODUTO:  'https://produto.',
  WS_CRM: 'https://crm.',
  WS_VENDAS: 'https://vendas.',
  WS_PUBLIC: 'https://publico.',
  WS_COMMONS: 'https://comum.',
  WS_TMS: 'https://tms.'

  // mode: 'Development',
  // WS_AUTH: 'WS-Authentication/',
  // WS_PRODUTO:  'WS-Produto/',
  // WS_CRM: 'WS-CRM/',
  // WS_VENDAS: 'WS-Vendas/',
  // WS_PUBLIC: 'WS-Publico/',
  // WS_COMMONS: 'WS-Commons/',
  // WS_TMS: 'WS-TMS/'
}

