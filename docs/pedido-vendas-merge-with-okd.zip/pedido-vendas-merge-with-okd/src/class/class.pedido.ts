export class Totalizadores {
    totalPedidoEmAberto: number;
    totalPedidoFinalizado: number;
    constructor(){}

    setTotalEmAberto(value) {
        this.totalPedidoEmAberto = value;
    }

    getTotalEmAberto() {
        return this.totalPedidoEmAberto;
    }

    setTotalFinalizado(value) {
        this.totalPedidoFinalizado = value;
    }

    getTotalFinalizado() {
        return this.totalPedidoFinalizado;
    }


}

export class PedidoCab {
    id: number;
    empresa: string;
    cliente: string;
    vendedor: string;
    dataEmissao: string;
    tipoEntrega: string;
    formaPagamento: string;
    numeroDeParcela: number;
    subTotal: number;
    frete: number;
    entrada: number;
    total: number;
    exigeAprovacao: boolean;

    constructor(
        id: number,
        empresa: string
    ) { }
}

export class PedidoItens {
    idEmpresa: number;
    numPedido: number;
    idProduto: string;
    descricao: string;
    embalagem: number;
    retiradas: Retiradas[];
    qtdTotal: number = 0;
    prcUnitario: number = 0;
    prcTotal: number = 0;
    imagem: string;

    constructor(
        idEmpresa: string,
        numPedido: number,
    ) { }
}

export class Retiradas {
    empresaRetirada: number;
    idDeposito: number;
    tipoRetirada: number;
    qtd: number;
    precoUnitario: number;

    constructor(
    ) { }
}

export class AtualizaPedido {
    cliente: string; //cpf do cliente
    vendedor: string; //código do vendedor
    entrega: string;
    tipo_pagamento: string;
    condicao_pagto: string;
    seq_endereco_entrega: string; //Sequencial do Endereço de Entrega
    valor_entrada: number;
    basket: number;
}


export class PedidoTable  {
    name: string; //atributo do objeto AtualizaPedido
    value: string; //valor do atributo
}

//Criado por Nicollas Bastos em 10-09-2018
// Classe para gerenciar o Accordeon em Pedido-Rapido
export class EstoqueProduto {
  show: boolean = false;
  estoque: number[];
  estoqueTotal: number;
  empresa: number;
  tipoEntrega: number;

}

