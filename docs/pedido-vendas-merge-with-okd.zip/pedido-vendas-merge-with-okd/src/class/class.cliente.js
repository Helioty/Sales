var Sequence = (function () {
    function Sequence(sequencialId, clienteId) {
    }
    return Sequence;
}());
export { Sequence };
var Clientes = (function () {
    function Clientes(id, cgccpf, nome, recnum, cep, endereco, numero, complemento, bairro, cidade, uf, origem_registro, natureza) {
    }
    return Clientes;
}());
export { Clientes };
var Endereco = (function () {
    function Endereco(id, cd_status, tp_ende, ds_ende, nu_ende, ds_compl, ds_bairro, ds_cep, ds_uf, nu_praca, ds_obs, nu_referencia_pessoal, cd_inscricao, usuario_cadastrou, latitude, longitude) {
    }
    return Endereco;
}());
export { Endereco };
var Telefone = (function () {
    function Telefone(id, referencia_pessoal, tipo, subtipo, observacao, recebe_nfe, status, ddd, numero, ramal) {
    }
    return Telefone;
}());
export { Telefone };
var Celular = (function () {
    function Celular(id, referencia_pessoal, tipo, subtipo, observacao, recebe_nfe, status, ddd, numero, ramal) {
    }
    return Celular;
}());
export { Celular };
var Email = (function () {
    function Email(id, referencia_pessoal, tipo, subtipo, observacao, recebe_nfe, status, email_site) {
    }
    return Email;
}());
export { Email };
//# sourceMappingURL=class.cliente.js.map