var Produto = (function () {
    function Produto(cod_produto, codigo, descricao, linha, codigoForn, descricaoForn, fantas, unidade, imagem, codbarean13, preco) {
    }
    return Produto;
}());
export { Produto };
//# sourceMappingURL=class.produto.js.map