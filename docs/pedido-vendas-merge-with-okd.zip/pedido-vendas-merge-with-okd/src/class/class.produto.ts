export class Produto {
    constructor(
        cod_produto: number,
        codigo: number,
        descricao: string,
        linha: string,
        codigoForn: string,
        descricaoForn: string,
        fantas: string,
        unidade: string,
        imagem: string,
        codbarean13: string,
        preco: number
    ) { }
}