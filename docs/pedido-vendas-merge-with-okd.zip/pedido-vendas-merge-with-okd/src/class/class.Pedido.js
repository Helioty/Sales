var Totalizadores = (function () {
    function Totalizadores() {
    }
    Totalizadores.prototype.setTotalEmAberto = function (value) {
        this.totalPedidoEmAberto = value;
    };
    Totalizadores.prototype.getTotalEmAberto = function () {
        return this.totalPedidoEmAberto;
    };
    Totalizadores.prototype.setTotalFinalizado = function (value) {
        this.totalPedidoFinalizado = value;
    };
    Totalizadores.prototype.getTotalFinalizado = function () {
        return this.totalPedidoFinalizado;
    };
    return Totalizadores;
}());
export { Totalizadores };
var PedidoCab = (function () {
    function PedidoCab(id, empresa) {
    }
    return PedidoCab;
}());
export { PedidoCab };
var PedidoItens = (function () {
    function PedidoItens(idEmpresa, numPedido) {
        this.qtdTotal = 0;
        this.prcTotal = 0;
    }
    return PedidoItens;
}());
export { PedidoItens };
var Retiradas = (function () {
    function Retiradas() {
    }
    return Retiradas;
}());
export { Retiradas };
//# sourceMappingURL=class.Pedido.js.map