module.exports = {
    copyIndexContent: {
      src: ['{{SRC}}/assets/imgs/logo.png'],
      dest: '{{WWW}}'
    }
  }