// by ryuge 25/09/2018
// $env:APP_ENV="prod" ou $env:APP_ENV="dev"

const chalk = require("chalk");
var path = require('path');
var defaultConfig = require('@ionic/app-scripts/config/webpack.config.js');
var fs = require('fs'); // by Ryuge 18/12/2018

var env = process.env.APP_ENV ? process.env.APP_ENV : 'dev';

console.log(chalk.yellow.bgBlack('\nUsing ' + env + ' environment variables.\n'));

// by Ryuge 18/12/2018
if (env == 'dev') {
  fs.unlinkSync("./src/index.html");
  fs.unlinkSync("./src/manifest.json");
  console.log(chalk.green.bgBlack('\nCopiando arquivos do ambiente ' + env + ' aguarde....\n'));
  fs.copyFileSync("./src/templates/index-dev.html", "./src/index.html", 1);
  fs.copyFileSync("./src/templates/manifest-dev.json", "./src/manifest.json", 1);
} else {
  fs.unlinkSync("./src/index.html");
  fs.unlinkSync("./src/manifest.json");
  console.log(chalk.green.bgBlack('\nCopiando arquivos do ambiente ' + env + ' aguarde...\n'));
  fs.copyFileSync("./src/templates/index-prod.html", "./src/index.html", 1);
  fs.copyFileSync("./src/templates/manifest-prod.json", "./src/manifest.json", 1);
}

var devWebPackConfig = defaultConfig.dev;
devWebPackConfig.resolve.alias = {
  "@app/env": path.resolve('./src/environments/environment.' + env + '.ts')
};

var prodWebPackConfig = defaultConfig.prod;
prodWebPackConfig.resolve.alias = {
  "@app/env": path.resolve('./src/environments/environment.' + env + '.ts')
};

module.exports = {
  dev: devWebPackConfig,
  prod: prodWebPackConfig
};
